const express=require("express")
const { login, signup, get_signup, changePassword, sendmail , forgotpassword , uploadImage, uploadFile,viewProfile,editAdminProfile,resetPassword,updateDynamic} = require("../controller/signup")
const router = express.Router();
const {auth}=require('../helper/auth')


/**
 * @swagger
 * /api/user/admin/signup:
 *  post:
 *      summary: Sign Up Admin
 *      tags: [Admin-Users]
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          email:
 *                              type: string
 *                              default: ''
 *                          password:
 *                              type: string
 *                              default: admin1
 *      responses:
 *          default:
 *              description: Default response for this api
 */

router.post("/api/user/admin/signup",signup)

/**
 * @swagger
 * /api/user/admin/login:
 *  post:
 *      summary: Admin Login
 *      description: get user details and token after login
 *      tags: [Admin-Users]
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          email:
 *                              type: string
 *                          password:
 *                              type: string
 *      responses:
 *          200:
 *              description: Success
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/SuccessResponse'
 *          default:
 *              description: Default response for this api
 */


router.post("/api/user/admin/login",login)


//// This is an user admin update api by user email for changing the user password with hashing password
/**
 * @swagger
 * /api/user/admin/change-password/{token}:
 *  put:
 *      summary: Change Password Admin
 *      tags: [Admin-Users]
 *      parameters:
 *      - name: token
 *        in: path
 *        description: token of an admin user
 *        required: true
 *        default: ""
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          password:
 *                              type: string
 *                              default: ''
 *                          cpassword:
 *                              type: string
 *                              default: ''
 *      responses:
 *          200:
 *              description: Success
 * 
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/SuccessResponse'
 *          default:
 *              description: Default response for this api
 */

router.put("/api/user/admin/change-password/:token",changePassword)


/**
 * @swagger
 * /api/user/admin/forgot-password:
 *  post:
 *      summary: Change Password Admin
 *      tags: [Admin-Users]
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          email:
 *                              type: string
 *                              default: ''
 *      responses:
 *          200:
 *              description: Success
 * 
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/SuccessResponse'
 *          default:
 *              description: Default response for this api
 */


router.post("/api/user/admin/forgot-password",forgotpassword)


router.get("/api/user/admin/get_signup",get_signup)

router.post("/api/user/admin/emailsending",sendmail)

/**
 * @swagger
 * /api/user/admin/uploadImage:
 *  post:
 *      summary: Upload Image on cloudFlare
 *      tags: [UPLOAD API]
 *      requestBody:
 *          required: true
 *          content:
 *              multipart/form-data:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          file:
 *                              type: string
 *                              format: base64
 *      responses:
 *          200:
 *              description: Success                      
 *          default:
 *              description: Default response for this api
 */
router.post("/api/user/admin/uploadImage",uploadImage)


/**
 * @swagger
 * /api/user/admin/uploadFile:
 *  post:
 *      summary: Upload file on s3
 *      tags: [UPLOAD API]
 *      requestBody:
 *          required: true
 *          content:
 *              multipart/form-data:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          file:
 *                              type: string
 *                              format: base64
 *      responses:
 *          200:
 *              description: Success                      
 *          default:
 *              description: Default response for this api
 */
router.post("/api/user/admin/uploadFile",uploadFile);

/**
 * @swagger
 * /get-profile:
 *  get:
 *      summary: get admin profile
 *      tags: [Admin-Users]
 *      responses:
 *         200:
 *             description: Success
 *         default:
 *             description: Default responses for this api
 */
router.get('/get-profile',auth,viewProfile)


/**
 * @swagger
 * /edit-admin:
 *  put:
 *      summary: edit admin profile
 *      tags: [Admin-Users]
 *      requestBody:
 *            required: true
 *            content:
 *                application/json:
 *                    schema:
 *                        type: object
 *                        properties:
 *                              first_name:   
 *                                     type: string
 *                                     default: ""
 *                              last_name:
 *                                     type: string
 *                                     default: ""
 *                              profile_pic_image_id:
 *                                     type: string
 *                                     default: ""
 *      responses:
 *         200:
 *             description: Success
 *         default:
 *             description: Default responses for this api                   
 */
router.put('/edit-admin',auth,editAdminProfile);


/**
 * @swagger
 * /reset-password:
 *  put:
 *      summary: reset with old password
 *      tags: [Admin-Users]
 *      requestBody: 
 *          required: true
 *          content:
 *             application/json:
 *                schema:
 *                  type: object
 *                  properties:
 *                      oldpassword:
 *                          type: string
 *                          default: ""
 *                      newpassword:
 *                          type: string
 *                          default: ""
 *      responses:
 *        200:
 *            description: Success
 *        default:
 *            description: Default response for this api   
 */
router.put('/reset-password',auth,resetPassword);


/**
 * @swagger
 * /update-dynamic-tables:
 *  put:
 *      summary: update dynamic table
 *      tags: [update-dynamic]
 *      requestBody: 
 *          required: true
 *          content:
 *             application/json:
 *                schema:
 *                  type: object
 *                  properties:
 *                      cafe_dynamic_total_order:
 *                          type: int
 *                          default: "0"
 *                      cafe_dynamic_total_item:
 *                          type: int
 *                          default: "0"
 *                      cafe_dynamic_average_ticket_size:
 *                          type: int
 *                          default: "0"
 *                      cafe_dynamic_average_rating:
 *                          type: int
 *                          default: "0"
 *                      cafe_dynamic_average_waiting_time:
 *                          type: int
 *                          default: "0"
 *                      cafe_dynamic_most_used_payment_mode:
 *                          type: int
 *                          default: "0"
 *                      cafe_dynamic_starting_price:
 *                          type: int
 *                          default: "0"
 *                      menu_dynamic_total_cafe:
 *                          type: int
 *                          default: "0"
 *                      menu_dynamic_average_rating:
 *                          type: int
 *                          default: "0"
 *                      menu_dynamic_total_items:
 *                          type: int
 *                          default: "0"
 *                      user_customer_dynamic_cafe_visit:
 *                          type: int
 *                          default: "0"
 *                      user_customer_dynamic_order_item_count:
 *                          type: int
 *                          default: "0"
 *                      user_customer_dynamic_no_of_reviews:
 *                          type: int
 *                          default: "0"
 *                      user_customer_dynamic_no_of_orders:
 *                          type: int
 *                          default: "0"
 *      responses:
 *        200:
 *            description: Success
 *        default:
 *            description: Default response for this api   
 */
router.put('/update-dynamic-tables',auth,updateDynamic);

module.exports =router  