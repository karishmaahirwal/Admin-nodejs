const express = require("express")
const Banner = require("../../controller/banner_ads/banner")
const {auth} = require('../../helper/auth')
const axios = require("axios")

const router = express.Router();

/**
 * @swagger
 * /api/user/admin/get-bannerads:
 *   get:
 *     tags: [Banner API's]
 *     parameters:
 *       - in: query
 *         name: pageno
 *         schema:
 *           type: int
 *       - in: query
 *         name: limits
 *         schema:
 *           type: int
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */
// done
router.get("/api/user/admin/get-bannerads",auth,Banner.banners)

/**
 * @swagger
 * /api/user/admin/get-bannerads-Byid/{bannerId}:
 *   get:
 *      tags: [Banner API's]
 *      parameters:
 *       - in: path
 *         name: bannerId
 *         schema:
 *           type: string
 *         required: true
 *      responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */


router.get("/api/user/admin/get-bannerads-Byid/:bannerId",auth,Banner.getbannerById);

/**
 * @swagger
 * /api/user/admin/add-bannerads:
 *  post:
 *      tags: [Banner API's]
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          cafe_list_id:
 *                               type: string
 *                               default: ''
 *                          start_date:
 *                               type: string
 *                               default: ''
 *                          end_date:
 *                               type: string
 *                               default: ''
 *                          banner_link:
 *                               type: string
 *                               default: ''
 *                          title:
 *                               type: string
 *                               default: ''
 *                          category:
 *                               type: string
 *                               default: ''
 *                          position:
 *                               type: string
 *                               default: ''
 *                          banner_image_id:
 *                               type: string
 *                               default: ''
 *                          status:
 *                               type: boolean
 *                               default: ''
 *      responses:
 *          200:
 *              description: Success
 *
 *          default:
 *              description: Default response for this api
 */
router.post("/api/user/admin/add-bannerads",auth,Banner.uploadBanner);

/**
 * @swagger
 * /api/user/admin/edit-bannerads/{bannerId}:
 *  put:
 *      tags: [Banner API's]
 *      parameters:
 *       - in: path
 *         name: bannerId
 *         schema:
 *           type: string
 *         required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          cafe_list_id:
 *                               type: int
 *                               default: ''
 *                          start_date:
 *                               type: string
 *                               default: ''
 *                          end_date:
 *                               type: string
 *                               default: ''
 *                          banner_link:
 *                               type: string
 *                               default: ''
 *                          title:
 *                               type: string
 *                               default: ''
 *                          category:
 *                               type: string
 *                               default: ''
 *                          position:
 *                               type: string
 *                               default: ''
 *                          banner_image_id:
 *                               type: string
 *                               default: ''
 *                          status:
 *                               type: boolean
 *                               default: ''
 *      responses:
 *          200:
 *              description: Success
 *
 *          default:
 *              description: Default response for this api
 */

router.put("/api/user/admin/edit-bannerads/:bannerId",auth,Banner.editBanner);

module.exports = router;