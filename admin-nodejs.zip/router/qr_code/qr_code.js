const express = require("express")
const qrcode = require("../../controller/qr_code/qr_code")
const { auth } = require('../../helper/auth')
const axios = require("axios")

const router = express.Router();



/**
 * @swagger
 * /api/user/admin/get-qrcodes:
 *   get:
 *     tags: [QR API's]
 *     parameters:
 *       - in: query
 *         name: pageno
 *         schema:
 *           type: int
 *       - in: query
 *         name: limits
 *         schema:
 *           type: int
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */
// done
router.get("/api/user/admin/get-qrcodes",auth,qrcode.getqr); 


/**
 * @swagger
 * /api/user/admin/get-qrcodes/{qrId}:
 *   get:
 *     tags: [QR API's]
 *     parameters:
 *       - in: path
 *         name: qrId
 *         schema:
 *           type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */

router.get("/api/user/admin/get-qrcodes/:qrId",auth,qrcode.getqrById);

/**
 * @swagger
 * /api/user/admin/create-qrcode:
 *  post:
 *      tags: [QR API's]
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties: 
 *                         cafe_list_id:
 *                            type: int
 *                            default: ''
 *                         table_title:
 *                            type: string
 *                            default: ''
 *                         status:
 *                            type: int
 *                            default: ''
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */






router.post("/api/user/admin/create-qrcode",auth,qrcode.createQr);


/**
 * @swagger
 * /api/user/admin/edit-qrcode/{qrId}:
 *  put:
 *      tags: [QR API's]
 *      parameters:
 *       - in: path
 *         name: qrId
 *         schema:
 *           type: string
 *         required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties: 
 *                         cafe_list_id:
 *                            type: int
 *                            default: ''
 *                         table_title:
 *                            type: string
 *                            default: ''
 *                         status:
 *                            type: int
 *                            default: ''
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */





router.put("/api/user/admin/edit-qrcode/:qrId",auth,qrcode.editqr);










module.exports=router;