const express=require("express")
const orders = require("../controller/orders")
const router = express.Router()
const { auth } = require('../helper/auth')

/**
 * @swagger
 * /api/admin/orders/list-live-orders:
 *   get:
 *     tags: [Orders]
 *     parameters:
 *       - in: query
 *         name: pageno
 *         schema:
 *           type: integer
 *         required: true
 *       - in: query
 *         name: limits
 *         schema:
 *           type: integer
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */

router.get("/api/admin/orders/list-live-orders",auth,orders.getLiveOrders)

/**
 * @swagger
 * /api/admin/orders/live-order-details-by-id/{order_detail_id}:
 *   get:
 *     tags: [Orders]
 *     parameters:
 *       - in: path
 *         name: order_detail_id
 *         schema:
 *           type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 */

router.get("/api/admin/orders/live-order-details-by-id/:order_detail_id",auth,orders.getLiveOrderDetailById)


/**
 * @swagger
 * /api/admin/orders/edit-live-order-details-by-id/{order_detail_id}:
 *  put:
 *      tags: [Orders]
 *      parameters:
 *       - in: path
 *         name: order_detail_id
 *         schema:
 *           type: string
 *         required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties: 
 *                         cooking_status:
 *                            type: int
 *                            default: ''
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */



router.put("/api/admin/orders/edit-live-order-details-by-id/:order_detail_id",auth,orders.Edit_Live_Order_Detail_by_ID)

/**
 * @swagger
 * /api/admin/orders/list-orders-history:
 *   get:
 *     tags: [Orders]
 *     parameters:
 *       - in: query
 *         name: pageno
 *         schema:
 *           type: integer
 *         required: true
 *       - in: query
 *         name: limits
 *         schema:
 *           type: integer
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */


router.get("/api/admin/orders/list-orders-history",auth,orders.Get_Order_History)


/**
 * @swagger
 * /order_history/{id}:
 *   get:
 *     tags: [Orders]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 */
router.get("/order_history/:id",orders.getOrderHistoryById)
module.exports = router