const express = require("express")
const Restaurant = require("../../controller/Restaurant/restaurant")
const restaurantFeatureImages = require("../../controller/Restaurant/restaurantFeaturedImage")
const {auth} = require('../../helper/auth')
const axios = require("axios")

const router = express.Router()

const multer = require('multer')
const path = require('path')

let API_KEY = ' JQl1vemVuIAUFBZ7LGezK3usRbphgGJP ';
let ACCOUNT_ID = ' 043e878517dbb7916d8cdc1f246a4e15 ';
let Token = '2MT9voCHBE9J2Xb8qUhHi6VwHkvW7se0A9DulOQz'


const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        if (!fs.existsSync("./src/restaurant/logo_image")) {
            fs.mkdirSync("./src/restaurant/logo_image", {recursive: true});
        }
        cb(null, "./src/restaurant/logoimage");
    },
    filename: (req, file, callback) => {
        callback(null, (path.basename(file.originalname) + '' + Date.now()).replace(/:|.|-|(|)/g, '_') + path.extname(file.originalname));
    }
});
const fileFilter = (req, file, cb) => {
    if (file) {
        cb(null, true)
    } else {
        cb(null, false)
    }
};

const upload = multer({
    storage: storage,
    fileFilter: fileFilter
})

const formData = new URLSearchParams();
formData.append('file', upload);

let cloudflareResponse;

const uploadImage = async (req, res) => {
    try {
        cloudflareResponse = await axios.post(
            // cloudflareResponse = axios.post(
            `https://api.cloudflare.com/client/v4/accounts/${ACCOUNT_ID}/images/v`,
            formData,
            {
                headers: {
                    Authorization: `Bearer ${API_KEY}`,
                    'Content-Type': 'multipart/form-data',
                }
            }
        );
    } catch (e) {
        console.log('Error while trying to upload image to Cloudflare API ', e);
    }

}


module.exports = {uploadImage}

/**
 * @swagger
 * /api/user/admin/create-restaurant:
 *  post:
 *      summery: create Restaurant
 *      tags: [CafeList-Restaurants]
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          cafe_name:
 *                              type: string
 *                          email:
 *                              type: string
 *                              default: ''
 *                          city:
 *                               type: string
 *                               default: ''
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */
// done for creating restaurant
router.post("/api/user/admin/create-restaurant", auth, Restaurant.Createrestaurant)

// router.get("/api/user/admin/restaurant/get-general-info/{cafe_list_id",auth,Restaurant.getRestaurantByCafe_list_id)

// /**
//  * @swagger
//  * /api/user/admin/restaurant/general/information/of/cafe/:cafe_list_id:
//  *  post:
//  *      tags: [Restaurant API's]
//  *      requestBody:
//  *          required: true
//  *          content:
//  *              application/json:
//  *                  schema:
//  *                      type: object
//  *                      properties:
//  *                          slogan:
//  *                              type: string
//  *                          logo_image_id:
//  *                              type: string
//  *                              default: ''
//  *      responses:
//  *          200:
//  *              description: Success
//  *          default:
//  *              description: Default response for this api
//  */


/**
 * @swagger
 * /api/user/admin/restaurant/viewprofile/{cafe_list_id}:
 *   get:
 *     tags: [CafeList-Restaurants]
 *     parameters:
 *       - in: path
 *         name: cafe_list_id
 *         schema:
 *           type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */
// done to get the restaurant profile
router.get("/api/user/admin/restaurant/viewprofile/:cafe_list_id", auth, Restaurant.get_generalInformation)
/**
 * @swagger
 * /api/user/admin/restaurant-all-info/{cafe_list_id}:
 *   get:
 *     tags: [CafeList-Restaurants]
 *     parameters:
 *       - in: path
 *         name: cafe_list_id
 *         schema:
 *           type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */
// done to get the restaurant general info
router.get("/api/user/admin/restaurant-all-info/:cafe_list_id", auth, Restaurant.get_generalInformation)

/**
 * @swagger
 * /api/user/admin/restaurant-edit-general-information/{cafe_list_id}:
 *  post:
 *      tags: [CafeList-Restaurants]
 *      parameters:
 *       - in: path
 *         name: cafe_list_id
 *         schema:
 *           type: string
 *         required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                         cafe_name:
 *                            type: string
 *                            default: ''
 *                         email:
 *                            type: string
 *                            default: ''
 *                         mobile_number:
 *                             type: string
 *                             default: ''
 *                         cafe_slogan:
 *                             type: string
 *                             default: ''
 *                         description:
 *                             type:  string
 *                             default: ''
 *                         is_featured:
 *                             type: int
 *                             default: ''
 *                         is_most_visited:
 *                             type: int
 *                             default: ''
 *                         is_new_opening:
 *                             type: int
 *                             default: ''
 *                         is_veg:
 *                             type: int
 *                             default: ''
 *                         is_non_veg:
 *                             type: int
 *                             default: ''
 *                         status:
 *                             type: int
 *                             default: ''
 *                         logo_image_id:
 *                             type: string
 *                             default: ""
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */
router.post("/api/user/admin/restaurant-edit-general-information/:cafe_list_id", auth, Restaurant.post_generalinfo)

/**
 * @swagger
 * /api/user/admin/restaurant-edit-address-information/{cafe_list_id}:
 *  post:
 *      tags: [CafeList-Restaurants]
 *      parameters:
 *       - in: path
 *         name: cafe_list_id
 *         schema:
 *           type: string
 *         required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                         address_1:
 *                            type: string
 *                            default: ''
 *                         address_2:
 *                            type: string
 *                            default: ''
 *                         city:
 *                            type: string
 *                            default: ''
 *                         state:
 *                             type: string
 *                             default: ''
 *                         country:
 *                             type: string
 *                             default: ''
 *                         pin_code:
 *                             type:  string
 *                             default: ''
 *                         latitude:
 *                             type: float
 *                             default: ''
 *                         longitude:
 *                             type: float
 *                             default: ''
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */
router.post("/api/user/admin/restaurant-edit-address-information/:cafe_list_id", auth, Restaurant.AddressInformation)

// router.get("/api/user/admin/restaurant/add/address/info/:cafe_list_id",Restaurant.get_AddressInformation)


/**
 * @swagger
 * /api/user/admin/restaurant-edit-time&price-information/{cafe_list_id}:
 *  post:
 *      tags: [CafeList-Restaurants]
 *      parameters:
 *       - in: path
 *         name: cafe_list_id
 *         schema:
 *           type: string
 *         required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                         opening_time:
 *                            type: string
 *                            default: ''
 *                         closing_time:
 *                            type: string
 *                            default: ''
 *                         cafe_price_range:
 *                            type: double
 *                            default: ''
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */


router.post("/api/user/admin/restaurant-edit-time&price-information/:cafe_list_id", auth, Restaurant.TimePrice)

/**
 * @swagger
 * /api/user/admin/restaurant-edit-socialinfo/{cafe_list_id}:
 *  post:
 *      tags: [CafeList-Restaurants]
 *      parameters:
 *       - in: path
 *         name: cafe_list_id
 *         schema:
 *           type: string
 *         required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          website_url:
 *                               type: string
 *                               default: ''
 *                          social_twitter_url:
 *                            type: string
 *                            default: ''
 *                          social_facebook_url:
 *                               type: string
 *                               default: ''
 *                          social_instagram_url:
 *                               type: string
 *                               default: ''
 *                          social_linkedin_url:
 *                               type: string
 *                               default: ''
 *      responses:
 *          200:
 *              description: Success
 *
 *          default:
 *              description: Default response for this api
 */
router.post("/api/user/admin/restaurant-edit-socialinfo/:cafe_list_id", auth, Restaurant.SocialInformation)

/**
 * @swagger
 * /api/user/admin/restaurant/featured-image/{cafe_list_id}:
 *  post:
 *      tags: [CafeList-Restaurants-FeaturedImage]
 *      summery: Add Featured Image for Restaurants
 *      parameters:
 *       - in: path
 *         name: cafe_list_id
 *         schema:
 *           type: string
 *         required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          cafe_image_name:
 *                              type: string
 *                              default: ''
 *                          image_position:
 *                              type: integer
 *                              default: 1
 *                          server_image_id:
 *                              type: string
 *                              default: ''
 *                          is_featured:
 *                              type: int
 *                              default: ''
 *      responses:
 *          200:
 *              description: Success
 *
 *          default:
 *              description: Default response for this api
 */
router.post("/api/user/admin/restaurant/featured-image/:cafe_list_id", auth, restaurantFeatureImages.addFeaturedImage)

/**
 * @swagger
 * /api/user/admin/restaurant/featured-image/{cafe_gallery_id}:
 *  put:
 *      tags: [CafeList-Restaurants-FeaturedImage]
 *      summery: Update Featured Image of Restaurants
 *      parameters:
 *       - in: path
 *         name: cafe_gallery_id
 *         schema:
 *           type: string
 *         required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          cafe_image_name:
 *                              type: string
 *                              default: ''
 *                          image_position:
 *                              type: int
 *                              default: 1
 *                          is_featured:
 *                              type: int
 *                              default: ''
 *      responses:
 *          200:
 *              description: Success
 *
 *          default:
 *              description: Default response for this api
 */
router.put("/api/user/admin/restaurant/featured-image/:cafe_gallery_id", auth, restaurantFeatureImages.updateFeaturedImage)

/**
 * @swagger
 * /api/user/admin/restaurant/featured-image/{cafe_gallery_id}:
 *  delete:
 *      tags: [CafeList-Restaurants-FeaturedImage]
 *      parameters:
 *       - in: path
 *         name: cafe_gallery_id
 *         schema:
 *           type: string
 *         required: true
 *      responses:
 *          200:
 *              description: Success
 *
 *          default:
 *              description: Default response for this api
 */
router.delete("/api/user/admin/restaurant/featured-image/:cafe_gallery_id", auth, restaurantFeatureImages.deleteFeaturedImage)


/**
 * @swagger
 * /api/user/admin/restaurant-edit-document/{cafe_list_id}:
 *  post:
 *      tags: [CafeList-Restaurants]
 *      parameters:
 *       - in: path
 *         name: cafe_list_id
 *         schema:
 *           type: string
 *         required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          fssai_certificate_url:
 *                               type: string
 *                               default: ''
 *      responses:
 *          200:
 *              description: Success
 *
 *          default:
 *              description: Default response for this api
 */


router.post("/api/user/admin/restaurant-edit-document/:cafe_list_id", auth, Restaurant.document)


/**
 * @swagger
 * /api/user/admin/generalInfoCafe:
 *   get:
 *     tags: [CafeList-Restaurants]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *         required: true
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */
// done
router.get("/api/user/admin/generalInfoCafe", auth, Restaurant.generalInfoCafe)


/**
 * @swagger
 * /api/user/admin/cafe-list/get/all:
 *  get:
 *      tags: [CafeList-Restaurants]
 *      parameters:
 *      - in: query
 *        name: s
 *        schema:
 *          type: string
 *      responses:
 *       200:
 *         description: Success
 *       default:
 *         description: Default responses for this api
 */
router.get('/api/user/admin/cafe-list/get/all', auth, Restaurant.cafeList);

module.exports = router;