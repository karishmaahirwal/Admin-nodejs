const express = require("express")
const menu_addon_price = require("../../controller/Category/menu_addon_price")
const router = express.Router()
const { auth } = require('../../helper/auth')


/**
 * @swagger
 * /api/user/admin/add-menu-addon-price:
 *  post:
 *      summary: Add Menu_addon_price
 *      tags: [Category - menu_addon_price]
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          cafe_list_id:
 *                              type: integer
 *                              default: ""
 *                          menu_addon_id:
 *                              type: integer
 *                              default: ""
 *                          addon_price:
 *                              type: integer
 *                              default: ""
 *                          status:
 *                              type: integer
 *                              default: ""
 * 
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */ 
router.post("/api/user/admin/add-menu-addon-price",auth,menu_addon_price.createmenu_addon_price)
/**
 * @swagger
 * /api/user/admin/get-menuaddonprice-details/{id}:
 *   get:
 *     summary: Get Menu_addon_price
 *     tags: [Category - menu_addon_price ]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */
router.get("/api/user/admin/get-menuaddonprice-details/:id",auth,menu_addon_price.getmenu_addon_priceById)

/**
 * @swagger
 * /api/user/admin/update-menuaddonprice-details/{id}:
 *  put:
 *      summary: Update Menu_addon_price
 *      tags: [Category - menu_addon_price]
 *      parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          cafe_list_id:
 *                              type: integer
 *                          menu_addon_id:
 *                              type: integer
 *                              default: ""
 *                          addon_price:
 *                              type: integer
 *                              default: ""
 *                          status:
 *                              type: integer
 *                              default: ""
 * 
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */
router.put("/api/user/admin/update-menuaddonprice-details/:id",auth,menu_addon_price.updatetMenuAddonById)


/**
 * @swagger
 * /api/user/admin/resturant/page/menu/addon/price:
 *   get:
 *     summary: Get menu_addon_price
 *     tags: [Category - menu_addon_price]
 *     parameters:
 *       - in: query
 *         name: pageno
 *         schema:
 *           type: integer
 *         required: true
 *       - in: query
 *         name: limits
 *         schema:
 *           type: integer
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */


router.get("/api/user/admin/resturant/page/menu/addon/price",auth,menu_addon_price.getAllmenu_addon_pricepage)




module.exports = router


