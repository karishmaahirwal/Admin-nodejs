const express = require("express")
const menu_category = require("../../controller/Category/menu_Category")
const { auth } = require('../../helper/auth')


const router = express.Router()




// menu_category
/**
 * @swagger
 * /api/user/admin/resturant/create/menu:
 *  post:
 *      summary: Create menu_category
 *      tags: [Category - menu_category]
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          category_name:
 *                              type: integer
 *                              default: " "
 *                          category_image_id:
 *                              type: integer
 *                              default: " "
 *                          status:
 *                              type: integer
 *                              default: " "
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */
router.post("/api/user/admin/resturant/create/menu",auth,menu_category.createMenuCategory)

// router.get("/api/user/admin/resturant/get/menu",auth,menu_category.getMenuCategory)

/**
 * @swagger
 * /api/user/admin/get-menucategory/{id}:
 *   get:
 *     summary: Get menu_category by {id}
 *     tags: [Category - menu_category ]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The menu_category was not found
 *
 */

router.get("/api/user/admin/get-menucategory/:id",auth,menu_category.getMenuCategoryById)

/**
 * @swagger
 * /api/user/admin/update-menucategory/{id}:
 *  put:
 *      summary: Update menu_category by {id}
 *      tags: [Category - menu_category]
 *      parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          category_name:
 *                              type: integer
 *                              default: " "
 *                          category_image_id:
 *                              type: integer
 *                              default: " "
 *                          status:
 *                              type: integer
 *                              default: " "
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */

router.put("/api/user/admin/update-menucategory/:id",auth,menu_category.updatetMenuCategoryById)



/**
 * @swagger
 * /api/user/admin/get-menucategory:
 *   get:
 *     summary: Get menu_category
 *     tags: [Category - menu_category ]
 *     parameters:
 *       - in: query
 *         name: pageno
 *         schema:
 *           type: integer
 *         required: true
 *       - in: query
 *         name: limits
 *         schema:
 *           type: integer
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The menu_category was not found
 *
 */



router.get("/api/user/admin/get-menucategory",auth,menu_category.getAllMenuCategorypage)




/**
 * @swagger
 * /api/user/admin/search-menu-category:
 *  get:
 *      tags: [Category - menu_category ]
 *      parameters:
 *      - in: query
 *        name: s
 *        schema: 
 *           type: string
 *      responses: 
 *          200:
 *              description: Success
 *          default: 
 *              description: Default responses for this api
 */
router.get('/api/user/admin/search-menu-category',auth,menu_category.serchMenuCategory)






module.exports = router
