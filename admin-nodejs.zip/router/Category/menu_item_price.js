const express = require("express")
const menu_item_price = require("../../controller/Category/menu_item_price")
const router = express.Router()
const { auth } = require('../../helper/auth')


/**
 * @swagger
 * /api/user/admin/create-menu-item-price:
 *  post:
 *      summary: Create Menu_item_price
 *      tags: [Category - menu_item_price]
 *      requestBody:
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          cafe_list_id:
 *                              type: integer
 *                              default: ""
 *                          menu_category_id:
 *                              type: integer
 *                              default: ""
 *                          menu_item_id:
 *                              type: integer
 *                              default: ""
 *                          menu_addon_id:
 *                              type: integer
 *                              default: "remove menu addon id if you don't want it"
 *                          price:
 *                              type: integer
 *                              default: ""
 *                          status:
 *                              type: integer
 *                              default: ""
 * 
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */
router.post("/api/user/admin/create-menu-item-price",auth,menu_item_price.createMenu_item_price)
/**
 * @swagger
 * /api/user/admin/get-menu-item-price/{id}:
 *   get:
 *     summary: Get Menu_item_price
 *     tags: [Category - menu_item_price ]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */
router.get("/api/user/admin/get-menu-item-price/:id",auth,menu_item_price.gecreateMenu_item_priceById)

/**
 * @swagger
 * /api/user/admin/update-menu-item-price/{id}:
 *  put:
 *      summary: Update Menu_item_price
 *      tags: [Category - menu_item_price]
 *      parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *      requestBody:
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          cafe_list_id:
 *                              type: integer
 *                              default: ""
 *                          menu_category_id:
 *                              type: integer
 *                              default: ""
 *                          menu_item_id:
 *                              type: integer
 *                              default: ""
 *                          menu_addon_id:
 *                              type: integer
 *                              default: ""
 *                          price:
 *                              type: integer
 *                              default: ""
 *                          status:
 *                              type: integer
 *                              default: ""
 * 
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */
router.put("/api/user/admin/update-menu-item-price/:id",auth,menu_item_price.updatetMenuItemById)



/**
 * @swagger
 * /api/user/admin/get-menu-item-price:
 *   get:
 *     summary: Get Menu_item_price
 *     tags: [Category - menu_item_price ]
 *     parameters:
 *     - in: query
 *       name: page
 *       schema:
 *          type: integer
 *       required: true
 *     - in: query
 *       name: limit
 *       schema:
 *          type: integer
 *       required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */
router.get("/api/user/admin/get-menu-item-price",auth,menu_item_price.getAllMenu_item_pricepage)




module.exports = router

