// const express = require("express")
// const qr_code = require("../../controller/Category/qr_code")

// const router = express.Router()
// const { auth } = require('../../helper/auth')

// /**
//  * @swagger
//  * /api/user/admin/resturant/create/qr_code:
//  *  post:
//  *      summary: Create Qr_code
//  *      tags: [Category - Qr_code]
//  *      requestBody:
//  *          required: true
//  *          content:
//  *              application/json:
//  *                  schema:
//  *                      type: object
//  *                      properties:
//  *                          cafe_list_id:
//  *                              type: integer
//  *                          table_number:
//  *                              type: integer
//  *                              default: " "
//  * 
//  *      responses:
//  *          200:
//  *              description: Success
//  *          default:
//  *              description: Default response for this api
//  */

// router.post("/api/user/admin/resturant/create/qr_code",auth,qr_code.createqr_code)

// /**
//  * @swagger
//  * /api/user/admin/resturant/get/qr_code/{id}:
//  *   get:
//  *     summary: Get Qr_code by id
//  *     tags: [Category - Qr_code ]
//  *     parameters:
//  *       - in: path
//  *         name: id
//  *         schema:
//  *           type: string
//  *         required: true
//  *     responses:
//  *       200:
//  *         description: Success
//  *         contents:
//  *           application/json:
//  *       404:
//  *          description: The generalInformation was not found
//  *
//  */

// router.get("/api/user/admin/resturant/get/qr_code/:id",auth,qr_code.getqr_codeById)


// /**
//  * @swagger
//  * /api/user/admin/resturant/update/qr_code/{id}:
//  *  put:
//  *      summary: Update Qr_code by id
//  *      tags: [Category - Qr_code]
//  *      requestBody:
//  *          required: true
//  *          content:
//  *              application/json:
//  *                  schema:
//  *                      type: object
//  *                      properties:
//  *                          cafe_list_id:
//  *                              type: integer
//  *                          table_number:
//  *                              type: integer
//  *                              default: " "
//  * 
//  *      responses:
//  *          200:
//  *              description: Success
//  *          default:
//  *              description: Default response for this api
//  */

// router.put("/api/user/admin/resturant/update/qr_code/:id",auth,qr_code.updatetqr_codeById)


// router.get("/api/user/admin/resturant/get/all/page/limit/qr_code/item/",auth,qr_code.getAllqr_codepage)

// module.exports = router
