const express = require("express")
const menu_addon = require("../../controller/Category/menu_addon")
const router = express.Router()
const { auth } = require('../../helper/auth')


/**
 * @swagger
 * /api/user/admin/create-menu-addon:
 *  post:
 *      summary: Create Menu_addon
 *      tags: [Category - menu_addon]
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          addon_image_id:
 *                              type: string
 *                              default: ""
 *                          Addon_name:
 *                              type: string
 *                              default: ""
 *                          status:
 *                              type: integer
 *                              default: ""
 * 
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */
router.post("/api/user/admin/create-menu-addon",auth,menu_addon.createMenuAddon)
/**
 * @swagger
 * /api/user/admin/get-menu-addon/{id}:
 *   get:
 *     summary: Get menu_addon
 *     tags: [Category - menu_addon ]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */
router.get("/api/user/admin/get-menu-addon/:id",auth,menu_addon.getMenuAddonById)

/**
 * @swagger
 * /api/user/admin/resturant/update/menu/addon/{id}:
 *  put:
 *      summary: Update menu_addon
 *      tags: [Category - menu_addon]
 *      parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          addon_image_id:
 *                              type: string
 *                              default: " "
 *                          addon_name:
 *                              type: string
 *                              default: " "
 *                          status:
 *                              type: integer
 *                              default: " "
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */
router.put("/api/user/admin/resturant/update/menu/addon/:id",auth,menu_addon.updatetMenuAddonById)



/**
 * @swagger
 * /api/user/admin/all-menu-addons:
 *   get:
 *     summary: Get menu_addon
 *     tags: [Category - menu_addon ]
 *     parameters:
 *       - in: query
 *         name: pageno
 *         schema:
 *           type: integer
 *         required: true
 *       - in: query
 *         name: limits
 *         schema:
 *           type: integer
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */

router.get("/api/user/admin/all-menu-addons",auth,menu_addon.getAllMenuAddonspage)

/**
 * @swagger
 * /api/user/admin/search-menu-addon:
 *  get:
 *      tags: [Category - menu_addon ]
 *      parameters:
 *      - in: query
 *        name: s
 *        schema: 
 *           type: string
 *      responses: 
 *          200:
 *              description: Success
 *          default: 
 *              description: Default responses for this api
 */
router.get("/api/user/admin/search-menu-addon",auth,menu_addon.serchMenuAddon)


module.exports = router
