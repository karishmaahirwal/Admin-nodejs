const c = require("config")
const express = require("express")
const menu_item = require("../../controller/Category/menu_Item")
const router = express.Router()
const { auth } = require('../../helper/auth')




/**
 * @swagger
 * /api/user/admin/create-menu-item:
 *  post:
 *      summary: Create Menu_item
 *      tags: [Category - Menu_item]
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          menu_item_name:
 *                              type: string
 *                              default: " "
 *                          item_image_id:
 *                              type: string
 *                              default: " "
 *                          food_type:
 *                              type: integer
 *                              default: " "
 *                          status:
 *                              type: integer
 *                              default: " "
 *                          measure_unit:
 *                              type: string
 *                              default: " "
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */

router.post("/api/user/admin/create-menu-item",auth,menu_item.createMenuItem)

/**
 * @swagger
 * /api/user/admin/get-menu-item/{id}:
 *   get:
 *     summary: Get Menu_item
 *     tags: [Category - Menu_item ]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */

router.get("/api/user/admin/get-menu-item/:id",auth,menu_item.getMenuItemById)
/**
 * @swagger
 * /api/user/admin/update-menu-item/{id}:
 *  put:
 *      summary: Update Menu_item by {id}
 *      tags: [Category - Menu_item]
 *      parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          menu_item_name:
 *                              type: string
 *                              default: " "
 *                          item_image_id:
 *                              type: string
 *                              default: " "
 *                          food_type:
 *                              type: integer
 *                              default: " "
 *                          status:
 *                              type: integer
 *                              default: " "
 *                          measure_unit:
 *                              type: string
 *                              default: " "
 * 
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */

router.put("/api/user/admin/update-menu-item/:id",auth,menu_item.updatetMenuItemById)

// /// This Api is used to show all employee
// /**
//  * @swagger
//  * /api/user/admin/restaurant/employee/get/all/employee:
//  *  get:
//  *      summary: Update Menu_item by {id}
//  *      tags: [Menu_item API's]
//  *      responses:
//  *          default:
//  *              description: Default response for this api
//  */

// router.get("/api/user/admin/resturant/get/all/menu/item", auth,menu_item.getAllMenuItem)



/**
 * @swagger
 * /api/user/admin/get-menu-item:
 *   get:
 *     summary: Get Menu_item
 *     tags: [Category - Menu_item ]
 *     parameters:
 *       - in: query
 *         name: pageno
 *         schema:
 *           type: integer
 *         required: true
 *       - in: query
 *         name: limits
 *         schema:
 *           type: integer
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */

router.get("/api/user/admin/get-menu-item",auth,menu_item.getAllMenuItemspage)

/**
 * @swagger
 * /api/user/admin/search-menu-item:
 *  get:
 *      tags: [Category - Menu_item ]
 *      parameters:
 *      - in: query
 *        name: s
 *        schema:
 *           type: string
 *      responses:
 *         200:
 *             description: Success
 *         default:
 *             description: Default responses for this api
 */
router.get('/api/user/admin/search-menu-item',auth,menu_item.serchMenuItem)
module.exports = router


