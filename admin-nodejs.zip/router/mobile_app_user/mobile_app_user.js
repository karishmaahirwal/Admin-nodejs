const express=require("express")
const Mobile_App_User = require("../../controller/mobile_app_user/mobile_app_user")
const { auth } = require('../../helper/auth')

const router = express.Router()


/**
 * @swagger
 * /api/admin/list-mobile-user:
 *   get:
 *     tags: [Mobile-User    API's]
 *     parameters:
 *       - in: query
 *         name: pageno
 *         schema:
 *           type: integer
 *         required: true
 *       - in: query
 *         name: limits
 *         schema:
 *           type: integer
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */


router.get("/api/admin/list-mobile-user",auth,Mobile_App_User.List_Mobile_App_User)
/**
 * @swagger
 * /order-history/{order_list_id}:
 *   get:
 *     tags: [Mobile-User    API's]
 *     parameters:
 *       - in: path
 *         name: order_list_id
 *         schema:
 *           type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */
 router.get("/order-history/:order_list_id",auth,Mobile_App_User.GetOrderHistory)
/**
 * @swagger
 * /api/admin/customer/profile-dynamic/remove/duplicate:
 *   get:
 *     tags: [Mobile-User    API's]
 *     summery: It will remove the dynamic issues
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */

router.get("/api/admin/customer/profile-dynamic/remove/duplicate", Mobile_App_User.clearCustomerProfileDynamicDuplicateData)

/**
 * @swagger
 * /api/admin/list-mobile-userById/{userId}:
 *   get:
 *     tags: [Mobile-User    API's]
 *     parameters:
 *       - in: path
 *         name: userId
 *         schema:
 *           type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */

router.get("/api/admin/list-mobile-userById/:userId",auth,Mobile_App_User.List_Mobile_App_UserById)


/**
 * @swagger
 * /api/admin/edit-mobile-user/{userId}:
 *  put:
 *      tags: [Mobile-User    API's]
 *      parameters:
 *       - in: path
 *         name: userId
 *         schema:
 *           type: string
 *         required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties: 
 *                         mobile_number:
 *                            type: int
 *                            default: ''
 *                         email:
 *                            type: string
 *                            default: ''
 *                         status:
 *                            type: int
 *                            default: ''
 *                         gender:
 *                            type: string  
 *                            default: ''
 *                         date_of_birth:
 *                            type: date
 *                            default: ''
 *                         first_name:
 *                            type: string
 *                            default: ''
 *                         last_name:
 *                            type: string
 *                            default: ''
 *                         profile_pic_image_id:
 *                            type: string
 *                            default: ''
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */

router.put("/api/admin/edit-mobile-user/:userId",auth,Mobile_App_User.Edit_Mobile_App_User)

/**
 * @swagger
 * /api/admin/create-mobile-user:
 *  post:
 *      tags: [Mobile-User    API's]
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties: 
 *                         mobile_number:
 *                            type: int
 *                            default: ''
 *                         email:
 *                            type: string
 *                            default: ''
 *                         status:
 *                            type: int
 *                            default: ''
 *                         gender:
 *                            type: string  
 *                            default: ''
 *                         date_of_birth:
 *                            type: date
 *                            default: ''
 *                         first_name:
 *                            type: string
 *                            default: ''
 *                         last_name:
 *                            type: string
 *                            default: ''
 *                         profile_pic_image_id:
 *                            type: string
 *                            default: ''
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 */

router.post("/api/admin/create-mobile-user",auth,Mobile_App_User.Create_Mobile_App_User)

/**
 * @swagger
 * /api/admin/customer/order-history/{userId}:
 *   get:
 *     tags: [Mobile-User    API's]
 *     parameters:
 *       - in: path
 *         name: userId
 *         schema:
 *           type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */


router.get("/api/admin/customer/order-history/:userId",auth,Mobile_App_User.orderHistory)

/**
 * @swagger
 * /api/admin/customer/order-history/get/all:
 *   get:
 *     tags: [Mobile-User    API's]
 *     parameters:
 *       - in: query
 *         name: userId
 *         schema:
 *           type: string
 *         required: false
 *       - in: query
 *         name: pageNo
 *         schema:
 *           type: string
 *         required: false
 *         default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: string
 *         required: false
 *         default: 10
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */


router.get("/api/admin/customer/order-history/get/all",auth,Mobile_App_User.orderHistoryAll)

// /**
//  * @swagger
//  * /api/admin/customer/order-review/{userId}:
//  *   get:
//  *     tags: [Mobile-User    API's]
//  *     parameters:
//  *       - in: path
//  *         name: userId
//  *         schema:
//  *           type: string
//  *         required: true
//  *     responses:
//  *       200:
//  *         description: Success
//  *         contents:
//  *           application/json:
//  *       404:
//  *          description: The generalInformation was not found
//  *
//  */

// router.get("/api/admin/customer/order-review/:userId",auth,Mobile_App_User.orderReview);


/**
 * @swagger
 * /api/admin/customer/order-review/get/all:
 *   get:
 *     tags: [Mobile-User    API's]
 *     summery: Get all user order reviews
 *     parameters:
 *       - in: query
 *         name: userId
 *         schema:
 *           type: string
 *         required: false
 *       - in: query
 *         name: pageNo
 *         schema:
 *           type: string
 *         required: false
 *         default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: string
 *         required: false
 *         default: 10
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */

router.get("/api/admin/customer/order-review/get/all",auth,Mobile_App_User.orderReviewAll);

/**
 * @swagger
 * /admin/customer/get/all:
 *  get:
 *      tags: [Mobile-User    API's]
 *      parameters:
 *      - in: query
 *        name: s
 *        schema: 
 *           type: string
 *      responses: 
 *          200:
 *              description: Success
 *          default: 
 *              description: Default responses for this api
 */
router.get("/admin/customer/get/all",auth,Mobile_App_User.serchMobileAppUser)
/**
 * @swagger
 * /order-review/{review_id}:
 *   get:
 *     tags: [Mobile-User    API's]
 *     parameters:
 *       - in: path
 *         name: review_id
 *         schema:
 *           type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *         contents:
 *           application/json:
 *       404:
 *          description: The generalInformation was not found
 *
 */
router.get("/order-review/:review_id",auth,Mobile_App_User.getReviewById)

/**
 * @swagger
 * /edit-review/{order_review_id}:
 *  put:
 *      summary: edit review
 *      tags: [Mobile-User    API's]
 *      parameters:
 *      - name: order_review_id
 *        description: order review id
 *        in: path
 *        default: 1
 *        required: true
 *      requestBody:
 *          required: true
 *          content:
 *             application/json:
 *               schema:
 *                 type: object
 *                 properties:
 *                    experience_rating:
 *                       type: string
 *                       default: ""
 *                    review_detail:
 *                       type: string
 *                       default: ""
 *                    is_featured:
 *                       type: string
 *                       default: ""
 *      responses:
 *         200:
 *             description: Success
 *         default:
 *             description: Default responses for this api 
 */
router.put('/edit-review/:order_review_id',auth,Mobile_App_User.editReview);

module.exports = router
