const express=require("express")
const Employees = require("../../controller/Employees/employee")
const { auth } = require('../../helper/auth')

const router = express.Router()




/**
 * @swagger
 * /api/user/admin/create-employee:
 *  post:
 *      tags: [Emloyees API's]
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          user_role_id:
 *                              type: string
 *                              default: ""
 *                          first_name:
 *                              type: string
 *                              default: ""
 *                          last_name:
 *                              type: string
 *                              default: ""
 *                          cafe_list_id:
 *                              type: string
 *                              default: ""
 *                          mobile_number:
 *                              type: string
 *                              default: ""
 *                          email:
 *                              type: string
 *                              default: ""
 *                          status:
 *                              type: integer
 *                              default: ""
 *                          photo_proof_id_url:
 *                              type: string
 *                              default: ""
 *                          address_proof_id_url:
 *                              type: string
 *                              default: ""
 *                          profile_pic_image_id:
 *                              type: string
 *                              default: ""
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 * 
 */
router.post("/api/user/admin/create-employee",auth,Employees.AddEmployee)

/// This Api is used to show all employee
/**
 * @swagger
 * /api/user/admin/get-all-employee:
 *  get:
 *      tags: [Emloyees API's]
 *      parameters:
 *       - in: query
 *         name: pageno
 *         schema:
 *           type: integer
 *         required: true
 *       - in: query
 *         name: limits
 *         schema:
 *           type: integer
 *         required: true
 *      responses:
 *          default:
 *              description: Default response for this api
 */
router.get("/api/user/admin/get-all-employee",auth,Employees.GetEmployees)


/**
 * @swagger
 * /api/user/admin/get-employee/{id}:
 *  get:
 *      summary: Get category details by id
 *      tags: [Emloyees API's]
 *      parameters:
 *      - name: id
 *        in: path
 *        description: Emloyees Id
 *        required: true
 *        default: 1
 *        schema:
 *          type: integer
 *          format: int64
 *      responses:
 *          200:
 *              description: Success
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/SuccessResponse'
 *          404:
 *              description: Emloyees not found with this id
 *          default:
 *              description: Default response for this api
 */
router.get("/api/user/admin/get-employee/:id",auth,Employees.GetEmployeesById)

/**
 * @swagger
 * /api/user/admin/update-employee/{id}:
 *  put:
 *      tags: [Emloyees API's]
 *      parameters:
 *      - name: id
 *        in: path
 *        description: Emloyees Id
 *        required: true
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          user_role_id:
 *                              type: string
 *                              default: ""
 *                          first_name:
 *                              type: string
 *                              default: ""
 *                          last_name:
 *                              type: string
 *                              default: ""
 *                          cafe_list_id:
 *                              type: string
 *                              default: ""
 *                          mobile_number:
 *                              type: string
 *                              default: ''
 *                          email:
 *                              type: string
 *                              default: ""
 *                          photo_proof_id_url:
 *                              type: string
 *                              default: ""
 *                          address_proof_id_url:
 *                              type: string
 *                              default: ""
 *                          profile_pic_image_id:
 *                              type: string
 *                              default: ""
 *      responses:
 *          200:
 *              description: Success
 *          default:
 *              description: Default response for this api
 * 
 */
router.put("/api/user/admin/update-employee/:id",auth,Employees.UpdateEmployeeById)
// /**
//  * @swagger
//  * /api/user/owner/restaurant/employee/get/all/employee/{cafe_list_id}:
//  *  get:
//  *      summary: Get category details by cafe_list_id
//  *      tags: [Emloyees API's]
//  *      parameters:
//  *      - name: cafe_list_id
//  *        in: path
//  *        description: Emloyees Id
//  *        required: true
//  *        default: 1
//  *        schema:
//  *          type: integer
//  *          format: int64
//  *      responses:
//  *          200:
//  *              description: Success
//  *              content:
//  *                  application/json:
//  *                      schema:
//  *                          $ref: '#/components/schemas/SuccessResponse'
//  *          404:
//  *              description: Emloyees not found with this cafe_list_id
//  *          default:
//  *              description: Default response for this api
//  */
// router.get ("/api/user/owner/restaurant/employee/get/all/employee/:cafe_list_id",auth,Employees.GetEmployeesCafeId)


// /**
//  * @swagger
//  * /api/admin/inquiry/{cafe_list_id}/{id}:
//  *  get:
//  *      tags: [Emloyees API's]
//  *      parameters:
//  *      - name: cafe_list_id
//  *        in: path
//  *        description: id
//  *        default: 1
//  *        required: true
//  *      - name: packageId
//  *        in: path
//  *        description: id
//  *        default: 1
//  *        required: true
//  *      responses:
//  *          200:
//  *              description: Success
//  *          default:
//  *              description: Default response for this api
//  */
// router.get ("/api/user/owner/restaurant/employee/get/all/employee/:cafe_list_id/:id",auth,Employees.GetEmployeesCafeIdEmpId)

// router.post('/api/admin/upload-profileImage',auth,Employees.uploadImage)


/**
 * @swagger
 * /api/user/employee/set-password:
 *  post:
 *      summary: Set Password Admin
 *      tags: [Emloyees API's]
 *      requestBody:
 *          required: true
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          email:
 *                              type: string
 *                              default: ''
 *      responses:
 *          200:
 *              description: Success
 * 
 *              content:
 *                  application/json:
 *                      schema:
 *                          $ref: '#/components/schemas/SuccessResponse'
 *          default:
 *              description: Default response for this api
 */


 router.post("/api/user/employee/set-password",Employees.sendVerification)

module.exports = router

