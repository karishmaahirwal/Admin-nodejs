const knex = require("../../db/db_knex")
const helper = require("../../helper/helper")
const baseResponse = require("../../helper/baseResponse")
const br = require("../../helper/baseResponse");

const { Validator } = require('node-input-validator');


// const uploadMenuImage = (req,res)=>{
//     const user = {
//         category_image_id:category_image_id.fileupload
//     }
//     console.log(user)
//     knex("menu_category").select("*").insert(user)
//     .then((data)=>{
//         res.statu(200).send({message:'image uploaded succesfully'})
//     })
//     .catch((err)=>{
//         if(err){
//         console.log(err)
//         res.status(400).send({error:err })
//         }
       

//     })
// }


// name
// category_image_id

const createMenuCategory =  (req, res) => {
    try{
        const v = new Validator(req.body, {
            category_name: 'required|minLength:3',
            category_image_id : 'required',
            status : 'required',
        });

        v.check().then((matched) => {
            if(!matched){
                res.status(422).send(baseResponse.withError('Missed Required files', v.errors));
            }else{
            knex.select('*').from('menu_category')  
                .then((data) => {
                    if (data.length > 0) {
                        let user = {
                            category_name: req.body.category_name,
                            category_image_id: req.body.category_image_id,
                            status: req.body.status,
                };
                        knex('menu_category').insert(user).then((data) => {
                            (async()=>{
                                await axios.post('https://auto.a2deats.com/webhook/defb6cb4-d6ec-49f9-9522-d2418cc1e1f7', {
                                    id:data[0].toString()
                                 })
                            })();
                            res.status(200).send(baseResponse.withSuccess('menu_category Data Created', data[0]))
                            console.log("menu_category Data Created")
                        }).catch((err) => {
                            res.status(500).send(err.message);
                            console.log(err.message);
                        })
                    } else {
                        res.status(400).send(baseResponse.withError('menu_category data not found!'));
                        console.log('menu_category data not found');
                    }
                }).catch((err) => {
                    console.error({ "error": err });
                    res.status(500).send(err.message)
                    console.log(err.message);
                })
}
});
    }catch (e) {
        console.log(e);
        res.status(500).send(baseResponse.withError(''));
    }
}


// getMenuCategory
const getMenuCategory = (req,res)=>{
    knex.select("*").from("menu_category").then((data) =>{
    res.status(200).send(baseResponse.withSuccess("all Menu Category ", data))
    console.log(data);
    }).catch((err)=>{
       res.status(500).send(err.message)
        console.log(err.message);
    })
}


// GetMenuById
const getMenuCategoryById = (req,res)=>{
    try{
        knex.select("*").from("menu_category")
        .where({id : req.params.id})
        .then((data)=>{
            if(data.length > 0){
                res.status(200).send(baseResponse.withSuccess("menu_category Details", data[0]))
                console.log(data[0]);
            }else{
                res.status(404).send(baseResponse.withError("menu_category not found"));
            }
        }).catch((err) => {
            res.status(500).send(err.message)
            console.log(err.message);
        })
    }catch(e){
        console.log(e)
        res.status(500).send(baseResponse.withError(''));

    }
    
}



const updatetMenuCategoryById = (req,res)=>{
    try{
        const v = new Validator(req.body, {
            category_name: 'required|minLength:3',
            category_image_id : 'required',
            status : 'required'
        });
            v.check().then((matched) => {
                if(!matched){
                    res.status(422).send(baseResponse.withError('Missed Required files', v.errors));
                }else{
                    let id  = parseInt(req.params.id)
            if(id > 0){
                knex.select('*').from('menu_category')
                    .where('id', id)
                    .then((data) => {
                        if (data.length > 0) {
                                let user = {
                                    category_name: req.body.category_name,
                                    category_image_id: req.body.category_image_id,
                                    status: req.body.status,
                               };
                            knex('menu_category').update(user).where('id', id).then((data) => {
                                res.status(200).send(baseResponse.withSuccess('menu_category Data updated', data[0]))
                            }).catch((err) => {
                                res.status(500).send(err.message);
                                console.log(err.message);
                            })
                        } else {
                            res.status(400).send(baseResponse.withError('menu_category data not found!'));
                            console.log('menu_category data not found');
                        }
                    }).catch((err) => {
                        console.error({ "error": err });
                        res.status(500).send(err.message)
                        console.log(err.message);
                    })
              }
              else{
                baseResponse.sendError(res, {}, 'invalid  id');
              }
    }
    });
        }catch (e) {
            console.log(e);
            res.status(500).send(baseResponse.withError('Internal server error'));
        }
    }
    



// getAllMenuCategorypage

function paginate(arr, page, pageSize) {
    return arr.slice(pageSize * (page - 1), pageSize * page);
  }
  
const getAllMenuCategorypage =async (req, res) => {
    try{
        let pageno = req.query.pageno;
        let limits = req.query.limits;
        if(!limits){
            limits=10;
        }
        if ( !pageno ) {
            pageno = 0;
        }
        else {
            pageno = pageno - 1;
        }

       knex("menu_category").select("*").limit(limits).offset(pageno*limits)
       .then((data)=>{
        (async () => {
            let getCountOfMenuCategory= await knex('menu_category').count('id as cnt')
            let counting={
                'cnt':getCountOfMenuCategory[0].cnt
                }
            console.log(counting.cnt,"hi")
            res.status(200).send({status:true,msg:"menu category list",TOTALCOUNTOFCATEGORY:counting.cnt,data})
        })();
          //res.status(200).send(baseResponse.withSuccess("Menu Category Details", data))
            
        }).catch((err)=>{
            if(err){
                console.log(err)
                res.status(400).send({error:err})
            }
        })
    
    }catch (e) {
        console.log( e );
        res.status( 500 ).send( baseResponse.withError( 'Internal server error' ) );
        }
};


const serchMenuCategory = async function (req, res) {
    try {
        let s = req.query.s;
        if (s === undefined) {
            s = '';
        }

        let getList = knex.select('menu_category.id', 'menu_category.category_name')
            .from('menu_category');

        if (s.length > 0) {
            getList.where('menu_category.category_name', 'like', `${s}%`);
        }

        getList = await getList;

        if (!getList > 0) {
            br.sendError(res, {}, "no data found", 404);
        } else {
            br.sendSuccess(res, getList, 'All menu category list');
        }
    } catch (error) {
        br.sendDatabaseError(res, error);
    }
}





module.exports  = {
    // uploadMenuImage,
    createMenuCategory,
    getMenuCategory,
    getMenuCategoryById,
    updatetMenuCategoryById,
    getAllMenuCategorypage,
    serchMenuCategory


    

    
}

