const knex = require( "../../db/db_knex" );
const baseResponse = require( "../../helper/baseResponse" );
const helper = require( "../../helper/helper" )
const { Validator } = require( 'node-input-validator' );
const br = require("../../helper/baseResponse");


const createMenuAddon = ( req, res ) => {
    try {
        const v = new Validator( req.body, {
            Addon_name: 'required|minLength:3',
            addon_image_id: 'required',
            status: 'required'
        } );

        v.check().then( ( matched ) => {
            if ( !matched ) {
                res.status( 422 ).send( baseResponse.withError( 'Missed Required files', v.errors ) );
            } else {

                let obj = {
                    Addon_name: req.body.Addon_name,
                    addon_image_id: req.body.addon_image_id,
                    status: req.body.status,
                }
                knex( 'menu_addon' ).insert( obj ).then( ( data ) => {
                    (async()=>{
                        await axios.post('https://auto.a2deats.com/webhook/ce1a5426-ea1f-4bc0-92cb-dc5df2438112', {
                            id:data[0].toString()
                         })
                    })();
                    res.status( 200 ).send( baseResponse.withSuccess( 'Menu Addon created', data ) )
                } )
                    .catch( ( err ) => {
                        console.error( { "error": err } );
                        res.status( 500 ).send( err.message )
                        console.log( err.message );
                    } )
            }
        } );
    } catch ( e ) {
        console.log( e );
        res.status( 500 ).send( baseResponse.withError( 'Internal server error' ) );
    }
}



const getMenuAddonById = ( req, res ) => {
    try {
        knex.select( '*' )
            .from( 'menu_addon' )
            .where( { id: req.params.id } )
            .then( ( data ) => {
                //console.log(data);
                if ( data.length > 0 ) {
                    res.status( 200 ).send( baseResponse.withSuccess( "menu_addon Details", data[0] ) )
                    console.log( data[0] );
                } else {
                    res.status( 404 ).send( baseResponse.withError( "menu_addon not found" ) );
                }
            } ).catch( ( err ) => {
                res.status( 500 ).send( err.message )
                console.log( err.message );
            } );
    } catch ( e ) {
        console.log( e );
        res.status( 500 ).send( baseResponse.withError( 'Internal server error' ) );
    }
}




// Update Menu addon Details
const updatetMenuAddonById = ( req, res ) => {
    try {
        const v = new Validator( req.body, {
            addon_name: 'required|minLength:3',
            addon_image_id: 'required',
            status: 'required'
        } );
        v.check().then( ( matched ) => {
            if ( !matched ) {
                res.status( 422 ).send( baseResponse.withError( 'Missed Required files', v.errors ) );
            } else {
                let id = parseInt( req.params.id );
                if ( id > 0 ) {
                    knex.select( '*' ).from( 'menu_addon' )
                        .where( 'id', id )
                        .then( ( data ) => {
                            if ( data.length > 0 ) {
                                let user = {
                                    Addon_name: req.body.addon_name,
                                    addon_image_id: req.body.addon_image_id,
                                    status: req.body.status,
                                };
                                knex( 'menu_addon' ).update( user ).where( 'id', id ).then( ( data ) => {
                                    res.status( 200 ).send( baseResponse.withSuccess( 'menu_addon Data updated', data[0] ) )
                                } ).catch( ( err ) => {
                                    res.status( 500 ).send( err.message );
                                    console.log( err.message );
                                } )
                            } else {
                                res.status( 400 ).send( baseResponse.withError( 'menu_addon data not found!' ) );
                                console.log( 'menu_addon data not found' );
                            }
                        } ).catch( ( err ) => {
                            console.error( { "error": err } );
                            res.status( 500 ).send( err.message )
                            console.log( err.message );
                        } )
                }
                else {
                    baseResponse.sendError( res, {}, 'invalid menu_addon id' );
                }
            }
        } );
    } catch ( e ) {
        console.log( e );
        res.status( 500 ).send( baseResponse.withError( 'Internal server error' ) );
    }
}

function paginate( arr, page, pageSize ) {
    return arr.slice( pageSize * ( page - 1 ), pageSize * page );
}

const getAllMenuAddonspage = async ( req, res ) => {
    try {
        let pageno = req.query.pageno;
        let limits = req.query.limits;
        if(!limits){
            limits=10;
        }
        if ( !pageno ) {
            pageno = 0;
        }
        else {
            pageno = pageno - 1;
        }
        knex( "menu_addon" ).select( "*" ).limit( limits ).offset(pageno*limits)
            .then( ( data ) => {
                (async () => {
                    let getCountOfMenuAddon= await knex('menu_addon').count('id as cnt')
                    let counting={
                        'cnt':getCountOfMenuAddon[0].cnt
                        }
                    console.log(counting.cnt,"hi")
                    res.status(200).send({status:true,msg:"menu addon list",TOTALCOUNTOFADDON:counting.cnt,data})
                })();

                
                //res.status(200).send(baseResponse.withSuccess("All Addon Details", data))

            } ).catch( ( err ) => {
                if ( err ) {
                    console.log( err )
                    res.status( 400 ).send( { error: err } )
                }
            } )

    } catch ( e ) {
        console.log( e );
        res.status( 500 ).send( baseResponse.withError( 'Internal server error' ) );
    }
};

const serchMenuAddon = async function (req, res) {
    try {
        let s = req.query.s;
        if (s === undefined) {
            s = '';
        }

        let getList = knex.select('menu_addon.id', 'menu_addon.Addon_name')
            .from('menu_addon');

        if (s.length > 0) {
            getList.where('menu_addon.Addon_name', 'like', `${s}%`);
        }

        getList = await getList;

        if (!getList > 0) {
            br.sendError(res, {}, "no data found", 404);
        } else {
            br.sendSuccess(res, getList, 'All menu addon list');
        }
    } catch (error) {
        br.sendDatabaseError(res, error);
    }
}



module.exports = {
    createMenuAddon,
    updatetMenuAddonById,
    getMenuAddonById,
    getAllMenuAddonspage,
    serchMenuAddon

}