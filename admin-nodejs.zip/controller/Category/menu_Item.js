const knex = require( "../../db/db_knex" )
const helper = require( "../../helper/helper" )
const { Validator } = require( 'node-input-validator' );
const baseResponse = require( "../../helper/baseResponse" );
const br = require("../../helper/baseResponse");

const createMenuItem = ( req, res ) => {
    try {
        const v = new Validator( req.body, {
            menu_item_name: 'required|minLength:3',
            item_image_id: 'required',
            food_type: 'required',
            status: 'required',
            measure_unit: 'required',
        } );

        v.check().then( ( matched ) => {
            if ( !matched ) {
                res.status( 422 ).send( baseResponse.withError( 'Missed Required files', v.errors ) );
            } else {
                knex.select( '*' ).from( 'menu_item' )
                    .then( ( data ) => {
                        if ( data.length > 0 ) {
                            let user = {
                                menu_item_name: req.body.menu_item_name,
                                item_image_id: req.body.item_image_id,
                                food_type: req.body.food_type,
                                status: req.body.status,
                                measure_unit: req.body.measure_unit,
                            };
                            knex( 'menu_item' ).insert( user ).then( ( data ) => {
                                (async()=>{
                                    await axios.post('https://auto.a2deats.com/webhook/89dfae41-1dff-4a3a-9f32-a33321f8ea90', {
                                        id:data[0].toString()
                                     })
                                })();
                                res.status( 200 ).send( baseResponse.withSuccess( 'menuItem Data Created', data[0] ) )
                                console.log( "menuItem Data Created" )
                            } ).catch( ( err ) => {
                                res.status( 500 ).send( err.message );
                                console.log( err.message );
                            } )
                        } else {
                            res.status( 400 ).send( baseResponse.withError( 'menuItem data not found!' ) );
                            console.log( 'menuItem data not found' );
                        }
                    } ).catch( ( err ) => {
                        console.error( { "error": err } );
                        res.status( 500 ).send( err.message )
                        console.log( err.message );
                    } )
            }
        } );
    } catch ( e ) {
        console.log( e );
        res.status( 500 ).send( baseResponse.withError( '' ) );
    }
}



const getMenuItemById = ( req, res ) => {
    try {
        knex.select( "*" ).from( "menu_item" )
            .where( { id: req.params.id } )
            .then( ( data ) => {
                if ( data.length > 0 ) {
                    res.status( 200 ).send( baseResponse.withSuccess( "menu_item Details", data[0] ) )
                    console.log( data[0] );
                } else {
                    res.status( 404 ).send( baseResponse.withError( "menu_item not found" ) );
                }
            } ).catch( ( err ) => {
                res.status( 500 ).send( err.message )
                console.log( err.message );
            } )
    } catch ( e ) {
        console.log( e )
        res.status( 500 ).send( baseResponse.withError( 'Internal server error' ) );

    }

}


const getAllMenuItem = async ( req, res ) => {

    knex( "menu_item" ).select( "*" )
        .then( ( row ) => {
            res.send( { MenuCollectionitem: row, Statu: true } )
        } )
        .catch( ( err ) => {
            res.json( { message: error.message, status: false } )
        } )
}

function paginate( arr, page, pageSize ) {
    return arr.slice( pageSize * ( page - 1 ), pageSize * page );
}

const getAllMenuItemspage = async ( req, res ) => {
    try {
        let pageno = req.query.pageno;
        let limits = req.query.limits;
        if ( !limits ) {
            limits = 10;
        }
        if ( !pageno ) {
            pageno = 0;
        }
        else {
            pageno = pageno - 1;
        }

        // knex("menu_item").select("*").limit(limit).skip(skip)
        knex( "menu_item" ).select( "*" ).limit( limits ).offset( pageno * limits )
            .then( ( data ) => {
                (async () => {
                    let getCountOfMenuItem= await knex('menu_item').count('id as cnt')
                    let counting={
                        'cnt':getCountOfMenuItem[0].cnt
                        }
                    console.log(counting.cnt,"hi")
                    res.status(200).send({status:true,msg:"menu item list",TOTALCOUNTOFMENUITEMS:counting.cnt,data})
                })();

                //res.status( 200 ).send( baseResponse.withSuccess( "Menu item Details", data ) )
            } ).catch( ( err ) => {
                if ( err ) {
                    console.log( err )
                    res.status( 400 ).send( { error: err } )
                }
            } )

    } catch ( error ) {
        console.log( e );
        res.status( 500 ).send( baseResponse.withError( 'Internal server error' ) );
    }
};





// Update Menu Item Details

const updatetMenuItemById = ( req, res ) => {
    try {
        const v = new Validator( req.body, {
            menu_item_name: 'required|minLength:3',
            item_image_id: 'required',
            food_type: 'required',
            status: 'required',
            measure_unit: 'required',
        } );
        v.check().then( ( matched ) => {
            if ( !matched ) {
                res.status( 422 ).send( baseResponse.withError( 'Missed Required files', v.errors ) );
            } else {
                let id = parseInt( req.params.id );
                if ( id > 0 ) {
                    knex.select( '*' ).from( 'menu_item' )
                        .where( 'id', id )
                        .then( ( data ) => {
                            if ( data.length > 0 ) {
                                let user = {
                                    menu_item_name: req.body.menu_item_name,
                                    item_image_id: req.body.item_image_id,
                                    food_type: req.body.food_type,
                                    status: req.body.status,
                                    measure_unit: req.body.measure_unit,
                                };
                                knex( 'menu_item' ).update( user ).where( 'id', id ).then( ( data ) => {
                                    res.status( 200 ).send( baseResponse.withSuccess( 'menu_item Data updated', data[0] ) )
                                } ).catch( ( err ) => {
                                    res.status( 500 ).send( err.message );
                                    console.log( err.message );
                                } )
                            } else {
                                res.status( 400 ).send( baseResponse.withError( 'menu_item data not found!' ) );
                                console.log( 'menu_item data not found' );
                            }
                        } ).catch( ( err ) => {
                            console.error( { "error": err } );
                            res.status( 500 ).send( err.message )
                            console.log( err.message );
                        } )
                }
                else {
                    baseResponse.sendError( res, {}, 'invalid menu_item  id' );
                }
            }
        } );
    } catch ( e ) {
        console.log( e );
        res.status( 500 ).send( baseResponse.withError( 'Internal server error ' ) );
    }
}




const serchMenuItem = async function (req, res) {
    try {
        let s = req.query.s;
        if (s === undefined) {
            s = '';
        }

        let getList = knex.select('menu_item.id', 'menu_item.menu_item_name')
            .from('menu_item');

        if (s.length > 0) {
            getList.where('menu_item.menu_item_name', 'like', `${s}%`);
        }

        getList = await getList;

        if (!getList > 0) {
            br.sendError(res, {}, "no data found", 404);
        } else {
            br.sendSuccess(res, getList, 'All menu item list');
        }
    } catch (error) {
        br.sendDatabaseError(res, error);
    }
}

module.exports = {
    createMenuItem,
    getMenuItemById,
    updatetMenuItemById,
    getAllMenuItem,
    getAllMenuItemspage,
    serchMenuItem

}