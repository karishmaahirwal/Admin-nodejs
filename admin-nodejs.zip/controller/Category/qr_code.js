const knex = require("../../db/db_knex")
const helper = require("../../helper/helper")
const qr = require("qrcode");


const baseResponse = require("../../helper/baseResponse")
const { Validator } = require('node-input-validator');


// qr_id


const createqr_code = async(req,res) => {
    function between(min, max) {  
        return Math.floor(
          Math.random() * (max - min + 1) + min
        )
      }
        
let randomId = between(1,10000);
// let stJson = JSON.stringify(data);
    try{
        const v = new Validator(req.body,{
            cafe_list_id:"required|integer",
            table_number: 'required'
        });
        v.check().then((matched) =>{
            if(!matched){
                res.status(422).send(baseResponse.withError('Missed Required files', v.errors));
            }else{
                knex.select('*').from('qr_code')
                .then((data) => {
                    
                    if (data.length > 0) {
                        let user = {
                            cafe_list_id:req.body. cafe_list_id,
                            table_number:req.body.table_number,
                        }
                        let stJson = JSON.stringify(user);
                        knex('qr_code').insert(user).then((data) => {

                            qr.toFile(`qr${randomId}.png`,stJson,function(err,code){
                                if(err) return console.log('error');
                            })

                            res.status(200).send(baseResponse.withSuccess(' Data Created', data[0]))
                            console.log(" Data Created")
                        }).catch((err) => {
                            res.status(500).send(err.message);
                            console.log(err.message);
                        })
                    }else{
                        res.status(400).send(baseResponse.withError(' data not found!'));
                        console.log(' data not found');
                    }
                }).catch((err) => {
                    console.error({ "error": err });
                    res.status(500).send(err.message)
                    console.log(err.message);
                })
            }
        })
    }catch (e) {
        console.log(e);
        res.status(500).send(baseResponse.withError(''));
    }
}
  



const updatetqr_codeById = (req,res)=>{
try{
    let id = parseInt(req.params.id);
     const v = new Validator(req.body,{
        cafe_list_id:"required|integer",
        table_number: 'required'
        
    })
    v.check().then((matched) => {
            if(!matched){
                res.status(422).send(baseResponse.withError('Missed Required files', v.errors));
            }else{
                let id  = parseInt(req.params.id)
        if(id > 0){
            knex.select('*').from('user_admin')
                .where('id', id)
                .then((data) => {
                    if (data.length > 0) {
                        let updateData = {
                            cafe_list_id:req.body. cafe_list_id,
                            table_number:req.body.table_number,
                };
                        knex('qr_code').update(updateData).where('id', id).then((data) => {
                            res.status(200).send(baseResponse.withSuccess(' qr_code updated  successfully By Id', data[0]))
                        }).catch((err) => {
                            res.status(500).send(err.message);
                            console.log(err.message);
                        })
                    } else {
                        res.status(400).send(br.withError('qr_code data not found!'));
                        console.log('qr_code data not found');
                    }
                }).catch((err) => {
                    console.error({ "error": err });
                    res.status(500).send(err.message)
                    console.log(err.message);
                })
            }
         else{
                baseResponse.sendError(res, {}, 'invalid form id');
        }
    }
})

}catch (e) {
    console.log(e);
    res.status(500).send(baseResponse.withError(''));
}
}


// Update Menu addon Details
const getqr_codeById = async(req,res)=>{
    try{
        //console.log(req.params.id);
        knex.select('*')
            .from('qr_code')
            .where({id : req.params.id})
            .then((data) => {
                //console.log(data);
                if(data.length > 0){
                    res.status(200).send(baseResponse.withSuccess("qr_code Details", data[0]))
                    console.log(data[0]);
                }else{
                    res.status(404).send(baseResponse.withError("qr_code not found"));
                }
            }).catch((err) => {
            res.status(500).send(err.message)
            console.log(err.message);
        });
    }catch (e) {
        console.log(e);
        res.status(500).send(baseResponse.withError(''));
    }
}






function paginate(arr, page, pageSize) {
    return arr.slice(pageSize * (page - 1), pageSize * page);
  }
  
const getAllqr_codepage =async (req, res) => {
    try{
        let { page, size } = req.params;
      
        if (!page) {
            page = 1;

        }
        if (!size) {
            size = 10;
        }
        const limit = parseInt(size);
        const offset = (page - 1) * size;

        // knex("menu_item").select("*").limit(limit).skip(skip)
       knex("qr_code").select("*").limit(limit).offset(offset)
       .then((row)=>{
            res.send({page, size, limit , offset , Info: row , status: true})
            
        }).catch((err)=>{
            if(err){
                console.log(err)
                res.status(400).send({error:err})
            }
        })
    
    }catch (error) {
        res.sendStatus(500);
        }
};
  




module.exports = {
    createqr_code,
    updatetqr_codeById,
    getqr_codeById,
    getAllqr_codepage
    
}