const knex = require( "../../db/db_knex" )
const helper = require( "../../helper/helper" )
const { Validator } = require( 'node-input-validator' );
const baseResponse = require( "../../helper/baseResponse" );






// const createMenu_item_price= async function(req,res){
//     try{
//         let cafe_list_id=req.body.cafe_list_id;
//         let menu_category_id=req.body.menu_category_id;
//         let menu_item_id=req.body.menu_item_id;
//         let menu_addon_id=req.body.menu_addon_id;
//         let price=req.body.price;
//         let status= req.body.status;
//         let item_image_id=req.body.item_image_id;
//         let measure_unit=req.body.measure_unit;
//         let average_rating=req.body.average_rating;

//         let payload1={
//             'cafe_list_id':cafe_list_id,
//             'menu_category_id':menu_category_id,
//             'menu_item_id':menu_item_id,
//             'menu_addon_id':menu_addon_id,
//             'price':price,
//             'status':status,
//             'average_rating':average_rating
//         }
//         let addmenuItemPrice= await knex('menu_item_price').insert(payload1)

//         let payload2={
             
//         }
        
//         }
//     catch(error){
//         console.log(error)
//         return res.status(500).send({status:false,ERROR:error})
//     }
// }
const createMenu_item_price= async function(req,res){
    try{
          let cafe_list_id= parseInt(req.body.cafe_list_id);
          if(!cafe_list_id>0) return res.status(400).send({status:false,msg:" please enter a valid cafe list id"})
          let menu_category_id= parseInt(req.body.menu_category_id);
          if(!menu_category_id>0) return res.status(400).send({status:false,msg:" please enter a valid menu category id"})
          let menu_item_id= parseInt(req.body.menu_item_id);
          if(!menu_item_id>0) return res.status(400).send({status:false,msg:" please enter a valid menu item id"})
          let menu_addon_id= req.body.menu_addon_id
          
          console.log(menu_addon_id)
          let price= parseInt(req.body.price);
          if(!price>0) return res.status(400).send({status:false,msg:" please enter a valid price data"})
          let status= parseInt(req.body.status);
          if(!status>0) res.status(400).send({status:false,msg:"please enter a valid status, it should be 0 or 1"})
         let chkForDuplicate= await knex.select('*').from('menu_item_price').where({'menu_item_price.cafe_list_id':cafe_list_id,'menu_item_price.menu_item_id':menu_item_id})
         if(chkForDuplicate.length>0) return res.status(400).send({status:false,msg:'menu_item_price data already exist!'})
          let payload={
            'cafe_list_id':cafe_list_id,
            'menu_category_id':menu_category_id,
            'menu_item_id':menu_item_id,
            'menu_addon_id':menu_addon_id,
            'price':price,
            'status':status
          }
          let createMenuItemPrice= await knex('menu_item_price').insert(payload)
          return res.status(201).send({status:true,msg:"new menu item price added to cafe"})



    }
    catch(error){
        console.log(error)
        return res.status(500).send({ERROR:error})
    }
}
// const createMenu_item_price = ( req, res ) => {
//     try {
//         const v = new Validator( req.body, {
//             cafe_list_id: 'required',
//             menu_category_id: 'required|integer',
//             menu_item_id: 'required|integer',
//             price: 'required',
//             status: 'required'
           


//         } );

//         v.check().then( ( matched ) => {
//             if ( !matched ) {
//                 res.status( 422 ).send( baseResponse.withError( 'Missed Required files', v.errors ) );
//             } else {
//                 knex.select( '*' ).from( 'menu_item_price' ).where( 'menu_item_price.menu_item_id', req.body.menu_item_id )
//                     .then( ( data ) => {
//                         if ( data.length == 0 ) {
//                             let user = {
//                                 cafe_list_id: req.body.cafe_list_id,
//                                 menu_category_id: req.body.menu_category_id,
//                                 menu_item_id: req.body.menu_item_id,
//                                 menu_addon_id: req.body.menu_addon_id,
//                                 price: req.body.price,
//                                 status: req.body.status
                                
//                             }
//                             console.log("hello")
//                             knex( 'menu_item_price' ).insert( user ).then( ( data ) => {

                                
//                                 res.status( 200 ).send( baseResponse.withSuccess( 'menu_item_price Data Created', data[0] ) )
//                                 console.log( "menu_item_price Data Created" )
//                             } ).catch( ( err ) => {
//                                 res.status( 500 ).send( err.message );  
//                                 console.log( err.message );
//                             } )
//                         } else {
//                             res.status( 400 ).send( baseResponse.withError( 'menu_item_price data already exist!' ) );
//                             console.log( 'menu_item_price data not found' );
//                         }
//                     } ).catch( ( err ) => {
//                         console.error( { "error": err } );
//                         res.status( 500 ).send( err.message )
//                         console.log( err.message );
//                     } )
//             }
//         } );
//     } catch ( e ) {
//         console.log( e );
//         res.status( 500 ).send( baseResponse.withError( 'Internal server error' ) );
//     }

// }






const gecreateMenu_item_priceById= async function(req,res){
    try{
     let id= req.params.id;
     if(!id>0) return res.status(400).send({status:false,msg:"invalid id"})
     let menuItemPrice= await knex.select('menu_item_price.id','menu_item_price.menu_category_id','menu_item_price.cafe_list_id','menu_item_price.menu_item_id','menu_item_price.menu_addon_id','menu_item_price.price','menu_item_price.status','menu_item_price.average_rating','menu_item_price.uid','cafe_list.cafe_name','menu_category.category_name','menu_item.menu_item_name','menu_addon.Addon_name','menu_item.item_image_id','menu_item.measure_unit').from('menu_item_price')
     .join('cafe_list',{'cafe_list.id':'menu_item_price.cafe_list_id'})
     .join('menu_category',{'menu_category.id':'menu_item_price.menu_category_id'})
     .join('menu_item',{'menu_item.id':'menu_item_price.menu_item_id'})
     .leftJoin('menu_addon',{'menu_addon.id':'menu_item_price.menu_addon_id'})
     .where('menu_item_price.id',id)
      if(!menuItemPrice>0) {return res.status(404).send({status:false,msg:"no data found"})}else{
     return res.status(200).send({status:true,msg:"menu item detail",menuItemPrice})}
    }
    catch(error){
        console.log(error)
        return res.status(500).send({status:false,ERROR:error})
    }
}



// Update Menu addon Details
const updatetMenuItemById = ( req, res ) => {
    try {
        const v = new Validator( req.body, {
            cafe_list_id: 'required',
            menu_category_id: 'required|integer',
            menu_item_id: 'required|integer',
            price: 'required',
            status: 'required'
           
        } );
        v.check().then( ( matched ) => {
            if ( !matched ) {
                res.status( 422 ).send( baseResponse.withError( 'Missed Required files', v.errors ) );
            } else {
                let id = parseInt( req.params.id );
                if ( id > 0 ) {
                    knex.select( '*' ).from( 'menu_item_price' )
                        .where( 'id', id )
                        .then( ( data ) => {
                            if ( data.length > 0 ) {
                                let updateData = {
                                    cafe_list_id: req.body.cafe_list_id,
                                    menu_category_id: req.body.menu_category_id,
                                    menu_item_id: req.body.menu_item_id,
                                    menu_addon_id: req.body.menu_addon_id,
                                    price: req.body.price,
                                    status: req.body.status
                                
                                };
                                knex( 'menu_item_price' ).update( updateData ).where( 'id', id ).then( ( data ) => {
                                    res.status( 200 ).send( baseResponse.withSuccess( 'menu_item_price Data updated', data[0] ) )
                                } ).catch( ( err ) => {
                                    res.status( 500 ).send( err.message );
                                    console.log( err.message );
                                } )
                            } else {
                                res.status( 400 ).send( baseResponse.withError( 'menu_item_price data not found!' ) );
                                console.log( 'menu_item_price data not found' );
                            }
                        } ).catch( ( err ) => {
                            console.error( { "error": err } );
                            res.status( 500 ).send( err.message )
                            console.log( err.message );
                        } )
                }
                else {
                    baseResponse.sendError( res, {}, 'invalid menu_item_price  id' );
                }
            }
        } );
    } catch ( e ) {
        console.log( e );
        res.status( 500 ).send( baseResponse.withError( 'Internal server error ' ) );
    }
}




const getAllMenu_item_pricepage= async function(req,res){
    try{
        const{page,limit}=req.query;

        let getMenuItem= await knex.select('menu_item.item_image_id','menu_item_price.id','menu_item_price.cafe_list_id','menu_item_price.menu_item_id','menu_item_price.menu_category_id','menu_item_price.price','menu_item_price.status','menu_item_price.average_rating','menu_item_price.uid','cafe_list.cafe_name','menu_category.category_name','menu_item.menu_item_name','menu_item.measure_unit','menu_addon.Addon_name')
        .from('menu_item_price')
        .join('menu_item',{'menu_item.id':'menu_item_price.menu_item_id'})
        .join('menu_category',{'menu_category.id':'menu_item_price.menu_category_id'})
        .join('cafe_list',{'cafe_list.id':'menu_item_price.cafe_list_id'})
        .leftJoin('menu_addon',{'menu_addon.id':'menu_item_price.menu_addon_id'}).limit(limit*1).offset((page-1)*limit)
         
        let getCountOfMenuItemPrice= await knex('menu_item_price').count('id as cnt')
        let counting={
            'cnt':getCountOfMenuItemPrice[0].cnt
            }
        console.log(counting.cnt,"hi")
        // let getMenuAddon= await knex.select('menu_addon_price.id','cafe_list.cafe_name','menu_addon.Addon_name','menu_addon.addon_image_id','menu_addon_price.addon_price').from('menu_addon_price')
        // .join('menu_addon',{'menu_addon.id':'menu_addon_price.menu_addon_id'})
        // .join('cafe_list',{'cafe_list.id':'menu_addon_price.cafe_list_id'})//.limit(limit*1).offset((page-1)*limit)
         return res.status(200).send({status:true,mag:"details of menu item price id",TOTALCOUNT:counting.cnt,getMenuItem})
        
    }
    catch(error){
        console.log(error)
        return res.status(500).send({status:false,ERROR:error})
    }
}




module.exports = {
    createMenu_item_price,
    gecreateMenu_item_priceById,
    getAllMenu_item_pricepage,
    updatetMenuItemById,


}