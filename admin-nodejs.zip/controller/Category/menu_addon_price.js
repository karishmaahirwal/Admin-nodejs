const knex = require("../../db/db_knex")
const helper = require("../../helper/helper")
const { Validator } = require('node-input-validator');
const baseResponse = require("../../helper/baseResponse");


const createmenu_addon_price = async (req,res)=>{
try{
    const v = new Validator(req.body, {
        cafe_list_id: 'required|integer',
        menu_addon_id:'required|integer',
        addon_price:'required|integer',
        status:'required|integer'
    });

    v.check().then((matched) => {
        if(!matched){
            res.status(422).send(baseResponse.withError('Missed Required files', v.errors));
        }else{
        knex.select('*').from('menu_addon_price').where( 'cafe_list_id', req.body.cafe_list_id).where( 'menu_addon_id', req.body.menu_addon_id)
            .then((data) => {
                if (data.length == 0) {
                    let user = {
                        cafe_list_id: req.body.cafe_list_id,
                        menu_addon_id: req.body.menu_addon_id,
                        addon_price: req.body.addon_price,
                        status: req.body.status,
                     };


                    knex('menu_addon_price').insert(user).then((data) => {
                        res.status(200).send(baseResponse.withSuccess('menu_addon_price Data Created', data[0]))
                        console.log("menu_addon_price Data Created")
                    }).catch((err) => {
                        res.status(500).send(err.message);
                        console.log(err.message);
                    })
                } else {
                    res.status(400).send(baseResponse.withError('menu_addon_price data already exist!'));
                    console.log('menu_addon_price data not found');
                }
            }).catch((err) => {
                console.error({ "error": err });
                res.status(500).send(err.message)
                console.log(err.message);
            })
}
});
}catch (e) {
    console.log(e);
    res.status(500).send(baseResponse.withError('Internal server error'));
}
}


const getmenu_addon_priceById = (req,res)=>{
const menu_addon_id = parseInt(req.params.id)
console.log(menu_addon_id)
try{
    knex.select('*')
        .from('menu_addon_price')
        .where({id : req.params.id})
        .then((data) => {
            //console.log(data);
            if(data.length > 0){
                res.status(200).send(baseResponse.withSuccess("menu_addon_price Details", data[0]))
                console.log(data[0]);
            }else{
                res.status(404).send(baseResponse.withError("menu_addon_price not found"));
            }
        }).catch((err) => {
        res.status(500).send(err.message)
        console.log(err.message);
    });
}catch (e) {
    console.log(e);
    res.status(500).send(baseResponse.withError('Internal server error'));
}

}


// Update Menu addon Details
const updatetMenuAddonById = async (req,res)=>{

    try{
        const v = new Validator(req.body, {
            cafe_list_id: 'required|integer',
            menu_addon_id:'required|integer',
            addon_price:'required|integer'
        });
            v.check().then((matched) => {
                if(!matched){
                    res.status(422).send(baseResponse.withError('Missed Required files', v.errors));
                }else{
                    let id = parseInt(req.params.id);
            if(id > 0){
                knex.select('*').from('menu_addon_price')
                    .where('id', id)
                    .then((data) => {
                        if (data.length > 0) {
                                let user = {
                                    cafe_list_id: req.body.cafe_list_id,
                                    menu_addon_id: req.body.menu_addon_id,
                                    addon_price: req.body.addon_price

                    };
                            knex('menu_addon_price').update(user).where('id', id).then((data) => {
                                res.status(200).send(baseResponse.withSuccess('menu_addon_price Data updated', data[0]))
                            }).catch((err) => {
                                res.status(500).send(err.message);
                                console.log(err.message);
                            })
                        } else {
                            res.status(400).send(baseResponse.withError('menu_addon_price data not found!'));
                            console.log('menu_addon_price data not found');
                        }
                    }).catch((err) => {
                        console.error({ "error": err });
                        res.status(500).send(err.message)
                        console.log(err.message);
                    })
              }
              else{
                baseResponse.sendError(res, {}, 'invalid menu_addon_price id');
              }
    }
    });
        }catch (e) {
            console.log(e);
            res.status(500).send(baseResponse.withError('Internal server error'));
        }
}








function paginate(arr, page, pageSize) {
    return arr.slice(pageSize * (page - 1), pageSize * page);
  }
  
const getAllmenu_addon_pricepage =async (req, res) => {
    try{
        let pageno = req.query.pageno;
        let limits = req.query.limits;
        if(!limits){
            limits=10;
        }
        if ( !pageno ) {
            pageno = 0;
        }
        else {
            pageno = pageno - 1;
        }

        // knex("menu_item").select("*").limit(limit).skip(skip)
       knex.select('cafe_list.cafe_name','menu_addon_price.cafe_list_id','menu_addon_price.id','menu_addon.Addon_name','menu_addon_price.addon_price','menu_addon_price.menu_addon_id','menu_addon_price.uid','menu_addon_price.status').from('menu_addon_price')
       .join('menu_addon',{'menu_addon.id':'menu_addon_price.menu_addon_id'})
       .join('cafe_list',{'cafe_list.id':'menu_addon_price.cafe_list_id'}).limit(limits).offset(pageno*limits)
       .then((data)=>{
        (async () => {
            let getCountOfMenuAddonPrice= await knex('menu_addon_price').count('id as cnt')
            let counting={
                'cnt':getCountOfMenuAddonPrice[0].cnt
                }
            console.log(counting.cnt,"hi")
            res.status(200).send({status:true,msg:"menu addon price list",TOTALCOUNTOFADDONPRICE:counting.cnt,data})
        })();
        //res.status(200).send(baseResponse.withSuccess("All Addon Price Details", data))
            
        }).catch((err)=>{
            if(err){
                console.log(err)
                res.status(400).send({error:err})
            }
        })
    
    }catch (e) {
        console.log( e );
        res.status( 500 ).send( baseResponse.withError( 'Internal server error' ) );
        }
};
  




module.exports = {
    createmenu_addon_price,
    getmenu_addon_priceById,
    updatetMenuAddonById,
    getAllmenu_addon_pricepage   
}

 