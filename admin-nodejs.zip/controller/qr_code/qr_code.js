const knex = require( "../../db/db_knex" )
const helper = require( "../../helper/helper" );
const { Validator } = require( 'node-input-validator' );
const baseResponse = require( "../../helper/baseResponse" );
const logger = require( "../../helper/logger" );
const FormData = require( 'form-data' );
const http = require( 'http' );
const fs = require( 'fs' );
const axios = require( 'axios' )


const getqr = async ( req, res ) => {
    try {

        let pageno = req.query.pageno;
        let limits = req.query.limits;
        if ( !limits ) {
            limits = 10;
        }
        if ( !pageno ) {
            pageno = 0;
        }
        else {
            pageno = pageno - 1;
        }
        console.log( pageno )
        knex( 'qr_code' ).select( '*', 'qr_code.id' ).join( 'cafe_list', { 'qr_code.cafe_list_id': 'cafe_list.id' } ).limit( limits ).offset( pageno * limits )
            .then( ( data ) => {
                // console.log(data);
                if ( data.length > 0 ) {

                    (async () => {
                        let getCountOfQrCode= await knex('qr_code').count('id as cnt')
                        let counting={
                            'cnt':getCountOfQrCode[0].cnt
                            }
                        console.log(counting.cnt,"hi")
                        res.status(200).send({status:true,msg:"menu addon price list",TOTALCOUNTOFQRCODE:counting.cnt,data})
                    })();
                    // res.status( 200 ).send( baseResponse.withSuccess( "All QR Codes", data ) )
                    // console.log( data[0] );
                } else {
                    baseResponse.sendDatabaseError( res, "The table dosn't contain any data" )
                    console.log( "empty table is there, please insert the data then you will get that data back" );
                }
            } ).catch( ( err ) => {
                console.error( { "error": err } );
                res.status( 500 ).send( err.message )
                console.log( err.message );
            } )
    } catch ( e ) {
        console.log( e )
        res.status( 500 ).send( baseResponse.withError( "server error" ) );
    }
}



const getqrById = async ( req, res ) => {
    try {
        const id = req.params.qrId;
        knex( 'qr_code' ).select( '*', 'qr_code.id' ).where( 'qr_code.id', id ).join( 'cafe_list', { 'qr_code.cafe_list_id': 'cafe_list.id' } )
            .then( ( data ) => {
                // console.log(data);
                if ( data.length > 0 ) {
                    res.status( 200 ).send( baseResponse.withSuccess( "All QR Codes", data ) )
                    console.log( data[0] );
                } else {
                    baseResponse.sendDatabaseError( res, "The table dosn't contain any data" )
                    console.log( "empty table is there, please insert the data then you will get that data back" );
                }
            } ).catch( ( err ) => {
                console.error( { "error": err } );
                res.status( 500 ).send( err.message )
                console.log( err.message );
            } )
    } catch ( e ) {
        console.log( e )
        res.status( 500 ).send( baseResponse.withError( "server error" ) );
    }
}


const createQr = async ( req, res ) => {
    try {

        let user = {
            cafe_list_id: req.body.cafe_list_id,
            table_title: req.body.table_title,
            status: req.body.status,
            // qr_image_id: req.body.qr_image_id
        }

        knex( 'qr_code' ).insert( user )
            .then( ( data ) => {
                // console.log( "helllllooooooooo"+data[0] );
                let s1 = "0000" + user.cafe_list_id;
                let s2 = "0000" + data[0];

                s1 = s1.substr( s1.length - 5 );
                s2 = s2.substr( s2.length - 5 );
                let uid = s1 + s2;

                // console.log("this is"+uid);
                let change = {
                    table_uid: uid,
                }
                knex( 'qr_code' ).update( change ).where( 'qr_code.id', data[0] ).then( ( row ) => {

                    axios.post( 'https://auto.a2deats.com/webhook/gen-qr-9debe0cd-4769-4736-b712-ceadd0414f1f', { 
                        table_uid: uid,
                        id: data[0]
                    } )
                        .then( function ( response ) {
                            console.log( response.data.Image_URL);
                            knex( 'qr_code' ).update( { qr_image_id: response.data.Image_URL , qr_short_url : response.data.short_url , qr_long_url : response.data.long_url } ).where( 'qr_code.id', data[0] ).then( ( val ) => {
                                res.status( 200 ).send( baseResponse.withSuccess( "QR Code created", row ) )
                            } ).catch( ( err ) => {
                                console.error( { "error": err } );
                                res.status( 500 ).send( err.message )
                                console.log( err.message );
                            } )
                        } )
                        .catch( function ( error ) {
                            console.log( error );
                        } );

                } ).catch( ( err ) => {
                    console.error( { "error": err } );
                    res.status( 500 ).send( err.message )
                    console.log( err.message );
                } )
            } ).catch( ( err ) => {
                console.error( { "error": err } );
                res.status( 500 ).send( err.message )
                console.log( err.message );
            } )
    } catch ( e ) {
        console.log( e )
        res.status( 500 ).send( baseResponse.withError( "server error" ) );
    }
}


const editqr = async ( req, res ) => {
    try {
        const id = req.params.qrId;
        let user = {
            cafe_list_id: req.body.cafe_list_id,
            table_title: req.body.table_title,
            status: req.body.status
        }
        console.log( id )
        knex( 'qr_code' ).update( user ).where( 'qr_code.id', id )
            .then( ( data ) => {
                res.status( 200 ).send( baseResponse.withSuccess( "Update QR", data ) )
                console.log( data[0] );
            } ).catch( ( err ) => {
                console.error( { "error": err } );
                res.status( 500 ).send( err.message )
                console.log( err.message );
            } )
    } catch ( e ) {
        console.log( e )
        res.status( 500 ).send( baseResponse.withError( "server error" ) );
    }
}


module.exports = { getqr, getqrById, createQr, editqr };




