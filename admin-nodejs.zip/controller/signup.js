const knex = require("../db/db_knex")
const helper = require("../helper/helper");
const logger = require("../helper/logger")
const {generateToken} = require("../helper/auth")
const bcrypt = require("bcrypt")
const br = require("../helper/baseResponse")
const jwt = require("jsonwebtoken");
const {Validator} = require('node-input-validator');
const emailRegexp = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
const nodemailer = require('nodemailer');
const {default: axios} = require("axios");
const path = require("path")
const fs = require("fs")
const FormData = require("form-data")
const dotenv = require('dotenv');
dotenv.config({path: './config.env'});
const AWS = require("aws-sdk");
const S3_KEY_ID = process.env.S3_KEY_ID;
const S3_SECRET_KEY = process.env.S3_SECRET_KEY;


const signup = async (req, res) => {
    try {
        if (req.body.email !== undefined
            && req.body.password !== undefined) {
            if (!emailRegexp.test(req.body.email)) {
                return res.send(br.withError("Please enter a valid email Id!"));
            } else if (req.body.password.length < 6) {
                return res.send(br.withError('Please enter password of length 6 characters!'));
            } else {
                const hash = bcrypt.hashSync(req.body.password, 10)
                const user = {
                    "email": req.body.email,
                    "password": hash
                }
                knex.select('*')
                    .from("user_admin")
                    .where("email", req.body.email)
                    .then((data) => {
                        if (data.length < 1) {
                            knex("user_admin").insert(user).then((data) => {
                                res.status(200).send(br.withSuccess('User Signup  successfully!'));
                                console.log(user);
                                console.log("Your data has been inserted successfully");
                            }).catch((err) => {
                                console.log(err.message);
                                res.status(500).send(err.message);
                            })
                        } else {
                            res.status(200).send(br.withError("This email is registered already! Try to login"));
                            console.log("This email address is already exists in user table");
                        }
                    }).catch((err) => {
                    console.error({"error": err});
                    res.status(500).send(err.message)
                    console.log(err.message);
                })
            }
        } else {
            //send invalid input
            res.status(400).send(br.withError("Please send a valid input"));
        }
    } catch (e) {
        console.log(e);
        res.status(500).send(br.withError(''));
    }
}


const login = function (req, res) {

    const v = new Validator(req.body, {
        email: 'required|string|email',
        password: 'required|string'
    });

    v.check().then( async (matched) => {
        if (!matched) {
            res.status(422).send(br.withError('Missed Required files', v.errors));
        } else {
            let email = req.body.email;
            let password = req.body.password;

            if (!(email.length > 0)) return res.status(400).send({status: false, msg: "email invaild"});
            if (!(password.length > 0)) return res.status(400).send({status: false, msg: "enter a password"});

            let loggingprocess = await knex.select('*').from('user_admin').where('email', email);

            checkEml = {'email': loggingprocess[0]}
            if (!checkEml.email || !checkEml.email.email == email) return res.status(404).send({
                status: false,
                msg: "invalid credential"
            })
            let findUserRole = {
                'user_role_id': loggingprocess[0].user_role_id
            }
            console.log(findUserRole.user_role_id)
            if (findUserRole.user_role_id != 1) return res.status(403).send({
                status: false,
                msg: "you are not authorized as admin"
            })


            let hasing = bcrypt.compareSync(password, loggingprocess[0].password)
            if (!hasing) {
                return res.status(400).send({status: false, msg: "invalid credential"})
            } else {
                let token = jwt.sign(
                    {
                        'email': loggingprocess[0].email,
                        'id': loggingprocess[0].id,
                        'cafe_list_id': loggingprocess[0].cafe_list_id
                    }, process.env.SECRET)
                console.log(token, email)
                let updateToken = await knex('user_admin').update('token', token).where('email', email)
                let userAdminProfile = await knex.select('user_admin.id as user_admin_id','user_admin.email','user_admin.mobile_number'
                ,'user_admin_profile.first_name','user_admin_profile.last_name','user_admin_profile.profile_pic_image_id','user_admin_profile.photo_proof_id_url',
                'user_admin_profile.address_proof_id_url').from('user_admin')
                .leftJoin('user_admin_profile',{'user_admin_profile.user_admin_id':'user_admin.id'}).where('user_admin_id', loggingprocess[0].id)

                return res.status(200).send({status: true, msg: "login successful", token, email, userAdminProfile})

            }
        }
    }).catch(e => br.sendServerError(res, e));

}


const changePassword = (req, res) => {
    try {
        const v = new Validator(req.body, {
            password: 'required|minLength:6',
            cpassword: 'required|minLength:6',
            // newPassword : 'required|minLength:6',
        });

        v.check().then((matched) => {
            if (!matched) {
                res.status(422).send(br.withError('Missed Required files', v.errors));
            } else {
                if (req.body.password != req.body.cpassword) {
                    res.status(400).json({msg: "password and cpassword does not match"})
                }
                let token = req.params.token;
                console.log(token)
                // console.log(typeof email)
                if (token.length > 0) {
                    knex.select('*').from('user_admin')
                        .where('token', token)
                        .then((data) => {
                            console.log(data)
                            if (data.length > 0) {
                                const hash = bcrypt.hashSync(req.body.password, 10)
                                let user = {
                                    "password": hash
                                };
                                knex('user_admin').where('token', token).update(user).then((data) => {
                                    res.status(200).send(br.withSuccess(' password Changed  successfully By email', data[0]))
                                    console.log(user)
                                }).catch((err) => {
                                    res.status(500).send(err.message);
                                    console.log(err.message);
                                })
                            } else {
                                res.status(400).send(br.withError('User  data not found!'));
                                console.log('password data not found');
                            }
                        }).catch((err) => {
                        console.error({"error": err});
                        res.status(500).send(err.message)
                        console.log(err.message);
                    })
                } else {
                    br.sendError(res, {}, 'invalid  email');
                }
            }
        })
    } catch (e) {
        console.log(e);
        res.status(500).send(br.withError('Internal server error'));
    }
}


const get_signup = (req, res) => {
    knex.from("user_admin").select("*")
        .then((row) => {
            res.send(row)
        })
        .catch((err) => {
            res.json({
                message: err
            })
        })
}


const sendmail = async (req, res) => {
    var smtpConfig = {
        host: 'mx1.a2d.email',
        port: 587,
        secure: true, // use SSL
        auth: {
            user: 'system@a2deats.com',
            pass: 'eePpsBUT'
        }
    };

    var transporter = nodemailer.createTransport(smtpConfig);

    // setup e-mail data with unicode symbols
    var mailOptions = {
        from: 'system@a2deats.com', // sender address
        // to: `${req.body.email}`, // list of receivers
        to: `arpitpachauri220@gmail.com`, // list of receivers
        subject: 'Hello from A2D Team <img draggable="false" class="emoji" alt="✔" src="https://s0.wp.com/wp-content/mu-plugins/wpcom-smileys/twemoji/2/svg/2714.svg">', // Subject line
        text: 'Hello Reset password link', // plaintext body
        html: '<b><img draggable="false" class="emoji" alt="✌" src="https://s0.wp.com/wp-content/mu-plugins/wpcom-smileys/twemoji/2/svg/270c.svg"></b>' // html body
    }

    transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
            return console.log(error);
        } else {
            console.log('Message sent: ' + info.response);
            return res.status(200).send(br.withSuccess(' Email has been successfully sent to user', req.body.email));
        }
    });

}


const forgotpassword = async (req, res) => {
    const email = req.body.email;
    knex('user_admin').select('*').where('user_admin.email', email).then((data) => {
        if (data.length > 0) {
            //  
            const user = {
                'email': email,
            };
            console.log(user);
            const token = generateToken(user)
            console.log(token);
            console.log(data[0].user_role_id)
            knex("user_admin").where('email', email).update({token: token}).then((row) => {
                // token updated //https://auto.a2deats.com/webhook/reset-password-64a53eb9-7e6e-4e2a-8798-63a05ad1a88a
                //https://auto.a2deats.com/webhook/reset-password-64a53eb9-7e6e-4e2a-8798-63a05ad1a88a
                axios.post('https://auto.a2deats.com/webhook/reset-password-64a53eb9-7e6e-4e2a-8798-63a05ad1a88a', {

                    email: email,
                    // email: "suman.mal@a2d.co.in",
                    user_role_id: data[0].user_role_id.toString(),
                    token: token
                }).then((response) => {
                    console.log(response)
                    res.status(200).json({msg: "email sent"})
                }).catch((err) => {
                    res.status(500).send(err.message);
                    console.log(err.message);
                })

            }).catch((err) => {
                res.status(500).send(err.message);
                console.log(err.message);
            })
        } else {
            res.status(400).json({err: "email does not exist"});
        }
    })
}


const uploadImage = async (req, res) => {
    // console.log(req.files.file)
    if (req.files) {
        let image_url = req.files.file.tempFilePath.replace(/\\/g, "/");
        const formdata = new FormData();
        formdata.append('file', fs.createReadStream(image_url));
        // formdata.append('file', req.files.file);

        // console.log(req.files)
        var url = process.env.CloudflareURL;
        axios.post(url, formdata, {
            method: "POST",
            headers: {
                'Content-Type': `multipart/form-data; boundary=${formdata._boundary}`,
                'Authorization': `Bearer ${process.env.CloudflareToken} `
            },
        }).then((response) => {
            console.log(response)
            res.status(200).json(response.data.result)
        }).catch((err) => {
            res.status(500).send(err.message);
            console.log(err.message);
        })

    } else {
        res.status(400).json({msg: "Plz select the file"})
    }

}

const uploadFile = async (req, res) => {

    if (req.files) {

        let image_url = req.files.file.tempFilePath.replace(/\\/g, "/");

        const s3 = new AWS.S3({
            accessKeyId: S3_KEY_ID,
            secretAccessKey: S3_SECRET_KEY,
        });
        const fileContent = fs.readFileSync(path.resolve(image_url));
        const params = {
            ACL: process.env.ACL,
            Bucket: process.env.BucketName,
            Key: process.env.folder + req.files.file.name,
            Body: fileContent,
            ContentType: "`multipart/form-data; boundary=${formdata._boundary}`"
        }
        s3.upload(params, (err, data) => {
            if (err) {
                console.log(err);
                res.status(500).json(err);
            } else {
                //    console.log(data);
                console.log("File Uploaded Successfully", data.Location)
                res.status(200).json(data.Location);
            }
        })
    } else {
        // console.log( "I am here" );
        res.status(400).json({msg: "Plz select the file"})
    }
}


const viewProfile = async function (req, res) {
    try {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];

        let getUserId = await knex.select('*').from('user_admin').where('token', token)
        let ID = {
            'id': getUserId[0].id
        }
        console.log(ID.id)
        let getProfile = await knex.select('*').from('user_admin_profile').where('user_admin_id', ID.id)
        if (!getProfile > 0) {
            return res.status(404).send({status: false, msg: "no data found"})
        } else {
            return res.status(200).send({status: true, getProfile})
        }
    } catch (error) {
        console.log(error)
        return res.status(500).send({status: false, ERROR: error})
    }
}

const editAdminProfile = async function (req, res) {
    try {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];
        const decodedToken = jwt.verify(token, process.env.SECRET)
        req.Id = decodedToken.id;
        req.cafeId = decodedToken.cafe_list_id;
        let first_name = req.body.first_name;
        if (!first_name > 0) return res.status(400).send({status: false, msg: "enter a valid first name"})
        let last_name = req.body.last_name;
        if (!last_name > 0) return res.status(400).send({status: false, msg: "enter a valid last name"})
        let profile_pic_image_id = req.body.profile_pic_image_id;
        if (!profile_pic_image_id) return res.status(400).send({
            status: false,
            msg: "enter a valid profile pic image id"
        })
        let payload = {
            'first_name': first_name,
            'last_name': last_name,
            'profile_pic_image_id': profile_pic_image_id
        }
        let editProfile = await knex('user_admin_profile').update(payload).where('user_admin_id', req.Id)
        return res.status(200).send({status: true, msg: "profile details updated"})
    } catch (error) {
        console.log(error)
        return res.status(500).send({status: false, ERROR: error})
    }
}

const resetPassword = async function (req, res) {
    try {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];
        const decodedToken = jwt.verify(token, process.env.SECRET)
        req.Id = decodedToken.id;
        req.cafeId = decodedToken.cafe_list_id;
        //let data=req.body;
        //let{oldpassword,newpassword,reenternewpassword}=data;
        let oldpassword = req.body.oldpassword;
        let newpassword = req.body.newpassword;
        //let reenternewpassword=req.body.reenternewpassword
        //let id=parseInt(req.params.id);  //Number
        let id = req.Id;
        //if(!id) return res.status(400).send({status:false,msg:"please enter a id"})
        //if(req.Id!=id) return res.status(403).send({status:false,msg:"user not authorized for this task"})

        let validId = await knex.select('id').from('user_admin').where('id', id)
        if (!validId) return res.status(404).send({status: false, msg: "id not valid"})
        let data = await knex.select('password').from('user_admin').where('id', id)

        let old = bcrypt.compareSync(oldpassword, data[0].password)
        if (!old) return res.status(400).send({status: false, msg: "old passowrd is wrong"})

        //if(newpassword!=reenternewpassword) return res.status(400).send({status:false,msg:"enter same password"})
        const hash = bcrypt.hashSync(newpassword, 10)
        let updatepass = {'password': hash};
        let updatePassword = await knex.select('password').from('user_admin').update(updatepass).where('id', id)
        return res.status(200).send({status: true, msg: "password updated successfully"})
    } catch (error) {
        console.log(error)
        return res.status(500).send({ERROR: error})
    }

}


const updateDynamic= async function (req, res) {

    const {cafe_dynamic_total_order,cafe_dynamic_total_item,cafe_dynamic_average_ticket_size,cafe_dynamic_average_rating,cafe_dynamic_average_waiting_time,cafe_dynamic_most_used_payment_mode,cafe_dynamic_starting_price,menu_dynamic_total_cafe,menu_dynamic_average_rating,menu_dynamic_total_items,user_customer_dynamic_cafe_visit,user_customer_dynamic_no_of_orders,user_customer_dynamic_no_of_reviews,user_customer_dynamic_order_item_count}=req.body;
    if(cafe_dynamic_total_order==1){
       await  axios.get('https://auto.a2deats.com/webhook/c189d644-debd-484a-83de-989124e6ba02').then((response) => {
            console.log("tota-order data updated");
        }).catch((err) => {
            console.log(err);
            // return res.status(500).send(err.message);
        })
    }
    if(cafe_dynamic_total_item==1){
        // this also has error
        await  axios.get('https://auto.a2deats.com/webhook/df127a45-4b01-4d73-b8b4-c0c6bd08b9cf').then((response) => {
             console.log("tota-item data updated");
         }).catch((err) => {
             console.log("tota-item"+err)
            //  return res.status(500).send(err.message);
         })
     }
     if(cafe_dynamic_average_ticket_size==1){
        await  axios.get('https://auto.a2deats.com/webhook/e8a9346b-7a44-4019-baf1-88f2e5dba39d').then((response) => {
             console.log("cafe_dynamic_average_ticket_size data updated");
         }).catch((err) => {
             console.log("cafe_dynamic_average_ticket_size"+err);
            //  return res.status(500).send(err.message);
         })
     }
     if(cafe_dynamic_average_rating==1){
        await  axios.get('https://auto.a2deats.com/webhook/9481eaec-804a-4592-8326-14f7f53119c7').then((response) => {
             console.log("cafe_dynamic_average_rating data updated");
         }).catch((err) => {
             console.log(err);
            //  return res.status(500).send(err.message);
         })
     }
     if(cafe_dynamic_average_waiting_time==1){
        await  axios.get('https://auto.a2deats.com/webhook/c228f158-3601-4eec-8c07-58c892572fa0').then((response) => {
             console.log("cafe_dynamic_average_waiting_time data updated");
         }).catch((err) => {
             console.log(err);
            //  return res.status(500).send(err.message);
         })
     }
     if(cafe_dynamic_most_used_payment_mode==1){
        await  axios.get('https://auto.a2deats.com/webhook/e13aa226-4575-449f-afec-3a90f8f5cf7b').then((response) => {
             console.log("cafe_dynamic_most_used_payment_mode data updated");
         }).catch((err) => {
             console.log(err);
            //  return res.status(500).send(err.message);
         })
     }
     if(cafe_dynamic_starting_price==1){
        await  axios.get('https://auto.a2deats.com/webhook/aa16e9dc-8674-4986-a33a-f2af7446a814').then((response) => {
             console.log("cafe_dynamic_starting_price data updated");
         }).catch((err) => {
             console.log(err);
            //  return res.status(500).send(err.message);
         })
     }
     if(menu_dynamic_total_cafe==1){
        await  axios.get('https://auto.a2deats.com/webhook/77f9b88b-ef67-4ce8-9b38-41e3c94928d0').then((response) => {
             console.log("menu_dynamic_total_cafe data updated");
         }).catch((err) => {
             console.log(err);
            //  return res.status(500).send(err.message);
         })
     }
     if(menu_dynamic_average_rating==1){
        await  axios.get('https://auto.a2deats.com/webhook/a4117c48-7d8e-4c5e-9e5e-6a591756e086').then((response) => {
             console.log("menu_dynamic_average_rating data updated");
         }).catch((err) => {
             console.log(err);
            //  return res.status(500).send(err.message);
         })
     }
     if(menu_dynamic_total_items==1){
        await  axios.get('https://auto.a2deats.com/webhook/f9b21d5e-b04d-4a5a-8ee7-3ee8818e6cd7').then((response) => {
             console.log("menu_dynamic_total_items data updated");
         }).catch((err) => {
             console.log(err);
            //  return res.status(500).send(err.message);
         })
     }
     if(user_customer_dynamic_cafe_visit==1){
        await  axios.get('https://auto.a2deats.com/webhook/c7489509-ade6-4ad8-8999-b17f3bb636be').then((response) => {
             console.log("user_customer_dynamic_cafe_visit data updated");
         }).catch((err) => {
             console.log(err);
            //  return res.status(500).send(err.message);
         })
     }
     if(user_customer_dynamic_order_item_count==1){
        //  this has error 
        await  axios.get('https://auto.a2deats.com/webhook/afa08255-972e-489e-9417-0630af843e31').then((response) => {
             console.log("user_customer_dynamic_order_item_count data updated");
         }).catch((err) => {
             console.log(err);
            //  return res.status(500).send(err.message);
         })
     }
     if(user_customer_dynamic_no_of_reviews==1){
        await  axios.get('https://auto.a2deats.com/webhook/20bf8ea1-a051-4edf-a4d9-63dedd6cd116').then((response) => {
             console.log("user_customer_dynamic_no_of_reviews data updated");
         }).catch((err) => {
             console.log(err);
            //  return res.status(500).send(err.message);
         })
     }
     if(user_customer_dynamic_no_of_orders==1){
        await  axios.get('https://auto.a2deats.com/webhook/962d2755-b616-4d2c-a4b1-9da296c60431').then((response) => {
             console.log("user_customer_dynamic_no_of_orders data updated");
         }).catch((err) => {
             console.log(err);
            //  return res.status(500).send(err.message);
         })
     }
    res.status(200).json({"msg": "Data Updated"});
}

module.exports = {
    signup,
    login,
    changePassword,
    get_signup,
    sendmail,
    forgotpassword,
    uploadImage,
    uploadFile,
    viewProfile,
    editAdminProfile,
    resetPassword,
    updateDynamic
}



