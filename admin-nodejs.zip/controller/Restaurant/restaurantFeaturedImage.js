const knex = require("../../db/db_knex")
const helper = require("../../helper/helper");
const {Validator} = require('node-input-validator');
const br = require("../../helper/baseResponse");
const logger = require("../../helper/logger");
const jwt = require("jsonwebtoken");
const dotenv = require('dotenv').config();

const featuredImage = {};
// cafe_list
featuredImage.addFeaturedImage = (req, res) => {
    try {
        const v = new Validator(req.body, {
            cafe_image_name: "required",
            image_position: "integer",
            server_image_id: "required",
            is_featured: "required",
        })
        v.check().then(async (matched) => {
            if (!matched) {
                res.status(422).send(br.withError('Missed Required files', v.errors));
            } else {
                let cafe_list_id = Number(req.params.cafe_list_id);
                if (cafe_list_id > 0) {

                    if(helper.getBoolean(req.body.is_featured)){
                        await knex('cafe_gallery')
                            .update({is_featured: 0})
                            .where('cafe_list_id', cafe_list_id)
                            .where('is_featured', 1);
                    }

                    let maxSeqNumber = await knex('cafe_gallery')
                        .select(knex.raw('COALESCE(max(image_position), 0) as maxSeq'))
                        .where('cafe_list_id', cafe_list_id);

                    let user = {
                        cafe_list_id: cafe_list_id,
                        cafe_image_name: req.body.cafe_image_name,
                        image_position: parseInt(req.body.image_position),
                        server_image_id: req.body.server_image_id,
                        is_featured: helper.getBoolean(req.body.is_featured) ? '1' : '0'
                    };

                    if(user.image_position > 0 && maxSeqNumber[0].maxSeq > user.image_position){
                        await knex('cafe_gallery').update({image_position: knex.raw(' image_position + 1 ')})
                            .where('cafe_list_id', cafe_list_id)
                            .where('image_position', '>=', user.image_position);
                    }else{
                        user.image_position = maxSeqNumber[0].maxSeq + 1;
                    }

                    let cf = await knex('cafe_gallery').insert(user);
                    let data = await knex('cafe_gallery').where('id', cf[0]);

                    return br.sendSuccess(res, data[0], 'Featured Image Added');
                } else {
                    br.sendError(res, {}, 'invalid form cafe_list_id');
                }
            }
        });
    } catch (e) {
        console.log(e);
        res.status(500).send(br.withError(''));
    }
}

featuredImage.updateFeaturedImage = async function (req, res) {
    try {
        const v = new Validator(req.body, {
            cafe_image_name: "string",
            image_position: "integer",
            server_image_id: "string",
            is_featured: "boolean",
        })

        v.check().then( async (matched) => {
            if (!matched) {
                res.status(422).send(br.withError('Missed Required files', v.errors));
            } else {
                let galId = Number(req.params.cafe_gallery_id);
                if (galId > 0) {

                    let galDetails = await knex('cafe_gallery')
                        .where('id', galId);

                    if(galDetails.length < 1){
                        return br.sendError(res, {}, 'Gallery not found', 404);
                    }
                    galDetails = galDetails[0];

                    let updateData = {
                        /*                        cafe_list_id: galId,
                                                cafe_image_name: req.body.cafe_image_name,
                                                image_position: req.body.image_position,
                                                server_image_id: req.body.server_image_id,
                                                is_featured: req.body.is_featured*/
                    };

                    if(helper.isNotUndefinedOrNull(req.body.cafe_image_name)){
                        updateData.cafe_image_name = req.body.cafe_image_name;
                    }

                    if(helper.isNotUndefinedOrNull(req.body.image_position) && parseInt(req.body.image_position) > 0){
                        updateData.image_position = parseInt(req.body.image_position);

                        let items = await knex('cafe_gallery').where('image_position', req.body.image_position);

                        if(items.length > 0 && req.body.image_position !== galDetails.image_position){

                            if(updateData.image_position > galDetails.image_position){
                                let upCt = await knex('cafe_gallery')
                                    .update({ image_position: knex.raw('image_position - 1')})
                                    .where('image_position', '<=', updateData.image_position)
                                    .whereNot('image_position', galDetails.image_position)
                                    .where('cafe_list_id', galDetails.cafe_list_id);

                                console.log(upCt);
                            }else{
                                let upCt = await knex('cafe_gallery')
                                    .update({ image_position: knex.raw('image_position + 1')})
                                    .where('image_position', '>=', updateData.image_position)
                                    .whereNot('image_position', galDetails.image_position)
                                    .where('cafe_list_id', galDetails.cafe_list_id);

                                console.log(upCt);
                            }
                        }
                    }

                    if(helper.isNotUndefinedOrNull(req.body.is_featured)){
                        updateData.is_featured = helper.getBoolean(req.body.is_featured) ? '1' : '0';

                        if(updateData.is_featured){
                            await knex('cafe_gallery')
                                .update({is_featured: 0})
                                .where('cafe_list_id', galDetails.cafe_list_id)
                                .where('is_featured', 1);
                        }
                    }

                    if(Object.keys(updateData).length > 0){
                        await knex('cafe_gallery').update(updateData).where('id', galDetails.id);
                    }

                    galDetails = await knex('cafe_gallery')
                        .where('id', galId);

                    br.sendSuccess(res, galDetails[0], 'Updated!');

                } else {
                    br.sendError(res, {}, 'invalid form cafe_gallery_id');
                }
            }
        }).catch ((e) => {
            br.sendServerError(res, e);
        });
    } catch (e) {
        console.log(e);
        res.status(500).send(br.withError(''));
    }
}

featuredImage.deleteFeaturedImage = async function (req, res) {
    try {
        let cafe_gallery_id = Number( req.params.cafe_gallery_id );
        if ( cafe_gallery_id > 0 ) {

            knex( 'cafe_gallery' ).update( {is_deleted : true} ).where( {
                'cafe_gallery.id': cafe_gallery_id
            } )
                .then( ( data ) => {
                    res.status( 200 ).send( br.withSuccess( ' Image deleted' ) )
                    // console.log( "Restaurant Data Created" )
                } ).catch( ( err ) => {
                res.status( 500 ).send( err.message );
                console.log( err.message );
            } )
        } else {
            br.sendError( 'invalid form cafe_list_id' );
        }
    } catch ( e ) {
        console.log( e );
        res.status( 500 ).send( br.withError( '' ) );
    }
}

module.exports = featuredImage;



