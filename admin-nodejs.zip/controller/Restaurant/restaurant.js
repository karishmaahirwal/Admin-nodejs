const knex = require( "../../db/db_knex" )
const helper = require( "../../helper/helper" );
const { Validator } = require( 'node-input-validator' );
const br = require( "../../helper/baseResponse" );
const logger = require( "../../helper/logger" );
const jwt = require( "jsonwebtoken" );
const dotenv = require( 'dotenv' ).config();
const {default: axios} = require("axios");


// cafe_list
const Createrestaurant = async ( req, res ) => {
    try {
        const v = new Validator( req.body, {
            cafe_name: 'required|minLength:3',
            email: 'required',
            city: 'required|string'
        } );

        v.check().then( ( matched ) => {
            if ( !matched ) {
                res.status( 422 ).send( br.withError( 'Missed Required files', v.errors ) );
            } else {
                knex.select( '*' ).from( 'cafe_list' ).where( {
                    email: req.body.email,
                } )
                    .then( ( data ) => {
                        if ( data.length == 0 ) {
                            let user = {
                                cafe_name: req.body.cafe_name,
                                email: req.body.email,
                                city: req.body.city

                            };
                            let cafe_list_id;
                            knex( 'cafe_list' ).insert( user ).then( ( data ) => {
                                cafe_list_id = data[0];
                                // console.log(typeof(cafe_list_id));
                                let s = "0000" + cafe_list_id;
                                s = s.substr( s.length - 5 );
                                // console.log(s);  
                                ( async () => {
                                    const authHeader = req.headers['authorization'];
                                    const token = authHeader && authHeader.split( ' ' )[1];
                                    const decodedToken = jwt.verify( token, process.env.SECRET )
                                    req.Id = decodedToken.id;
                                    req.cafeId = decodedToken.cafe_list_id;
                                    //let finduseradmin= await knex.select('*').from('user_admin').where('user_admin.id',id)
                                    let payloadFordynamic = {
                                        'cafe_list_id': cafe_list_id,
                                        'user_admin_id': req.Id
                                    }
                                    await knex( 'cafe_list' ).where( 'id', '=', cafe_list_id ).update( { uid: s } );
                                    await knex( 'cafe_contact' ).insert( { cafe_list_id } );
                                    await knex( 'cafe_details' ).insert( { cafe_list_id } );
                                    await knex( 'cafe_dynamic' ).insert( payloadFordynamic );
                                    await axios.post('https://auto.a2deats.com/webhook/9d3e7b7a-8939-40fd-b4b5-aec5fa64aca3', {
                                        id: cafe_list_id.toString()
                                    })
                                } )();

                                res.status( 200 ).send( br.withSuccess( ' Restaurant Data Created', data ) )
                                // console.log(data)
                            } ).catch( ( err ) => {
                                console.error( { "error": err } );
                                res.status( 500 ).send( err.message )
                                console.log( err.message );
                            } )

                        } else {
                            res.status( 400 ).send( br.withError( 'email is already registered!' ) );
                            console.log( 'email is already registered!' );
                        }
                    } ).catch( ( err ) => {
                        console.error( { "error": err } );
                        res.status( 500 ).send( err.message )
                        console.log( err.message );
                    } )
            }
        } );
    } catch ( e ) {
        console.log( e );
        res.status( 500 ).send( br.withError( '' ) );
    }
}

const cafeList = async function ( req, res ) {
    try {
        let s = req.query.s;
        if ( s === undefined ) {
            s = '';
        }

        let getList = knex.select( 'cafe_list.id', 'cafe_list.cafe_name' )
            .from( 'cafe_list' );

        if ( s.length > 0 ) {
            getList.where( 'cafe_list.cafe_name', 'like', `${s}%` );
        }

        getList = await getList;

        if ( !getList > 0 ) {
            br.sendError( res, {}, "no data found", 404 );
        } else {
            br.sendSuccess( res, getList, 'All Cafe list' );
        }
    } catch ( error ) {
        br.sendDatabaseError( res, error );
    }
}

// knex('cafe_dynamic ').select('cafe_list.uid','cafe_list.status','cafe_list.restaurant_name','cafe_dynamic.total_item','cafe_dynamic.total_order','user_admin_profile.first_name')
//             .join('cafe_list', {'cafe_list.id' : 'cafe_dynamic.cafe_list_id'})
//             .join('user_admin_profile', { 'user_admin_profile.user_admin_id': 'cafe_dynamic.user_admin_id' })


// knex('cafe_dynamic ').select('cafe_list.uid','cafe_list.status','cafe_list.restaurant_name','cafe_dynamic.total_item','cafe_dynamic.total_order')
// .join('cafe_list', {'cafe_list.id' : 'cafe_dynamic.cafe_list_id'})
//    let testing= knex.select('cafe_list.id','cafe_list.uid','cafe_list.status','cafe_list.cafe_name','cafe_dynamic.total_item','cafe_dynamic.total_order','cafe_dynamic.is_most_visited','cafe_dynamic.is_new_opening','cafe_dynamic.is_featured','user_admin_profile.first_name','user_admin_profile.last_name').from('cafe_list')
//     .leftJoin('cafe_dynamic', {'cafe_dynamic.cafe_list_id' : 'cafe_list.id'})
//     .leftJoin('user_admin_profile', { 'user_admin_profile.user_admin_id': 'cafe_dynamic.user_admin_id' }).limit(limit*1).offset((page-1)*limit)
//     testing.toString()
// get generalInformation of cafe



const generalInfoCafe = async function ( req, res ) {
    try {

        let { page, limit } = req.query;

        if ( page === undefined ) {
            page = 1
        }
        if ( limit === undefined ) {
            limit = 10
        }
        let listOfCafeInfo = await knex.select( 'cafe_list.id', 'cafe_list.uid', 
        'cafe_list.status', 'cafe_list.cafe_name', 'cafe_dynamic.total_item', 'cafe_dynamic.total_order', 
        'cafe_dynamic.is_most_visited', 'cafe_dynamic.is_new_opening', 'cafe_dynamic.is_featured', 
        'user_admin_profile.first_name', 'user_admin_profile.last_name' )
        .from( 'cafe_list' )
            .leftJoin( 'cafe_dynamic', { 'cafe_dynamic.cafe_list_id': 'cafe_list.id' } )
            .leftJoin( 'user_admin_profile', { 'user_admin_profile.user_admin_id': 'cafe_dynamic.user_admin_id' } ).limit( limit * 1 ).offset( ( page - 1 ) * limit )

        let cafeCount = await knex( 'cafe_list' ).count( 'id as cnt' )
        let cafe = {
            'cnt': cafeCount[0].cnt
        }
        console.log( cafe.cnt, "hi" )
        return res.status( 200 ).send( {
            status: true,
            msg: "All Resturant Details",
            NUMBEROFCAFE: cafe.cnt,
            listOfCafeInfo
        } )

    } catch ( error ) {
        console.log( error )
        return res.status( 500 ).send( { status: false, ERROR: error } )
    }
}
// const generalInfoCafe = async (req, res) => {   
//     try {
//         let pageno=req.query.pageno;
//         let limits=req.query.limits;    
//         if(!limits){
//             limits=10;
//         }
//         if(!pageno){
//             pageno=0;
//         }
//         else{
//             pageno=pageno-1;
//         }
//         console.log(pageno)
//         knex('cafe_dynamic ').select('cafe_list.id','cafe_list.uid','cafe_list.status','cafe_list.cafe_name','cafe_dynamic.total_item','cafe_dynamic.total_order','cafe_dynamic.is_most_visited','cafe_dynamic.is_new_opening','cafe_dynamic.is_featured','user_admin_profile.first_name','user_admin_profile.last_name')
//             .join('cafe_list', {'cafe_list.id' : 'cafe_dynamic.cafe_list_id'})
//             .join('user_admin_profile', { 'user_admin_profile.user_admin_id': 'cafe_dynamic.user_admin_id' }).limit(limits).offset(pageno*limits)  
//             .then((data) => {
//                 //console.log(data);

//                     (async () => {
//                         let cafeCount= await knex('cafe_dynamic').count('id as cnt')
//                         let cafe={
//                             'cnt':cafeCount[0].cnt
//                         }
//                         console.log(cafe.cnt,"hi")
//                         res.status(200).send({status:true,msg:"All Resturant Details",NUMBEROFCAFE:cafe.cnt,data})
//                         //res.status(200).send(br.withSuccess("All Restaurant Details",data))
//                         //console.log(data[0]);
//                         })();


//             }).catch((err) => {
//                 console.error({ "error": err });
//                 res.status(500).send(err.message)
//                 console.log(err.message);
//             })  
//     } catch (e) {
//         console.log(e)
//         res.status(500).send(br.withError("server error"));
//     }
// }


// Get by cafe_list_id
// const getRestaurantByCafe_list_id = (req, res) => {
//     try {
//         //console.log(req.params.id);
//         knex.select('*')
//             .from('cafe_details')
//             .where({ cafe_list_id: req.params.cafe_list_id })
//             .then((data) => {
//                 //console.log(data);
//                 if (data.length > 0) {
//                     res.status(200).send(br.withSuccess("Restaurant Details", data[0]))
//                     console.log(data[0]);
//                 } else {
//                     res.status(404).send(br.withError("Restaurant not found"));
//                 }
//             }).catch((err) => {
//                 res.status(500).send(err.message)
//                 console.log(err.message);
//             });
//     } catch (e) {
//         console.log(e);
//         res.status(500).send(br.withError(''));
//     }
// }


//post  general information of cafe

// const generalInformation = (req, res) => {
//     const cafe_list_id = parseInt(req.params.cafe_list_id)
//     console.log(cafe_list_id)

//     if (cafe_list_id > 0) {
//         const user = {
//             cafe_list_id: cafe_list_id,
//             cafe_slogan: req.body.slogan,
//             logo_image_id: req.body.logo_image_id
//         }
//         console.log(user)

//         knex("cafe_details").select("*").where("cafe_list_id", req.params.cafe_list_id).insert(user)
//             .then((data) => {
//                 res.status(200).send({ message: " general information successfully Added", status: true })
//             })
//             .catch((err) => {
//                 if (err) {
//                     console.log(err);
//                     res.status(400).send({ error: err })
//                 }
//             })

//     } else {
//         return helper.sendError(res, "invalid_Cafe_list_id")
//     }
// }


const viewprofile = ( req, res ) => {
    try {
        knex( 'cafe_dynamic ' ).select( 'cafe_list.uid', 'cafe_list.status', 'cafe_list.cafe_name', 'cafe_dynamic.total_item', 'cafe_dynamic.total_order', 'cafe_dynamic.is_most_visited', 'cafe_dynamic.is_new_opening', 'cafe_dynamic.is_featured', 'user_admin_profile.first_name', 'user_admin_profile.last_name' )
            .join( 'cafe_list', { 'cafe_list.id': 'cafe_dynamic.cafe_list_id' } )
            .join( 'user_admin_profile', { 'user_admin_profile.user_admin_id': 'cafe_dynamic.user_admin_id' } )
            .then( ( data ) => {
                console.log( data );
                if ( data.length > 0 ) {
                    res.status( 200 ).send( br.withSuccess( "All Restaurant Details", data ) )
                    console.log( data[0] );
                } else {
                    br.sendDatabaseError( res, "The table dosn't contain any data" )
                    console.log( "empty table is there, please insert the data then you will get that data back" );
                }
            } ).catch( ( err ) => {
                console.error( { "error": err } );
                res.status( 500 ).send( err.message )
                console.log( err.message );
            } )
    } catch ( e ) {
        console.log( e )
        res.status( 500 ).send( br.withError( "server error" ) );
    }
}


// 'cafe_list.status','cafe_list.restaurant_name','cafe_list.email','cafe_dynamic.is_most_visited','cafe_dynamic.is_new_opening','cafe_dynamic.is_featured','user_admin_profile.first_name','user_admin_profile.last_name'


// .leftJoin('cafe_list', {'cafe_list.id' : 'cafe_dynamic.cafe_list_id'})
//         .leftJoin('cafe_details', { 'cafe_details.cafe_list_id': 'cafe_dynamic.cafe_list_id' }) 
//         .leftJoin('cafe_contact', { 'cafe_contact.cafe_list_id': 'cafe_dynamic.cafe_list_id' }) 
//         .leftJoin('cafe_gallery', { 'cafe_gallery.cafe_list_id': 'cafe_dynamic.cafe_list_id' }) 

// Get generalInformation
const get_generalInformation = ( req, res ) => {
    console.log( req.params.cafe_list_id )
    const cafe_list_id = Number( req.params.cafe_list_id )
    // console.log(cafe_list_id)
    if ( cafe_list_id > 0 ) {
        knex( 'cafe_dynamic ' ).select( 'cafe_dynamic.id', 'cafe_dynamic.cafe_list_id', 'cafe_details.cafe_about', 'cafe_details.cafe_slogan', 'cafe_details.cafe_price_range', 'cafe_dynamic.average_rating', 'cafe_dynamic.is_most_visited', 'cafe_dynamic.is_new_opening', 'cafe_dynamic.is_featured', 'cafe_dynamic.total_review', 'cafe_dynamic.user_admin_id', 'cafe_list.cafe_name', 'cafe_list.email', 'cafe_list.city', 'cafe_list.status', 'cafe_list.uid', 'cafe_details.logo_image_id', 'cafe_details.is_veg', 'cafe_details.is_non_veg', 'cafe_details.opening_time', 'cafe_details.fssai_certificate_url', 'cafe_details.closing_time', 'cafe_contact.mobile_number', 'cafe_contact.website_url', 'cafe_contact.social_facebook_url', 'cafe_contact.social_twitter_url', 'cafe_contact.social_instagram_url', 'cafe_contact.social_linkedin_url', 'cafe_contact.address_1', 'cafe_contact.address_2', 'cafe_contact.state', 'cafe_contact.pin_code', 'cafe_contact.country', 'cafe_contact.latitude', 'cafe_contact.longitude' ).where( 'cafe_dynamic.cafe_list_id', cafe_list_id )
            .join( 'cafe_list', { 'cafe_list.id': 'cafe_dynamic.cafe_list_id' } )
            .join( 'cafe_details', { 'cafe_details.cafe_list_id': 'cafe_dynamic.cafe_list_id' } )
            .join( 'cafe_contact', { 'cafe_contact.cafe_list_id': 'cafe_dynamic.cafe_list_id' } )
            // .join('cafe_gallery', { 'cafe_gallery.cafe_list_id': 'cafe_dynamic.cafe_list_id' })
            .then( ( row ) => {
                const output = [];
                (async () => {
                    let imageCount= await knex( 'cafe_gallery' ).count('id as CNT').where( { 'cafe_gallery.cafe_list_id': cafe_list_id } )
                    output.push(imageCount[0].CNT)
                    knex( 'cafe_gallery' ).select( '*' ).orderBy( 'cafe_gallery.image_position', 'asc' ).where( { 'cafe_gallery.cafe_list_id': cafe_list_id, 'cafe_gallery.is_deleted': false } ).then( ( data ) => {
                        //    console.log(data);
                        for ( let e of data ) {
                            //  console.log("this is the "+JSON.stringify(e));
                            output.push( e );
                        }
                        //    console.log("Here "+output);
                        res.send( { message: row, gallery: output, status: true } )
                    } ).catch( ( err ) => {
                        res.json( {
                            message: err
                        } )
                    } )
                })();
                

            } )
            .catch( ( err ) => {
                res.json( {
                    message: err
                } )
            } )

    } else {
        return helper.sendError( res, "invalid_Cafe_list_id" )
    }
}

const post_generalinfo = async ( req, res ) => {
    try {
        console.log( "yes" )
        const v = new Validator( req.body, {
            cafe_name: 'required',
            email: 'required',
            mobile_number: 'required',
            cafe_slogan: 'required',
            description: 'required',
            is_featured: 'required',
            is_most_visited: 'required',
            is_new_opening: 'required',
            is_veg: 'required',
            is_non_veg: 'required',
            status: 'required',
            logo_image_id: 'required'
        } )
        v.check().then( ( matched ) => {
            if ( !matched ) {
                res.status( 422 ).send( br.withError( 'Missed Required files', v.errors ) );
            } else {
                const cafe_list_id = Number( req.params.cafe_list_id )
                if ( cafe_list_id > 0 ) {
                    let cafe_list_update = {
                        cafe_name: req.body.cafe_name,
                        email: req.body.email,
                        status: req.body.status,
                    }
                    let cafe_details_update = {
                        cafe_slogan: req.body.cafe_slogan,
                        is_veg: req.body.is_veg,
                        is_non_veg: req.body.is_non_veg,
                        cafe_about: req.body.description,
                        logo_image_id: req.body.logo_image_id
                    }
                    let cafe_patani_update = {
                        is_featured: req.body.is_featured,
                        is_most_visited: req.body.is_most_visited,
                        is_new_opening: req.body.is_new_opening,
                    }

                    async function exec() {
                        await knex( 'cafe_list' ).where( 'cafe_list.id', cafe_list_id ).update( cafe_list_update );
                        await knex( 'cafe_details' ).where( 'cafe_details.cafe_list_id', cafe_list_id ).update( cafe_details_update );
                        await knex( 'cafe_contact' ).where( 'cafe_contact.cafe_list_id', cafe_list_id ).update( { mobile_number: req.body.mobile_number } );
                        await knex( 'cafe_dynamic' ).where( 'cafe_dynamic.cafe_list_id', cafe_list_id ).update( cafe_patani_update );
                    }

                    exec()
                    res.status( 200 ).send( br.withSuccess( ' Restaurant Data Updated' ) )
                } else {
                    br.sendError( res, {}, 'invalid form cafe_list_id' );
                }
            }
        } )

    } catch ( e ) {
        console.log( e );
        res.status( 500 ).send( br.withError( '' ) );
    }
}
// Address Information of cafe with cafe_list_id

const AddressInformation = ( req, res ) => {
    try {

        const v = new Validator( req.body, {
            address_1: 'required',
            address_2: 'required',
            city: 'required',
            state: 'required',
            country: 'required',
            pin_code: 'required|minLength:6',
            latitude: 'required',
            longitude: "required"
        } )
        v.check().then( ( matched ) => {
            if ( !matched ) {
                res.status( 422 ).send( br.withError( 'Missed Required files', v.errors ) );
            } else {
                let cafe_list_id = Number( req.params.cafe_list_id );
                if ( cafe_list_id > 0 ) {
                    knex.select( '*' ).from( 'cafe_contact' )
                        .where( 'cafe_list_id', cafe_list_id )
                        .then( ( data ) => {
                            if ( data.length > 0 ) {

                                let user = {
                                    address_1: req.body.address_1,
                                    address_2: req.body.address_2,
                                    state: req.body.state,
                                    country: req.body.country,
                                    pin_code: req.body.pin_code,
                                    latitude: req.body.latitude,
                                    longitude: req.body.longitude,
                                };

                                knex( 'cafe_contact' ).update( user ).where( 'cafe_contact.cafe_list_id', cafe_list_id ).then( ( data ) => {
                                    ( async () => {
                                        let payload1 = {
                                            'city': req.body.city
                                        }
                                        let updating = await knex( 'cafe_list' ).update( payload1 ).where( 'cafe_list.id', cafe_list_id )
                                        res.status( 200 ).send( br.withSuccess( ' AddressInformation Edited  successfully By Id', data[0] ) )
                                        console.log( "AddressInformation Added  successfully By Id" )
                                    } )();
                                } ).catch( ( err ) => {
                                    res.status( 500 ).send( err.message );
                                    console.log( err.message );
                                } )
                            } else {
                                res.status( 400 ).send( br.withError( 'AddressInformation data not found!' ) );
                                console.log( 'AddressInformation data not found' );
                            }
                        } );
                } else {
                    br.sendError( res, {}, 'invalid form cafe_list_id' );
                }
            }
        } )

    } catch ( e ) {
        console.log( e );
        res.status( 500 ).send( br.withError( '' ) );
    }
}


// GetAddressInformation by id
const get_AddressInformation = ( req, res ) => {
    try {
        knex.select( "*" ).from( "cafe_contact_data" )
            .where( { cafe_list_id: req.params.cafe_list_id } )
            .then( ( data ) => {
                if ( data.length > 0 ) {
                    res.status( 200 ).send( br.withSuccess( "AddressInformation Details", data[0] ) )
                    console.log( data[0] );
                } else {
                    res.status( 404 ).send( br.withError( "AddressInformation not found" ) );
                }
            } ).catch( ( err ) => {
                res.status( 500 ).send( err.message )
                console.log( err.message );
            } )
    } catch ( e ) {
        console.log( e )
        res.status( 500 ).send( br.withError( 'Internal server error' ) );
    }

}


const TimePrice = async ( req, res ) => {
    try {

        const v = new Validator( req.body, {
            opening_time: 'required',
            closing_time: 'required',
            cafe_price_range: 'required'
        } )
        v.check().then( ( matched ) => {
            if ( !matched ) {
                res.status( 422 ).send( br.withError( 'Missed Required files', v.errors ) );
            } else {
                let cafe_list_id = Number( req.params.cafe_list_id );
                if ( cafe_list_id > 0 ) {
                    knex.select( '*' ).from( 'cafe_details' )
                        .where( 'cafe_list_id', cafe_list_id )
                        .then( ( data ) => {
                            if ( data.length > 0 ) {
                                let user = {
                                    opening_time: req.body.opening_time,
                                    closing_time: req.body.closing_time,
                                    cafe_price_range: req.body.cafe_price_range,
                                };
                                knex( 'cafe_details' ).update( user ).where( 'cafe_list_id', cafe_list_id ).then( ( data ) => {
                                    res.status( 200 ).send( br.withSuccess( ' AddressInformation Edited  successfully By Id', data[0] ) )
                                    console.log( "Time Price info edited  successfully By Id" )
                                } ).catch( ( err ) => {
                                    res.status( 500 ).send( err.message );
                                    console.log( err.message );
                                } )
                            } else {
                                res.status( 400 ).send( br.withError( 'time price data not found!' ) );
                                console.log( 'time price data not found' );
                            }
                        } );
                } else {
                    br.sendError( res, {}, 'invalid form cafe_list_id' );
                }
            }
        } )

    } catch ( e ) {
        console.log( e );
        res.status( 500 ).send( br.withError( '' ) );
    }
}

// social Information of cafe 

const SocialInformation = async function ( req, res ) {
    try {
        let cafe_list_id = req.params.cafe_list_id;
        if ( !cafe_list_id > 0 ) return res.status( 400 ).send( {
            status: false,
            msg: "invalid cafe list id, please enter a valid one"
        } )
        let website_url = req.body.website_url;
        let social_twitter_url = req.body.social_twitter_url;
        let social_facebook_url = req.body;
        let social_instagram_url = req.body.social_instagram_url;
        let social_linkedin_url = req.body.social_linkedin_url;

        let user = {
            'website_url': website_url,
            'social_twitter_url': social_twitter_url,
            'social_facebook_url': social_facebook_url,
            'social_instagram_url': social_instagram_url,
            'social_linkedin_url': social_linkedin_url
        }
        let updating = await knex( 'cafe_contact' ).update( user ).where( 'cafe_contact.cafe_list_id', cafe_list_id )
        return res.status( 200 ).send( { status: true, msg: "info updated", updating } )

    } catch ( error ) {
        console.log( error )
        return res.status( 500 ).send( { ERROR: error } )
    }
}
// const SocialInformation = async (req, res) => {
//     try{
//         const v = new Validator(req.body,{
//             website_url:"required",
//             social_twitter_url:"required",
//             social_facebook_url:"required",
//             social_instagram_url:"required",
//             social_linkedin_url:"required",

//         })
//         v.check().then((matched) => {
//             if (!matched) {
//                 res.status(422).send(br.withError('Missed Required files', v.errors));
//             } else {
//                 let cafe_list_id = Number(req.params.cafe_list_id);
//                 if(cafe_list_id > 0){
//                 knex.select('*').from('cafe_list').where('cafe_list.id', cafe_list_id)
//                     .then((data) => {
//                         if (data.length > 0) {
//                             let user = {
//                                 website_url: req.body.website_url,
//                                 social_twitter_url: req.body.social_twitter_url,
//                                 social_facebook_url: req.body.social_facebook_url,
//                                 social_instagram_url: req.body.social_instagram_url,
//                                 social_linkedin_url: req.body.social_linkedin_url
//                             };
//                             knex('cafe_contact').update(user).where('cafe_list_id', cafe_list_id).then((data) => {
//                                 res.status(200).send(br.withSuccess(' SocialInformation Data Created', data[0]))
//                                 console.log("Restaurant Data Created")
//                             }).catch((err) => {
//                                 res.status(500).send(err.message);
//                                 console.log(err.message);
//                             })
//                         } else {
//                             res.status(400).send(br.withError('SocialInformation data not found!'));
//                             console.log('SocialInformation data not found');
//                         }
//                     }).catch((err) => {
//                         console.error({ "error ": err });
//                         res.status(500).send(err.message)
//                         console.log(err.message);
//                     })
//                 }
//                 else {
//                     br.sendError(res, {}, 'invalid form cafe_list_id');
//                 }
//             }
//         });
//     }catch (e) {
//         console.log(e);
//         res.status(500).send(br.withError(''));
// }
// }

// const user = {

//             // address_1:req.body.address_1,

//             website_url: req.body.website,
//             social_twitter_url: req.body.social_twitter,
//             social_facebook_url: req.body.social_facebook,
//             social_instagram_url: req.body.social_instagram,
//             social_linkedin_url: req.body.social_linkedin
//         }
//         console.log(user, req.params.cafe_list_id)

//         knex("cafe_contact").select("*").where("cafe_list_id", req.params.cafe_list_id).update(user)
//             .then((data) => {
//                 res.status(200).send({ message: "   Social  information Added successfully ", status: true })
//             })
//             .catch((err) => {
//                 if (err) {
//                     console.log(err);
//                     res.status(400).send({ error: err })
//                 }
//             })

//     } else {
//         return helper.sendError(res, "invalid_Cafe_list_id")
//     }
// }

// GetAddressInformation 
const GetSocialInformation = ( req, res ) => {
    const cafe_list_id = parseInt( req.params.cafe_list_id )

    if ( cafe_list_id > 0 ) {
        knex( "cafe_contact" ).select( "*" ).where( "cafe_list_id", req.params.cafe_list_id )
            .then( ( row ) => {
                res.send( { message: row, statu: true } )
            } )
            .catch( ( err ) => {
                res.json( {
                    message: err
                } )
            } )

    } else {
        return helper.sendError( res, "invalid_Cafe_list_id" )
    }
}


const imageInformation = ( req, res ) => {
    try {
        const v = new Validator( req.body, {
            cafe_image_name: "required",
            image_position: "required",
            server_image_id: "required",
            is_featured: "required",
        } )
        v.check().then( ( matched ) => {
            if ( !matched ) {
                res.status( 422 ).send( br.withError( 'Missed Required files', v.errors ) );
            } else {
                let cafe_list_id = Number( req.params.cafe_list_id );
                if ( cafe_list_id > 0 ) {
                    let user = {
                        cafe_list_id: cafe_list_id,
                        cafe_image_name: req.body.cafe_image_name,
                        image_position: req.body.image_position,
                        server_image_id: req.body.server_image_id,
                        is_featured: req.body.is_featured
                    };

                    knex.select( '*' ).from( 'cafe_gallery' ).andWhere( {
                        'cafe_gallery.cafe_list_id': cafe_list_id,
                        'cafe_gallery.is_featured': "1",
                        'cafe_gallery.is_deleted': false,
                    } )
                        .then( ( data ) => {
                            if ( data.length > 0 && user.is_featured == "1" ) {
                                // console.log(data)
                                // console.log("---------------------")
                                knex( 'cafe_gallery' ).update( user ).andWhere( {
                                    'cafe_gallery.cafe_list_id': cafe_list_id,
                                    'cafe_gallery.is_featured': "1"
                                } ).then( ( data ) => {
                                    res.status( 200 ).send( br.withSuccess( ' Image Data Created', data[0] ) )
                                    console.log( "Restaurant Data Created" )
                                } ).catch( ( err ) => {
                                    res.status( 500 ).send( err.message );
                                    console.log( err.message );
                                } )
                            } else {
                                knex( 'cafe_gallery' ).insert( user ).then( ( data ) => {
                                    res.status( 200 ).send( br.withSuccess( ' Cafe Gallery Data Created', data[0] ) )
                                } )
                                    .catch( ( err ) => {
                                        res.status( 500 ).send( err.message );
                                        console.log( err.message );
                                    } )
                            }
                        } ).catch( ( err ) => {
                            console.error( { "error ": err } );
                            res.status( 500 ).send( err.message )
                            console.log( err.message );
                        } )
                } else {
                    br.sendError( res, {}, 'invalid form cafe_list_id' );
                }
            }
        } );
    } catch ( e ) {
        console.log( e );
        res.status( 500 ).send( br.withError( '' ) );
    }
}



const deleteImage = ( req, res ) => {
    try {
        let cafe_gallery_id = Number( req.params.id );
        if ( cafe_gallery_id > 0 ) {

            knex( 'cafe_gallery' ).update( {is_deleted : true} ).where( {
                'cafe_gallery.id': cafe_gallery_id
            } )
                .then( ( data ) => {
                            res.status( 200 ).send( br.withSuccess( ' Image deleted' ) )
                            // console.log( "Restaurant Data Created" )
                        } ).catch( ( err ) => {
                            res.status( 500 ).send( err.message );
                            console.log( err.message );
                        } )
        } else {
            br.sendError( 'invalid form cafe_list_id' );
        }
    } catch ( e ) {
        console.log( e );
        res.status( 500 ).send( br.withError( '' ) );
    }
}




const document = async ( req, res ) => {
    const v = new Validator( req.body, {
        fssai_certificate_url: "required",
    } )
    v.check().then( ( matched ) => {
        if ( !matched ) {
            res.status( 422 ).send( br.withError( 'Missed Required files', v.errors ) );
        } else {
            let cafe_list_id = Number( req.params.cafe_list_id );
            if ( cafe_list_id > 0 ) {
                let user = {
                    fssai_certificate_url: req.body.fssai_certificate_url,
                };

                knex.select( '*' ).from( 'cafe_details' ).andWhere( { 'cafe_details.cafe_list_id': cafe_list_id } )
                    .then( ( data ) => {
                        if ( data.length > 0 ) {
                            // console.log(data)
                            // console.log("---------------------")
                            knex( 'cafe_details' ).update( user ).andWhere( { 'cafe_details.cafe_list_id': cafe_list_id } ).then( ( data ) => {
                                res.status( 200 ).send( br.withSuccess( ' Image Data Created', data[0] ) )
                                console.log( "Restaurant Data Created" )
                            } ).catch( ( err ) => {
                                res.status( 500 ).send( err.message );
                                console.log( err.message );
                            } )
                        } else {
                            res.status( 400 ).send( br.withError( 'Information data not found!' ) );
                            console.log( 'Information data not found' );
                        }
                    } ).catch( ( err ) => {
                        console.error( { "error ": err } );
                        res.status( 500 ).send( err.message )
                        console.log( err.message );
                    } )
            } else {
                br.sendError( res, {}, 'invalid form cafe_list_id' );
            }
        }
    } );
}


module.exports = {
    cafeList,
    generalInfoCafe,
    post_generalinfo,
    Createrestaurant,
    viewprofile,
    get_generalInformation,
    AddressInformation,
    get_AddressInformation,
    SocialInformation,
    GetSocialInformation,
    imageInformation,
    TimePrice,
    document,
    deleteImage
}



