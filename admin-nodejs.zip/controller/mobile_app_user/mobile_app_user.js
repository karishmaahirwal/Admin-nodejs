const knex = require("../../db/db_knex")
const helper = require("../../helper/helper");
const logger = require("../../helper/logger");
const {Validator} = require('node-input-validator');
const br = require("../../helper/baseResponse");
const baseResponse=require("../../helper/baseResponse");
const jwt = require("jsonwebtoken");

const clearCustomerProfileDynamicDuplicateData = async (req, res) => {
    try {
        let allCusProDup = await knex.select('a.*')
            .fromRaw('(select user_customer_id as cus_id, count(*) as ct ' +
                'from user_customer_profile group by user_customer_id) as a')
            .where('a.ct', '>', 1);

        logger.info(`Total Profile Duplicate found ${allCusProDup.length}`);

        let idsToDelete = [];

        for (let cus of allCusProDup) {
            let profiles = await knex('user_customer_profile').select('id').where('user_customer_id', cus.cus_id);
            profiles.shift();
            logger.info(`${JSON.stringify(cus)} => deleting ${profiles.length}`);

            idsToDelete = [
                ...idsToDelete,
                ...profiles.map(d => d.id)
            ];

            if (idsToDelete.length > 500) {
                await knex('user_customer_profile').whereIn('id', idsToDelete).del();
                idsToDelete = [];
            }
        }

        if (idsToDelete.length > 0) {
            await knex('user_customer_profile').whereIn('id', idsToDelete).del();
        }

        let allCusDyDup = await knex.select('a.*')
            .fromRaw('(select user_customer_id as cus_id, count(*) as ct ' +
                'from user_customer_dynamic group by user_customer_id) as a')  //
            .where('a.ct', '>', 1);

        logger.info(`Total Dynamic Duplicate found ${allCusDyDup.length}`);
        idsToDelete = [];

        for (let cus of allCusDyDup) {
            let dynamics = await knex('user_customer_dynamic').select('id').where('user_customer_id', cus.cus_id);
            dynamics.shift();
            logger.info(`${JSON.stringify(cus)} => deleting ${dynamics.length}`);

            idsToDelete = [
                ...idsToDelete,
                ...dynamics.map(d => d.id)
            ];

            if (idsToDelete.length > 500) {
                await knex('user_customer_dynamic').whereIn('id', idsToDelete).del();
                idsToDelete = [];
            }
        }

        if (idsToDelete.length > 0) {
            await knex('user_customer_dynamic').whereIn('id', idsToDelete).del();
        }

        br.sendSuccess(res, {
            profile: `Total Profile Duplicate found ${allCusProDup.length}`,
            dynamic: `Total Dynamic Duplicate found ${allCusDyDup.length}`
        }, 'Data Cleared!');

    } catch (e) {
        br.sendServerError(res, e);
    }
}

const List_Mobile_App_User = async (req, res) => {
    try {
        let pageno = req.query.pageno;
        let limits = req.query.limits;
        if (!limits) {
            limits = 10;
        }
        if (!pageno) {
            pageno = 0;
        } else {
            pageno = pageno - 1;
        }

        knex('user_customer')
            .select('user_customer.id as user_customer_id',
            'user_customer_profile.first_name',
            'user_customer_profile.last_name',
            'user_customer_profile.city',
            'user_customer.email',
            'user_customer.mobile_number',
            'user_customer_dynamic.order_count',
            'user_customer_dynamic.review_count',
            'user_customer_dynamic.last_active',
            'user_customer.status')
            .limit(limits)
            .offset(pageno*limits)
            .leftJoin('user_customer_dynamic', { 'user_customer_dynamic.user_customer_id': 'user_customer.id' })
            .leftJoin('user_customer_profile', { 'user_customer_profile.user_customer_id': 'user_customer.id' })
            .then((data) => {
                console.log(data);
                if (data.length > 0) {

                    (async () => {
                        let getCountOfCustomer = await knex('user_customer').count('id as cnt')
                        let counting = {
                            'cnt': getCountOfCustomer[0].cnt
                        }
                        console.log(counting.cnt, "hi")
                        res.status(200).send({
                            status: true,
                            msg: "menu category list",
                            TOTALCOUNTOFUSER: counting.cnt,
                            data
                        })
                    })();
                    // res.status(200).send(br.withSuccess("All mobile User Details", data))
                    // console.log(data[0]);
                } else {
                    br.sendDatabaseError(res, "The table dosn't contain any data")
                    console.log("empty table is there, please insert the data then you will get that data back");
                }
            }).catch((err) => {
            console.error({"error": err});
            res.status(500).send(err.message)
            console.log(err.message);
        })
    } catch (e) {
        console.log(e)
        res.status(500).send(br.withError("server error"));
    }
}


const Create_Mobile_App_User= async function(req,res){
    try{
         let email=req.body.email;
         if(!email.length>0)  return res.status(400).send({status:false,msg:"please enter a valid email"})
         let chkMail= await knex.select('*').from('user_customer').where('user_customer.email',email)
         if(chkMail.length>0) return res.status(400).send({status:false,msg:"email already exist"})
         let mobile_number= parseInt(req.body.mobile_number);
         if(!mobile_number>0 || mobile_number===undefined) return res.status(400).send({status:false,msg:"please enter a valid mobile number"})
         let chkMobile= await knex.select('*').from('user_customer').where('user_customer.mobile_number',mobile_number)
         if(chkMobile.length>0) return res.status(400).send({status:false,msg:"mobile number already exist"})
         let status=req.body.status;
         let userCustomerData={
            'email':email,
            'mobile_number':mobile_number,
            'status':status,
            'user_role_id':5
         }
         let insertInUserCustomer= await knex('user_customer').insert(userCustomerData)
         let userID={
            'id':insertInUserCustomer[0]
         }
         console.log(userID.id)
         let gender=req.body.gender;
         if(!gender.length>0) return res.status(400).send({status:false,msg:"please enter gender data"})
         let date_of_birth= req.body.date_of_birth;
         let first_name=req.body.first_name;
         let last_name=req.body.last_name;
         if(!first_name.length>0) return res.status(400).send({status:false,msg:"please enter some data"})
         if(!last_name.length>0) return res.status(400).send({status:false,msg:"please enter some data"})
         let profile_pic_image_id=req.body.profile_pic_image_id;
         if(!profile_pic_image_id.length>0) return res.status(400).send({status:false,msg:"please enter some value"})
         let userCustomerProfileData={
            'gender':gender,
            'first_name':first_name,
            'last_name':last_name,
            'date_of_birth':date_of_birth,
            'user_customer_id':userID.id,
            'profile_pic_image_id':profile_pic_image_id
         }
         let insertInUserCustomerProfile= await knex('user_customer_profile').insert(userCustomerProfileData)
         return res.status(201).send({status:true,msg:"user added to database"})
    }
    catch(error){
        console.log(error)
        return res.status(500).send({ERROR:error})
    }
}


const List_Mobile_App_UserById = async (req, res) => {
    try {

        const id=req.params.userId;
        knex('user_customer').select('user_customer.id as user_customer_id','user_customer_profile.first_name','user_customer_profile.last_name','user_customer.mobile_number','user_customer.email','user_customer_profile.gender','user_customer.status','user_customer_profile.profile_pic_image_id','user_customer_profile.date_of_birth').where('user_customer.id',id)
            //.leftJoin('user_customer_dynamic', { 'user_customer_dynamic.user_customer_id': 'user_customer.id' })
            .join('user_customer_profile', { 'user_customer_profile.user_customer_id': 'user_customer.id' })
            .then((data) => {
                console.log(data);
                if (data.length > 0) {
                    res.status(200).send(br.withSuccess("All mobile User Details", data))
                    // console.log(data[0]);
                } else {
                    br.sendDatabaseError(res, "The table dosn't contain any data")
                    console.log("empty table is there, please insert the data then you will get that data back");
                }
            }).catch((err) => {
            console.error({"error": err});
            res.status(500).send(err.message)
            console.log(err.message);
        })
    } catch (e) {
        console.log(e)
        res.status(500).send(br.withError("server error"));
    }
}


const Edit_Mobile_App_User = async (req, res) => {
    try {
        const id = req.params.userId;
        let user_customer_data = {
            mobile_number: req.body.mobile_number,
            email: req.body.email,
            status: req.body.status,
        }
        let user_customer_profile_data = {
            gender: req.body.gender,
            date_of_birth: req.body.date_of_birth,
            first_name: req.body.first_name,
            last_name: req.body.last_name,
            profile_pic_image_id: req.body.profile_pic_image_id,
        }
        await knex('user_customer').update(user_customer_data).where('user_customer.id', id);
        knex('user_customer_profile').update(user_customer_profile_data).where('user_customer_profile.user_customer_id', id)
            .then((data) => {
                console.log(data);
                res.status(200).send(br.withSuccess("Updated Customer", data))
            }).catch((err) => {
            console.error({"error": err});
            res.status(500).send(err.message)
            console.log(err.message);
        })
    } catch (e) {
        console.log(e)
        res.status(500).send(br.withError("server error"));
    }
}

const GetOrderHistory= async function(req,res){
    try{
     let order_list_id= parseInt(req.params.order_list_id);
     if(!order_list_id>0) return res.status(400).send({status:false,msg:"please enter a valid order list id"})
     let chekOrderListId= await knex.select('*').from('order_list').where('order_list.id',order_list_id)
     if(!chekOrderListId.length>0) return res.status(404).send({status:false,msg:"order list does not exist"})
     let getOrderListData= await knex.select('order_list.id as order_list_id'
     ,'order_list.uid as order_list_uid',
     'order_list.start_date_time','order_list.end_date_time','order_list.approved_by','order_payment.payment_mode','order_payment.amount',
     'order_payment.discount','order_payment.status as order_payment_status','user_customer_profile.first_name','user_customer_profile.last_name','cafe_list.cafe_name',
     'order_list.qr_code_id','qr_code.table_title'
     ,'user_admin_profile.first_name','user_admin_profile.last_name').from('order_list')
     .join('order_payment',{'order_payment.order_list_id':'order_list.id'})
     .join('cafe_list',{'cafe_list.id':'order_list.cafe_list_id'})
     .join('user_customer_profile',{'user_customer_profile.user_customer_id':'order_list.user_customer_id'})
     .join('qr_code',{'qr_code.id':'order_list.qr_code_id'})
     .join('user_admin_profile',{'user_admin_profile.user_admin_id':'order_list.approved_by'})
     .whereIn('order_list.status', [2, 3])
     .where('order_list.id',order_list_id)
    

    let getOrderDetailData= await knex.select('order_detail.id as order_detail_id',
    'order_detail.uid as order_detail_uid',
    'order_detail.book_date_time',
    'order_detail.serve_date_time','menu_item.menu_item_name',
    'menu_item.measure_unit','menu_item_price.price',
    'order_detail.cooking_status','user_admin_profile.first_name',
    'user_admin_profile.last_name','order_detail.cooking_instruction','order_detail.order_list_id').from('order_list')
    .leftJoin('order_detail',{'order_detail.order_list_id':'order_list.id'})
    .leftJoin('user_admin_profile',{'user_admin_profile.user_admin_id':'order_detail.served_by'})
    .join('menu_item_price',{'menu_item_price.id':'order_detail.menu_item_price_id'})
    .join('menu_item',{'menu_item.id':'menu_item_price.menu_item_id'})
    .where('order_list.id',order_list_id)
    .whereIn('order_list.status', [2, 3])
    
     return res.status(200).send({status:true,msg:"order list details",getOrderListData,getOrderDetailData})

    }
    catch(error){
        console.log(error)
        return res.status(500).send({ERROR:error})
    }
}
const orderHistory = async (req, res) => {
    try {
        const id = parseInt(req.params.userId);

        if (id > 0) {
            knex.select('o_l.id',
                'o_l.uid',
                'o_l.status',
                'o_l.user_customer_id',
                'u_c.first_name',
                'u_c.last_name',
                'c_l.cafe_name',
                'o_p.amount',
                'o_p.discount',
                'o_p.created_at',
                'o_p.updated_at',
                'o_p.payment_mode',
                'o_p.status as payment_status',
                'o_l.start_date_time',
                'o_l.end_date_time',
                'o_l.approved_by')
                .from('order_list as o_l')
                .whereIn('o_l.status', [2, 3])
                .where('o_l.user_customer_id', id)
                .join('cafe_list as c_l', {'o_l.cafe_list_id': 'c_l.id'})
                .join('user_customer_profile as u_c', {'o_l.user_customer_id': 'u_c.user_customer_id'})
                .leftJoin('order_payment as o_p', {'o_l.id': 'o_p.order_list_id'})
                .orderBy('o_l.created_at', 'desc')
                .then((data) => {
                    br.sendSuccess(res, data, 'All Order History Details!');
                }).catch((err) => {
                br.sendDatabaseError(res, err);
            })
        } else {
            br.sendError(res, {}, 'Please send a valid user id');
        }
    } catch (e) {
        br.sendServerError(res, e);
    }
}

const orderHistoryAll = async (req, res) => {
    try {
        const userId = parseInt(req.query.userId);

        let pageNo = parseInt(req.query.pageNo);
        let limit = parseInt(req.query.limit);

        if (isNaN(pageNo) || pageNo < 1) {
            pageNo = 1;
        }

        if (isNaN(limit) || limit < 1) {
            limit = 10;
        }

        let orderHistoryQry = knex.select('o_l.id',
            'o_l.uid',
            'o_l.status',
            'o_l.user_customer_id',
            'u_c.first_name',
            'u_c.last_name',
            'c_l.cafe_name',
            'o_p.amount',
            'o_p.discount',
            'o_p.created_at',
            'o_p.updated_at',
            'o_p.payment_mode',
            'o_p.status as payment_status',
            'o_l.start_date_time',
            'o_l.end_date_time',
            'o_l.approved_by')
            .from('order_list as o_l')
            .whereIn('o_l.status', [2, 3])
            .join('cafe_list as c_l', {'o_l.cafe_list_id': 'c_l.id'})
            .join('user_customer_profile as u_c', {'o_l.user_customer_id': 'u_c.user_customer_id'})
            .leftJoin('order_payment as o_p', {'o_l.id': 'o_p.order_list_id'})
            .orderBy('o_l.created_at', 'desc')
            .limit(limit)
            .offset((pageNo - 1) * limit);

        let orderHistoryTotalQry = knex.count('* as ct')
            .from('order_list as o_l')
            .whereIn('o_l.status', [2, 3])
            .join('cafe_list as c_l', {'o_l.cafe_list_id': 'c_l.id'})
            .join('user_customer_profile as u_c', {'o_l.user_customer_id': 'u_c.user_customer_id'})
            .leftJoin('order_payment as o_p', {'o_l.id': 'o_p.order_list_id'})

        if (userId > 0) {
            orderHistoryQry.where('o_l.user_customer_id', userId)
            orderHistoryTotalQry.where('o_l.user_customer_id', userId)
        }

        Promise.all([
            orderHistoryQry,
            orderHistoryTotalQry
        ]).then(([data, total]) => {
            let totalCount = total[0].ct;
            br.sendSuccess(res, helper.getPaginateResponse(totalCount, limit, pageNo, data), 'All Order History Details!');
        }).catch((err) => {
            br.sendDatabaseError(res, err);
        });

    } catch (e) {
        br.sendServerError(res, e);
    }
}
// const orderReview= async function (req,res){
//  try{
//      let id = parseInt(req.params.userId);
//      //let getOrderRatingData=0;
//      let getReviewData= await knex.select('order_review.id as order_review_id',
//                  'order_review.order_list_id',
//                  'order_review.experience_rating',
//                  'order_review.review_detail',
//                  'order_review.is_featured',
//                  'order_review.user_customer_id',
//                  'user_customer_profile.first_name',
//                  'user_customer_profile.last_name',
//                  'user_customer_profile.gender',
//                  'user_customer_profile.profile_pic_image_id',
//                  'cafe_list.cafe_name',
//                  'cafe_list.email as cafe_email',
//                  'cafe_list.city as cafe_city',
//                  'order_review.created_at',
//                  'order_review.updated_at').from('order_review')
//      .join('cafe_list',{'cafe_list.id':'order_review.cafe_list_id'})
//      .join('user_customer_profile',{'user_customer_profile.user_customer_id':'order_review.user_customer_id'})
//      .where('order_review.user_customer_id',id)

//      let getOrderrating= await knex.select('order_rating.id as order_rating_id',
//      'order_rating.order_list_id',
//      'order_rating.rating',
//      'order_rating.menu_item_price_id').from('order_rating')
//      .join('order_review',{'order_review.order_list_id':'order_rating.order_list_id'})
//      .where('order_review.user_customer_id',id)
// let allreviews= [];
// for(let review of getReviewData ) {
//     let allratings= [];
//     for(let rating of getOrderrating){
//   if(review.order_list_id === rating.order_list_id){
//     console.log("1",review.order_list_id)
//     console.log("2",rating.order_list_id)
//     allratings.push(rating)
//   }
//     }
//     allreviews.push({
//         ...review,
//         getOrderrating: allratings
//     })
// }
// baseResponse.sendSuccess(res,allreviews, 'all reviws')
     
    
//    // return res.status(200).send({status:true,getReviewData,getOrderrating})
//  }
     
//  catch(error){
//     console.log(error)
//     return res.status(500).send({ERROR:error})
//  }
// }

// const orderReview = async (req, res) => {
//     try {
//         const id = req.params.userId;
//         knex.select('r.id as order_review_id',
//             'r.experience_rating',
//             'r.review_detail',
//             'r.is_featured',
//             'r.user_customer_id',
//             'u_c.first_name',
//             'u_c.last_name',
//             'u_c.gender',
//             'u_c.profile_pic_image_id',
//             'c_l.cafe_name',
//             'c_l.email as cafe_email',
//             'c_l.city as cafe_city',
//             'r.created_at',
//             'r.updated_at')
//             .from({r: 'order_review'})
//             .where('r.user_customer_id', id)
//             .join('user_customer_profile as u_c', {'r.user_customer_id': 'u_c.user_customer_id'})
//             .join('cafe_list as c_l', {'r.cafe_list_id': 'c_l.id'})
//             .orderBy('r.created_at', 'desc')
//             .then((data) => {
//                 br.sendSuccess(res, data, 'All Reviews!');
//             }).catch((err) => {
//             br.sendDatabaseError(res, err);
//         })

//     } catch (e) {
//         br.sendServerError(res, e);
//     }
// }

const orderReviewAll = async (req, res) => {
    try {
        const userId = parseInt(req.query.userId);
        let pageNo = parseInt(req.query.pageNo);
        let limit = parseInt(req.query.limit);

        if (isNaN(pageNo) || pageNo < 1) {
            pageNo = 1;
        }

        if (isNaN(limit) || limit < 1) {
            limit = 10;
        }

        let reviewQry = knex.select('r.id as order_review_id',
            'r.uid as order_review_uid',
            'r.experience_rating',
            'r.review_detail',
            'r.is_featured',
            'r.user_customer_id',
            'u_c.first_name',
            'u_c.last_name',
            'u_c.gender',
            'u_c.profile_pic_image_id',
            'c_l.cafe_name',
            'c_l.email as cafe_email',
            'c_l.city as cafe_city',
            'r.created_at',
            'r.updated_at')
            .from({r: 'order_review'})
            .join('user_customer_profile as u_c', {'r.user_customer_id': 'u_c.user_customer_id'})
            .join('cafe_list as c_l', {'r.cafe_list_id': 'c_l.id'})
            .orderBy('r.created_at', 'desc')
            .limit(limit)
            .offset((pageNo - 1) * limit);

        let reviewTotalQry = knex.from({r: 'order_review'})
            .count('* as ct')
            .join('user_customer_profile as u_c', {'r.user_customer_id': 'u_c.user_customer_id'})
            .join('cafe_list as c_l', {'r.cafe_list_id': 'c_l.id'});

        if (userId > 0) {
            reviewQry.where('r.user_customer_id', userId);
            reviewTotalQry.where('r.user_customer_id', userId);
        }


        Promise.all([reviewQry, reviewTotalQry]).then(([data, total]) => {
            let totalCount = total[0].ct;
            br.sendSuccess(res, helper.getPaginateResponse(totalCount, limit, pageNo, data), 'All Reviews!');
        }).catch((err) => {
            br.sendDatabaseError(res, err);
        })

    } catch (e) {
        br.sendServerError(res, e);
    }
}

const serchMobileAppUser = async function (req, res) {
    try {
        let s = req.query.s;
        if (s === undefined) {
            s = '';
        }

        let getList = knex.select('u_c.id as user_customer_id', 'u_c_p.first_name','u_c_p.last_name', knex.raw("concat(u_c_p.first_name, ' ', u_c_p.last_name) as full_name") )
            .from('user_customer as u_c')
            .join('user_customer_profile as u_c_p',{'u_c.id':'u_c_p.user_customer_id'})
            

        if (s.length > 0) {
            getList.whereRaw( `concat(u_c_p.first_name, ' ', u_c_p.last_name) like '${s}%'`);
        }

        getList = await getList;

        if (!getList > 0) {
            br.sendError(res, {}, "no data found", 404);
        } else {
            br.sendSuccess(res, getList, 'All customer list');
        }
    } catch (error) {
        br.sendDatabaseError(res, error);
    }
}
// const CreateMobileAppUser = async (req, res) => {
//     try {
//         const v = new Validator(req.body, {
//             // restaurant_name: 'required|minLength:3',
//             email: 'required',
//             mobile_number: 'required|minLength:10',
//             gender: 'required'
//         });
//         v.check().then((matched) => {
//             if (!matched) {
//                 res.status(422).send(br.withError('Missed Required files', v.errors));
//             } else {
//                 knex(').from('cafe_list')
//                     .then((data) => {
//                         if (data.length > 0) {
//                             let user = {
//                                 email: req.body.email,
//                                 mobile_number:req.body.mobile_number,
//                                 gender: req.body.gender,
//                             };
//                             knex('cafe_list').insert(user).then((data) => {
//                                 res.status(200).send(br.withSuccess(' mobile  Data Created', data[0]))
//                                 console.log("mobile Data Created")
//                             })
//                         } else {
//                             res.status(400).send(br.withError('mobile data not found!'));
//                             console.log('mobile data not found');
//                         }
//                     }).catch((err) => {
//                         console.error({ "error": err });
//                         res.status(500).send(err.message)
//                         console.log(err.message);
//                     })
//             }
//         });
//     } catch (e) {
//         console.log(e);
//         res.status(500).send(br.withError(''));
//     }
// }


// user_customer
// user_customer_profile

// Name
// email
// mobile_number
// gender
// Status
const getReviewById= async function(req,res){
    try{
        let review_id= parseInt(req.params.review_id);
        if(!review_id>0) return res.status(400).send({status:false,msg:"please enter a review id"})
        let getReviewData= await knex.select('order_review.id as order_review_id','order_review.uid as order_review_uid','cafe_list.cafe_name',
        'order_review.order_list_id',
        'order_review.experience_rating',
        'order_review.user_customer_id',
        'order_review.cafe_list_id',
        'order_review.review_detail','order_review.is_featured','user_customer_profile.first_name','user_customer_profile.last_name',
        'order_review.updated_at').from('order_review')
        //.join('order_rating',{'order_rating.order_review_id':'order_review.id'})
        .join('user_customer_profile',{'user_customer_profile.user_customer_id':'order_review.user_customer_id'})
        .join('cafe_list',{'cafe_list.id':'order_review.cafe_list_id'})
        .where('order_review.id',review_id)
        let getOrderList_id={
            'order_list_id':getReviewData[0].order_list_id
        }
        console.log("order_list_id",getOrderList_id.order_list_id)
        let getRatingData=await knex.select('order_rating.id as order_rating_id',
        'order_rating.order_list_id','order_rating.rating',
        'order_rating.menu_item_price_id',
        'order_rating.cafe_list_id',
        'order_rating.order_review_id','order_rating.created_at','order_rating.updated_at','order_review.uid','menu_item.menu_item_name','menu_item_price.price').from('order_rating')
        .join('order_review',{'order_review.order_list_id':'order_rating.order_list_id'})
        .join('menu_item_price',{'menu_item_price.id':'order_rating.menu_item_price_id'})
        .join('menu_item',{'menu_item.id':'menu_item_price.menu_item_id'})
        .where('order_rating.order_list_id',getOrderList_id.order_list_id)
       
        return res.status(200).send({status:true,msg:"order review details",getReviewData,getRatingData})
        // let all=[]
        // for(let reviewData of getReviewData) {
        //     let rating=[];
        //     for(let data1 of getRatingData){
        //         if(reviewData.order_list_id==data1.order_list_id){
        //         all.push({
        //             ...reviewData,
        //             getRatingData : data1
        //         })}
        //     }
            
        // }
        // br.sendSuccess(res, all, 'All Menu items on category');
        // let allCats = [];

        // for (let cat of getReviewData) {
        //     let items = [];
        //     for (let item of getRatingData) {
        //         if(cat.order_list_id === item.order_list_id){
        //             allCats.push({
        //                 ...cat,
        //                 getRatingData : items
        //             })
        //         }
        //     }
            
        // }
        // br.sendSuccess(res, allCats, 'All Menu items on category');
        
    }catch(error){
        console.log(error)
        return res.status(500).send({ERROR:error})
    }
}

const editReview= async function(req,res){
    try{
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];
        const decodedToken = jwt.verify(token, process.env.SECRET)
        req.Id = decodedToken.id;
        req.cafeId = decodedToken.cafe_list_id;
        console.log(req.cafeId)

        let order_review_id = parseInt(req.params.order_review_id);
        if(!order_review_id>0) return res.status(400).send({status:fasle,msg:"please enter a valid order review id"})
        let orderReview= await knex.select('*').from('order_review').where('order_review.id',order_review_id)
        if(!orderReview.length>0) return res.status(404).send({status:false,msg:"order review id does not exist"})
        let experience_rating = req.body.experience_rating;
            //let review_date=req.body.review_date;
            
            let review_detail = req.body.review_detail;
            let is_featured= req.body.is_featured
            let update1 = {
                'experience_rating': experience_rating,
                'review_detail': review_detail,
                'is_featured': is_featured
                }
            let updating1 = await knex('order_review').update(update1).where('order_review.id',order_review_id)
            return res.status(200).send({status: true, msg: "order review edited"})
            

            

        
    }
    catch(error){
     console.log(error)
     return res.status(500).send({ERROR:error})
    }
}


module.exports = {
    clearCustomerProfileDynamicDuplicateData,
    List_Mobile_App_User,
    Create_Mobile_App_User,
    Edit_Mobile_App_User,
    List_Mobile_App_UserById,
    orderHistory,
    orderHistoryAll,
    // orderReview,
    orderReviewAll,
    serchMobileAppUser,
    getReviewById,
    editReview,
    GetOrderHistory
    // CreateMobileAppUser
}


// user_customer
// user_customer_profile
