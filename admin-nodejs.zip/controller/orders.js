const {join} = require("path")
const knex = require("../db/db_knex")
const helper = require("../helper/helper");
const {Validator} = require('node-input-validator');
const br = require("../helper/baseResponse");
const baseResponse= require("../helper/baseResponse");
const logger = require("../helper/logger");
const e = require("express");

const getLiveOrders = (req, res) => {
    try {

        let pageNo = parseInt(req.query.pageno);
        let limits = req.query.limits;
        if (!limits) {
            limits = 10;
        }
        if (isNaN(pageNo) || pageNo < 1) {
            pageNo = 1;
        }

        let orderQry = knex.select('cafe_list.cafe_name',
            'order_list.qr_code_id',
            'order_detail.cooking_status',
            'order_detail.id',
            'order_detail.uid',
            'user_customer_profile.first_name',
            'user_customer_profile.last_name',
            'menu_item.menu_item_name',
            'menu_item_price.price',
            'order_detail.book_date_time',
            'order_detail.cooking_instruction',
            'order_detail.served_by',
            'order_detail.serve_date_time')
            .from('order_detail')
            .join('order_list', {'order_list.id': 'order_detail.order_list_id'})
            .join('user_customer_profile', {'user_customer_profile.user_customer_id': 'order_list.user_customer_id'})
            .join('cafe_list', {'cafe_list.id': 'order_detail.cafe_list_id'})
            .join('menu_item_price', {'menu_item_price.id': 'order_detail.menu_item_price_id'})
            .join('menu_item', {'menu_item.id': 'menu_item_price.menu_item_id'})
            .orderBy('order_detail.created_at', 'desc')
            .limit(limits)
            .offset((pageNo - 1) * limits);

        let orderTotalCountQry = knex('order_detail')
            .join('order_list', {'order_list.id': 'order_detail.order_list_id'})
            .join('user_customer_profile', {'user_customer_profile.user_customer_id': 'order_list.user_customer_id'})
            .join('cafe_list', {'cafe_list.id': 'order_detail.cafe_list_id'})
            .join('menu_item_price', {'menu_item_price.id': 'order_detail.menu_item_price_id'})
            .join('menu_item', {'menu_item.id': 'menu_item_price.menu_item_id'})
            .count('* as cnt');

        Promise.all([
            orderQry,
            orderTotalCountQry
        ]).then(([data, count]) => {
            let totalCount = count[0].cnt;
            br.sendSuccess(res, helper.getPaginateResponse(totalCount, limits, pageNo, data), 'All live order details')
        }).catch((err) => {
            br.sendDatabaseError(res, err);
        })

    } catch (e) {
        br.sendServerError(res, e);
    }

}

// knex.select('*')
//        .from({order_list: 'o_l'})
//        .join('order_details as o_d', {'o_l.id':'o_d.id'})
// 	  .join('order_details as o_d', {'o_l.id':'o_d.order_list_id'})
// 	  .join('order_payments as o_p', {'o_l.id':'o_p.order_list_id'})
// 	  .join('order_status_history as o_s_h', {'o_l.id':'o_s_h.order_list_id'})
// 	  .join('user_customer as u_C', {'o_l.id':'u_c.id'})
//        .join('cafe_list as c_l', {'o_l.id':'c_l.id'})
// 	  .join('qr_code as q_c', {'o_l.id':'q_c.order_list_id'})


const getLiveOrderDetailById = async (req, res) => {
    try {
        const id = parseInt(req.params.order_detail_id);

        if (id > 0) {
            let data = await knex.select('c_l.cafe_name',
                'o_l.qr_code_id',
                'o_d.cooking_status',
                'o_d.id',
                'o_d.uid',
                'u_c.first_name',
                'u_c.last_name',
                'm_i.menu_item_name',
                'm_i_p.price',
                'o_d.book_date_time',
                'o_d.cooking_instruction',
                'o_d.served_by',
                'o_d.serve_date_time')
                .from({o_d: 'order_detail'})
                .where('o_d.id', id)
                .join('order_list as o_l', {'o_d.order_list_id': 'o_l.id'})
                .join('user_customer_profile as u_c', {'o_l.user_customer_id': 'u_c.user_customer_id'})
                .join('menu_item_price as m_i_p', {'o_d.menu_item_price_id': 'm_i_p.id'})
                .join('menu_item as m_i', {'m_i_p.menu_item_id': 'm_i.id'})
                .join('qr_code as q_c', {'o_l.qr_code_id': 'q_c.id'})
                .leftJoin('menu_addon_price as m_a_p', {'o_d.menu_addon_price_id': 'm_a_p.id'})
                .leftJoin('menu_addon as m_a', {'m_a_p.menu_addon_id': 'm_a.id'})
                .join('cafe_list as c_l', {'c_l.id': 'o_d.cafe_list_id'});

            if (data.length > 0) {
                br.sendSuccess(res, data, "All LiveOrder Details by ID");
            } else {
                br.sendError(res, {}, "Order Details with order Id not found", 404);
            }
        } else {
            br.sendError(res, {}, 'Please enter a valid order id!');
        }
    } catch (e) {
        br.sendServerError(res, e);
    }

}


const Edit_Live_Order_Detail_by_ID = async (req, res) => {
    try {

        const v = new Validator(req.body, {
            cooking_status: 'required',
        })
        v.check().then((matched) => {
            if (!matched) {
                res.status(422).send(br.withError('Missed Required files', v.errors));
            } else {
                let id = Number(req.params.order_detail_id);
                let user = {
                    cooking_status: req.body.cooking_status,
                }
                if (id > 0) {
                    knex('order_detail').where('order_detail.id', id).update(user).then((data) => {
                        res.status(200).send(br.withSuccess(' order detail Edited successfully By Id', data[0]))
                        console.log("order detail Edited successfully By Id")
                    }).catch((err) => {
                        res.status(500).send(err.message);
                        console.log(err.message);
                    })
                } else {
                    br.sendError(res, {}, 'invalid form cafe_list_id');
                }
            }
        })

    } catch (e) {
        console.log(e);
        res.status(500).send(br.withError(''));
    }
}


const getOrderHistory = async (req, res) => {
    try {


        let pageNo = parseInt(req.query.pageno);
        let limits = req.query.limits;
        if (!limits) {
            limits = 10;
        }
        if (isNaN(pageNo) || pageNo < 1) {
            pageNo = 1;
        }

        let historyQry = knex.select('o_l.id',
            'o_l.uid',
            'o_l.status',
            'u_c.first_name',
            'u_c.last_name',
            'c_l.cafe_name',
            'o_p.amount',
            'o_p.discount',
            'o_p.created_at',
            'o_p.updated_at',
            'o_p.payment_mode',
            'o_p.status as payment_status',
            'o_l.start_date_time',
            'o_l.end_date_time',
            'o_l.approved_by')
            .from('order_list as o_l')
            .whereIn('o_l.status', [2, 3])
            .limit(limits)
            .offset((pageNo - 1) * limits)
            .join('cafe_list as c_l', {'o_l.cafe_list_id': 'c_l.id'})
            .join('user_customer_profile as u_c', {'o_l.user_customer_id': 'u_c.user_customer_id'})
            .leftJoin('order_payment as o_p', {'o_l.id': 'o_p.order_list_id'});

        let getCountOfOrderList = await knex({o_l: 'order_list'})
            .whereIn('o_l.status', [2, 3])
            .join('cafe_list as c_l', {'o_l.cafe_list_id': 'c_l.id'})
            .join('user_customer_profile as u_c', {'o_l.user_customer_id': 'u_c.user_customer_id'})
            .leftJoin('order_payment as o_p', {'o_l.id': 'o_p.order_list_id'})
            .count('* as cnt');

        Promise.all([
            historyQry,
            getCountOfOrderList
        ]).then(([data, ct]) => {

            let totalCount = ct[0].cnt;
            br.sendSuccess(res, helper.getPaginateResponse(totalCount, limits, pageNo, data), 'All Order History Details');

        }).catch((err) => {
            br.sendDatabaseError(res, err);
        })

    } catch (e) {
        br.sendServerError(res, e);
    }
}

const getOrderHistoryById= async function(req,res){
    try{
    let id= parseInt(req.params.id);
    if(!id>0) return res.status(400).send({status:false,msg:"please enter valid order list id"})
    let getOrderListData= await knex.select('order_list.id as order_list_id','order_list.uid as order_list_uid',
    'order_list.qr_code_id','user_customer_profile.first_name','user_customer_profile.last_name','cafe_list.cafe_name',
    'order_payment.amount','order_payment.payment_mode','order_payment.discount','order_list.start_date_time','order_list.end_date_time',
    'order_list.approved_by')
    .from('order_list')
    //.join('order_detail',{'order_detail.order_list_id':'order_list.id'})
    .join('order_payment',{'order_payment.order_list_id':'order_list.id'})
    .join('cafe_list',{'cafe_list.id':'order_list.cafe_list_id'})
    .join('user_customer_profile',{'user_customer_profile.user_customer_id':'order_list.user_customer_id'})
    .where('order_list.id',id).whereIn('order_list.status',[2,3])

    let orderDetailData= await knex.select('order_detail.order_list_id as order_list_id',
    'order_detail.id as order_detail_id',
    'order_detail.uid as order_detail_uid','menu_item.menu_item_name','menu_item_price.price','order_list.status as order_list_status',
    'order_detail.cooking_instruction','order_detail.served_by','order_detail.book_date_time','order_detail.serve_date_time').from('order_list')
    .join('order_detail',{'order_detail.order_list_id':'order_list.id'})
    .join('menu_item_price',{'menu_item_price.id':'order_detail.menu_item_price_id'})
    .join('menu_item',{'menu_item.id':'menu_item_price_id'})
    .where('order_list.id',id).whereIn('order_list.status',[2,3])

    let addonDAta= await knex.select('order_detail.order_list_id','order_detail.id as order_detail_id',
    'menu_addon.Addon_name','menu_addon_price.addon_price').from('order_list')
    .join('order_detail',{'order_detail.order_list_id':'order_list.id'})
    .join('menu_addon_price',{'menu_addon_price.id':'order_detail.menu_addon_price_id'})
    .join('menu_addon',{'menu_addon.id':'menu_addon_price.menu_addon_id'})
    .where('order_list.id',id).whereIn('order_list.status',[2,3])
    
       let items = [];

        for (let item of orderDetailData) {

                let addOns = [];

                for (let addOn of addonDAta) {

                    if (item.order_detail_id === addOn.order_detail_id) {
                        addOns.push(addOn)
                    }
                }
                items.push({
                    ...item,
                    orderAddOns: addOns
                })
            
        }
        return res.status(200).send({status:true,getOrderListData,items})
    
    }
    catch(error){
        console.log(error)
        return res.status(500).send({ERROR:error})
    }
}
// const getOrderHistoryById = async (req, res) => {
//     try {
//         let id = parseInt(req.params.id);

//         if (id > 0) {
//             knex.select('o_l.id as order_list_id','o_l.uid as order_list_uid','c_l.cafe_name','u_c_p.first_name','u_c_p.last_name','o_l.qr_code_id','o_p.amount','o_p.payment_mode','o_p.discount','o_l.start_date_time',
//             'o_l.end_date_time','o_l.approved_by','o_d.uid as order_detail_uid','o_d.id as order_detail_id','')
//                 .from('order_list as o_l')
//                 .join('cafe_list as c_l', {'o_l.cafe_list_id': 'c_l.id'})
//                 .join('user_customer_profile as u_c', {'o_l.user_customer_id': 'u_c.user_customer_id'})
//                 .join('order_payment as o_p', {'o_l.id': 'o_p.order_list_id'})
//                 .join('order_detail as o_d',{'o_d.order_list_id':'o_l.id'})
//                 .join('menu_item_price as m_i_p',{'m_i_p.id':'o_d.menu_item_price_id'})
//                 .join('menu_item as m_i',{'m_i.id':'m_i_p.menu_item_id'})
//                 .where({'o_l.id': req.params.id}).whereIn('o_l.status',[2,3])
//                 .then((data) => {
//                     console.log(data);
//                     if (data.length > 0) {
//                         br.sendSuccess(res, data[0], "Order History Details By Id");
//                     } else {
//                         br.sendDatabaseError(res, "The table dosn't contain any data")
//                         console.log("empty table is there, please insert the data then you will get that data back");
//                     }
//                 }).catch((err) => {
//                 br.sendDatabaseError(res, err);
//             })
//         } else {
//             br.sendError(res, {}, 'Please provide a valid order id');
//         }
//     } catch (e) {
//         br.sendServerError(res, e);
//     }
// }

//     knex.select('*')
//    .from({order_list: 'o_l'})
//    .join('order_details as o_d', {'o_l.id':'o_d.order_list_id'})
//    .join('order_status_history as o_s_h', {'o_l.id':'o_s_h.order_list_id'})
//    .join('cafe_list as c_l', {'o_l.id':'c_l.id'})
//    .join('order_payments as o_p',{'o_l.id':'o_p.order_list_id'})
//    .join('user_customer as u_C', {'o_l.id':'u_c.id'})
//   .join('cafe_list as c_l', {'o_l.id':'c_l.id'})


module.exports = {
    getLiveOrders,
    getLiveOrderDetailById,
    Get_Order_History: getOrderHistory,
    Edit_Live_Order_Detail_by_ID,
    getOrderHistoryById
}


