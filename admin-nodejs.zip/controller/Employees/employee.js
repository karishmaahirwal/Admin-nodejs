const knex = require("../../db/db_knex")
const baseResponse = require("../../helper/baseResponse")
const { Validator } = require('node-input-validator');
const {generateToken} = require("../../helper/auth")
const {default: axios} = require("axios");

// Add Employee
const AddEmployee = async (req,res) =>{
    try{
        const v = new Validator(req.body, {
            // full_name:"required",
            user_role_id:"required",
            first_name:"required",
            last_name:"required",
            cafe_list_id:"required|integer",
            mobile_number: 'required|minLength:10',
            email: "required",
            status: "required",
            photo_proof_id_url: "required",
            address_proof_id_url: "required",
            // profile_pic_image_id: "required"

        });
        v.check().then((matched) => {
            if(!matched){
                res.status(422).send(baseResponse.withError('Missed Required files', v.errors));
            }else{
            knex.select('*').from('user_admin')
                .then((data) => {
                    if (data.length > 0) {
                        let user_admin_data = {
                            // full_name:req.body.full_name,
                            user_role_id:req.body.user_role_id,
                            cafe_list_id:req.body.cafe_list_id,
                            email: req.body.email,
                            mobile_number: req.body.mobile_number,
                            status: req.body.status
                      };
                    
                      let user_admin_id;
                      (async () => {
                        user_admin_id=await knex('user_admin').insert(user_admin_data);
                        console.log(user_admin_id)
                        let admin_profile_data = {
                            user_admin_id:user_admin_id[0],
                            first_name:req.body.first_name,
                            last_name:req.body.last_name,
                            photo_proof_id_url:req.body.photo_proof_id_url,
                            address_proof_id_url: req.body.address_proof_id_url,
                            profile_pic_image_id: req.body.profile_pic_image_id
                      };
                    await axios.post('https://auto.a2deats.com/webhook/03ad9611-702b-42b2-809f-70fb8caca71d', {
                       id:user_admin_id[0].toString()
                    })
                      knex('user_admin_profile').insert(admin_profile_data).then((data) => {
                        res.status(200).send(baseResponse.withSuccess("Data Created", data))
                        //  console.log("user_admin Data Created")
                     }).catch((err) => {
                         res.status(500).send(err.message)
                         console.log(err.message);
                     })
                    })();
                     
                        
                    } else {
                        res.status(400).send(baseResponse.withError(' data not found!'));
                        console.log(' data not found');
                    }
                }).catch((err) => {
                    console.error({ "error": err });
                    res.status(500).send(err.message)
                    console.log(err.message);
                })
}
});
    }catch (e) {
        console.log(e);
        res.status(500).send(baseResponse.withError(''));
    }
}


// Get employees
const GetEmployees = async (req,res)=>{

    let pageno=req.query.pageno;
        let limits=req.query.limits;    
        if(!limits){
            limits=10;
        }
        if(!pageno){
            pageno=0;
        }
        else{
            pageno=pageno-1;
        }

    knex('user_admin').select('user_admin.id','user_admin.user_role_id','user_admin.cafe_list_id','user_admin.mobile_number','user_admin.country_code',
    'user_admin.email','user_admin.token','user_admin.status','user_admin.uid','user_admin.player_id','cafe_list.cafe_name','cafe_list.city',
    'cafe_list.city','user_admin_profile.first_name','user_admin_profile.last_name','user_admin_profile.photo_proof_id_url','user_admin_profile.address_proof_id_url',
    'user_admin_profile.profile_pic_image_id','user_admin_profile.photo_proof_id_number','user_admin_profile.address_proof_id_number')
    .leftJoin('cafe_list',{'cafe_list.id':'user_admin.cafe_list_id'})
    .leftJoin('user_admin_profile', {'user_admin_profile.user_admin_id' : 'user_admin.id'}).limit(limits).offset(pageno*limits) 
    .then((data) => {
        (async () => {
            let getCountOfUserAdmin= await knex('user_admin').count('id as cnt')
            let counting={
                'cnt':getCountOfUserAdmin[0].cnt
                }
            console.log(counting.cnt,"hi")
            res.status(200).send({status:true,msg:"menu category list",TOTALCOUNTOFUSERADMIN:counting.cnt,data})
        })();

        // res.status(200).send(baseResponse.withSuccess("all Employees ", data))
        // console.log(data);
    }).catch((err) => {
        res.status(500).send(err.message)
        console.log(err.message);
    });
}



const GetEmployeesById = async (req,res)=>{
    try{
        //console.log(req.params.id);
        knex.select('user_admin.id','user_admin.user_role_id','user_admin.cafe_list_id','user_admin.mobile_number',
        'user_admin.country_code','user_admin.email',
        'user_admin.status','user_admin.uid','user_admin.player_id','user_admin_profile.first_name',
        'user_admin_profile.last_name',
        'user_admin_profile.photo_proof_id_url','user_admin_profile.address_proof_id_url',
        'user_admin_profile.profile_pic_image_id',
        'user_admin_profile.photo_proof_id_number','user_admin_profile.address_proof_id_number')
            .from('user_admin')
            .leftJoin('user_admin_profile', {'user_admin_profile.user_admin_id' : 'user_admin.id'})
            .where({'user_admin.id' : req.params.id})
            .then((data) => {
                //console.log(data);
                if(data.length > 0){
                    res.status(200).send(baseResponse.withSuccess("Employees Details", data[0]))
                    console.log(data[0]);
                }else{
                    res.status(404).send(baseResponse.withError("Employees not found"));
                }
            }).catch((err) => {
            res.status(500).send(err.message)
            console.log(err);
        });
    }catch (e) {
        console.log(e);
        res.status(500).send(baseResponse.withError(''));
    }
}



const UpdateEmployeeById = async (req,res) =>{
    try{
         const v = new Validator(req.body,{
            user_role_id:"required",
            first_name:"required",
            last_name:"required",
            cafe_list_id:"required|integer",
            mobile_number: 'required|minLength:10',
            email: "required",
            photo_proof_id_url: "required",
            address_proof_id_url: "required",
            profile_pic_image_id: "required"
            
        })
        v.check().then((matched) => {
                if(!matched){
                    res.status(422).send(baseResponse.withError('Missed Required files', v.errors));
                }else{
                    let id  = parseInt(req.params.id)
            if(id > 0){
                let user_admin_data = {
                    // full_name:req.body.full_name,
                    user_role_id:req.body.user_role_id,
                    cafe_list_id:req.body.cafe_list_id,
                    email: req.body.email,
                    mobile_number: req.body.mobile_number,
              };
            
              (async () => {
                await knex('user_admin').update(user_admin_data).where('user_admin.id', id);
                let admin_profile_data = {
                    first_name:req.body.first_name,
                    last_name:req.body.last_name,
                    photo_proof_id_url:req.body.photo_proof_id_url,
                    address_proof_id_url: req.body.address_proof_id_url,
                    profile_pic_image_id: req.body.profile_pic_image_id
              };

              knex('user_admin_profile').update(admin_profile_data).where('user_admin_profile.user_admin_id',id).then((data) => {
                res.status(200).send(baseResponse.withSuccess("Data Updated", data))
                //  console.log("user_admin Data Created")
             }).catch((err) => {
                 res.status(500).send(err.message)
                 console.log(err.message);
             })
            })();
                }
             else{
                    baseResponse.sendError(res, {}, 'invalid form id');
            }
        }
    })
    
    }catch (e) {
        console.log(e);
        res.status(500).send(baseResponse.withError(''));
}
}



//Get employees by cafe_list_id
const GetEmployeesCafeId = async(req,res)=>{
    try{
        //console.log(req.params.id);
        knex.select('*')
            .from('user_admin')
            .where({cafe_list_id : req.params.cafe_list_id})
            .then((data) => {
                //console.log(data);
                if(data.length > 0){
                    res.status(200).send(baseResponse.withSuccess("Employees Details", data[0]))
                    console.log(data[0]);
                }else{
                    res.status(404).send(baseResponse.withError("Employees not found"));
                }
            }).catch((err) => {
            res.status(500).send(err.message)
            console.log(err.message);
        });
    }catch (e) {
        console.log(e);
        res.status(500).send(baseResponse.withError(''));
    }
}




//Get employees by cafe_list_id and Emp id

const GetEmployeesCafeIdEmpId= async(req,res) => {
    try{
        let cafe_list_id = parseInt(req.params.cafe_list_id),
            id = parseInt(req.params.id);

        if(cafe_list_id > 0 && id > 0){
            knex('user_admin')
                .select('*')
                .where('cafe_list_id', cafe_list_id)
                .where('id', id)
                .then((data)=>{
                    res.status(200).send(baseResponse.withSuccess('Employees details!', data));
                })
                .catch((err)=>{
                    logger.error(err);
                    res.status(500).send(baseResponse.withError(err));
                });
        }else{
            res.status(400).send(baseResponse.withError('Please enter proper cafe_list_id Id and  Employees id!'));
        }
    }catch(e){
        logger.error(e);
        res.status(500).send(baseResponse.withError(e.toString()));
    }
}


const uploadImage = async(req,res)=>{
    try {

        if(req.files.profile_photo!==undefined){
            let  imagePublicUrl =  process.env.BASE_URL + 'adminProfile/' + req.files.profile_photo[0].filename
            res.json({profileImageUrl:imagePublicUrl})
        }else{
            res.json({Error:"Provide Profile Image"})
        }
      
    } catch (error) {
        res.json({error})
    }
}


const sendVerification = async (req, res) => {
    const email = req.body.email;
    knex('user_admin').select('*').where('user_admin.email', email).then((data) => {
        if (data.length > 0) {
            //  
            const user = {
                'email': email,
            };
            console.log(user);
            const token = generateToken(user)
            console.log(token);
            console.log(data[0].user_role_id)
            knex("user_admin").where('email', email).update({token: token}).then((row) => {
                // token updated //https://auto.a2deats.com/webhook/reset-password-64a53eb9-7e6e-4e2a-8798-63a05ad1a88a
                //https://auto.a2deats.com/webhook/reset-password-64a53eb9-7e6e-4e2a-8798-63a05ad1a88a
                axios.post('https://auto.a2deats.com/webhook/onboard-64a53eb9-7e6e-4e2a-8798-63a05ad1a88a', {

                    email: email,
                    // email: "suman.mal@a2d.co.in",
                    user_role_id: data[0].user_role_id.toString(),
                    token: token
                }).then((response) => {
                    console.log(response)
                    res.status(200).json({msg: "email sent"})
                }).catch((err) => {
                    res.status(500).send(err.message);
                    console.log(err.message);
                })

            }).catch((err) => {
                res.status(500).send(err.message);
                console.log(err.message);
            })
        } else {
            res.status(400).json({err: "email does not exist"});
        }
    })
}

module.exports = {
    AddEmployee,
    GetEmployees,
    GetEmployeesById,
    UpdateEmployeeById,
    GetEmployeesCafeId,
    GetEmployeesCafeIdEmpId,
    uploadImage,
    sendVerification


}