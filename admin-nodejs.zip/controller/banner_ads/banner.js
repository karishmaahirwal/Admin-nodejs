const knex = require("../../db/db_knex")
const helper = require("../../helper/helper");
const {Validator} = require('node-input-validator');
const br = require("../../helper/baseResponse");
const logger = require("../../helper/logger");
const moment = require("moment");


const banners = (req, res) => {
    try {
        let pageNo = parseInt(req.query.pageno);
        let limit = parseInt(req.query.limits);

        if (isNaN(pageNo) || pageNo < 1) {
            pageNo = 1;
        }

        if (isNaN(limit) || limit < 1) {
            limit = 10;
        }

        let bannerQry = knex.select('banner_ad.id as banner_ad_id',
            'banner_ad.uid',
            'banner_ad.position',
            'banner_ad.banner_image_id',
            'banner_ad.title',
            'banner_ad.created_at',
            'banner_ad.start_date',
            'banner_ad.end_date',
            'banner_ad.category',
            'banner_ad.cafe_list_id',
            'cafe_list.cafe_name',
            'banner_ad.clicks_count',
            'banner_ad.status as banner_ad_status').from('banner_ad')
            .orderBy('banner_ad.position')
            .join('cafe_list', {'cafe_list.id': 'banner_ad.cafe_list_id'})
            .limit(limit).offset((pageNo - 1) * limit);

        let bannerCountQry = knex.count('* as ct').from('banner_ad')
            .join('cafe_list', {'cafe_list.id': 'banner_ad.cafe_list_id'});

        Promise.all([bannerQry, bannerCountQry]).then(([data, total]) => {

            /*                if (data.length > 0) {

                                (async () => {
                                    let getCountOfBannerAds = await knex('banner_ad').count('id as cnt')
                                    let counting = {
                                        'cnt': getCountOfBannerAds[0].cnt
                                    }
                                    console.log(counting.cnt, "hi")
                                    res.status(200).send({
                                        status: true,
                                        msg: "menu addon price list",
                                        TOTALCOUNTOFBANNERADS: counting.cnt,
                                        data
                                    })
                                })();
                                // res.status(200).send(br.withSuccess("All Banner Details", data))
                                // console.log(data[0]);
                            } else {
                                br.sendDatabaseError(res, "The table dosn't contain any data")
                                console.log("empty table is there, please insert the data then you will get that data back");
                            }*/

            let totalCount = total[0].ct;
            br.sendSuccess(res, helper.getPaginateResponse(totalCount, limit, pageNo, data), 'All Banner Details!');

        }).catch((err) => {
            br.sendServerError(res, err);
        })
    } catch (e) {
        br.sendServerError(res, e);
    }
}


const uploadBanner = (req, res) => {
    try {
        const v = new Validator(req.body, {
            cafe_list_id: 'required',
            start_date: 'required',
            end_date: 'required',
            banner_link: 'required',
            title: 'required|string',
            category: 'required|string',
            position: 'integer',
            banner_image_id: 'required',
            status: 'required',
        });

        v.check().then(async (matched) => {
            if (!matched) {
                res.status(422).send(br.withError('Missed Required files', v.errors));
            } else {

                let user = {
                    uid: moment().format('Y-M-d-h-m-s'),
                    cafe_list_id: req.body.cafe_list_id,
                    start_date: req.body.start_date,
                    end_date: req.body.end_date,
                    banner_link: req.body.banner_link,
                    title: req.body.title,
                    category: req.body.category,
                    position: req.body.position,
                    banner_image_id: req.body.banner_image_id,
                    status: req.body.status,
                };

                let cafe_list_id = Number(user.cafe_list_id);

                if (cafe_list_id > 0) {
                    let cafeDetails = await knex('cafe_list').where('id', cafe_list_id);

                    if (!(cafeDetails.length > 0)) {
                        return br.sendError(res, {}, 'Cafe details does not exists!');
                    }
                }else{
                    user.cafe_list_id = null;
                }

                let maxSeqNumber = await knex('banner_ad')
                    .select(knex.raw('COALESCE(max(position), 0) as maxSeq'));

                if (user.position > 0 && maxSeqNumber[0].maxSeq > user.position) {
                    await knex('banner_ad').update({position: knex.raw(' position + 1 ')})
                        .where('position', '>=', user.position);
                } else {
                    user.position = maxSeqNumber[0].maxSeq + 1;
                }

                let cf = await knex('banner_ad').insert(user);
                let data = await knex('banner_ad').where('id', cf[0]);
                await axios.post('https://auto.a2deats.com/webhook/42f836eb-ac08-4c61-8602-147a6df17a27', {
                       id:cf[0].toString()
                    })

                br.sendSuccess(res, data[0], 'Banner Add Created!');
            }
        }).catch(e => br.sendServerError(res, e));
    } catch (e) {
        console.log(e);
        res.status(500).send(br.withError(''));
    }
}


const editBanner = (req, res) => {
    try {
        const v = new Validator(req.body, {
            cafe_list_id: 'required',
            start_date: 'required',
            end_date: 'required',
            banner_link: 'required',
            title: 'required',
            category: 'required',
            position: 'required',
            banner_image_id: 'required',
            status: 'required',
        });

        v.check().then(async (matched) => {
            if (!matched) {
                res.status(422).send(br.withError('Missed Required files', v.errors));
            } else {
                const id = Number(req.params.bannerId);
                console.log(id)
                if (id > 0) {
                    let oldBannerData = await knex('banner_ad').where('id', id);

                    if(!(oldBannerData.length > 0)){
                        return br.sendError(res, {}, `Banner Ad with ${id} does not exists!`);
                    }

                    oldBannerData = oldBannerData[0];


                    let user = {
                        start_date: req.body.start_date,
                        cafe_list_id: req.body.cafe_list_id,
                        end_date: req.body.end_date,
                        banner_link: req.body.banner_link,
                        title: req.body.title,
                        category: req.body.category,
                        position: req.body.position,
                        banner_image_id: req.body.banner_image_id,
                        status: req.body.status,
                    };

                    if(helper.isNotUndefinedOrNull(user.position) && parseInt(user.position) > 0){

                        let items = await knex('banner_ad').where('position', user.position);

                        if(items.length > 0 && user.position !== oldBannerData.position){

                            if(user.position > oldBannerData.position){
                                let upCt = await knex('banner_ad')
                                    .update({ position: knex.raw('position - 1')})
                                    .where('position', '<=', user.position)
                                    .whereNot('position', oldBannerData.position);

                                console.log(upCt);
                            }else{
                                let upCt = await knex('banner_ad')
                                    .update({ position: knex.raw('position + 1')})
                                    .where('position', '>=', user.position)
                                    .whereNot('position', oldBannerData.position);

                                console.log(upCt);
                            }
                        }
                    }

                    await knex('banner_ad').update(user).where('banner_ad.id', id);
                    let data = await knex('banner_ad').where('banner_ad.id', id);

                    br.sendSuccess(res, data[0], 'Banner Ad Data Updated');
                } else {
                    br.sendError(res, {}, 'invalid form banner id');
                }

            }
        });
    } catch (e) {
        console.log(e);
        res.status(500).send(br.withError(''));
    }
}


const getbannerById = (req, res) => {
    try {
        const bannerId = req.params.bannerId;
        console.log(bannerId)
        knex('banner_ad').select('*').where('banner_ad.id', bannerId)
            .then((data) => {
                console.log(data);
                if (data.length > 0) {
                    res.status(200).send(br.withSuccess("All Banner Details", data))
                    console.log(data[0]);
                } else {
                    br.sendDatabaseError(res, "The table dosn't contain any data")
                    console.log("empty table is there, please insert the data then you will get that data back");
                }
            }).catch((err) => {
            console.error({"error": err});
            res.status(500).send(err.message)
            console.log(err.message);
        })
    } catch (e) {
        console.log(e)
        res.status(500).send(br.withError("server error"));
    }
}


module.exports = {banners, uploadBanner, editBanner, getbannerById};