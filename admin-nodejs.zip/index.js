const express = require("express")
const logger = require("./helper/logger")
const signup = require("./router/signup")
const Restaurant = require("./router/Resturant/restaurant")
const Employees = require("./router/Employees/employees")
const menu_Category = require("./router/Category/menu_category")
const menu_addon = require("./router/Category/menu_addon")
const menu_item = require("./router/Category/menu_item")
const menu_item_price = require("./router/Category/menu_item_price")
const menu_addon_price = require("./router/Category/menu_addon_price")
// const qr_code  =require("./router/category/qr_code")
const orders = require("./router/orders")
const mobile_app_User = require("./router/mobile_app_user/mobile_app_user")
const banner_ad = require("./router/banner_ads/banner")
const qr_code = require("./router/qr_code/qr_code")
const fileupload = require("express-fileupload")
const cors=require('cors')
const bodyParser = require("body-parser")
const cookieParser = require("cookie-parser")

const swaggerUI = require("swagger-ui-express")
const swaggerJsDoc = require("swagger-jsdoc")

const app = express()
app.use(bodyParser.json())
app.use(cookieParser())
app.use(cors());

app.use(fileupload({
    useTempFiles:true
}))

const dotenv=require('dotenv');
dotenv.config({path: './config.env'});


const port = process.env.PORT || 3000;

app.listen(port, () => {
    console.log(`local server started on http://localhost:${port}`);
});

app.use("/",signup)
app.use("/",Restaurant)
app.use("/",Employees)
app.use("/",menu_Category)
app.use("/",menu_item)
app.use("/",menu_addon)
app.use("/",menu_item_price)
app.use("/",menu_addon_price)
app.use("/",qr_code)
app.use("/",orders)
app.use("/",mobile_app_User)
app.use("/",banner_ad)
// app.use("/",mobile_app_User)

app.use( (req, res, next) => {
    if(req.path.includes('/api/')){
        logger.info('Request Type: ' + req.method + ' Path:' + res.req.path + ' req.body =>');
        logger.info(req.body);
    }
    next();
});

//check for uncaught exception and throw the error!
process.on('uncaughtException', err => {
    console.log('uncaughtException:', err);
    logger.error('uncaughtException => ' + JSON.stringify(err, null, 2));
});

const options = {
    definition: {
        openapi: "3.0.0",
        info: {
            title: "Eats-backend API",
            version: "1.0.0",
            // description: " Eats-backend API"
        },

        components: {
            securitySchemes:{
                bearerAuth: {
                    type: "http",
                    scheme: "bearer",
                    bearerFormat: "JWT"
                }
            }
        },
        security: [
                {
                    bearerAuth: []
                }
        ],
        servers: [
              {
                url: "https://app-admin.a2deatsdev.in/",
                  description: "staging server",
              },
              {
                  url: "http://localhost:4001",
                  description: "Local dev",
              }
        ],
    },
    apis: [
        "./router/*.js",
        "./router/*/*.js"
    ],

};

const swaggerSpecs = swaggerJsDoc(options)
app.use("/api-docs", swaggerUI.serve, swaggerUI.setup(swaggerSpecs))



