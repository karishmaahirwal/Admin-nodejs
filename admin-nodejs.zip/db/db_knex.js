const dotenv=require('dotenv');
dotenv.config({path: './config.env'});


// console.log(process.env.host)
// console.log(process.env.user)
// console.log(process.env.password)
// console.log(process.env.database)
// console.log(process.env.port1)
const options = {
    client: 'mysql',
    connection: {
        host : process.env.host,
        user : process.env.user,
        password : process.env.password,
        database : process.env.database,
        port: process.env.port1
    }
  }
module.exports = require('knex')(options);


