/***
 * This is deprecated index.js is the starting point of the application
 * @type {createApplication}
 */

const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const app = express()
const router = require("./router/signup")
const Restaurant = require("./router/Resturant/restaurant")
const Employees = require("./router/Employees/employees")
const menu_Category = require("./router/Category/menu_category")
const menu_item = require("./router/Category/menu_item")
const menu_addon = require("./router/Category/menu_addon")
const menu_item_price = require("./router/Category/menu_item_price")
const menu_addon_price = require("./router/Category/menu_addon_price")
const qr_code = require("./router/Category/qr_code")
const orders = require("./router/orders")
const mobile_app_User = require("./router/mobile_app_user/mobile_app_user")
// security
app.use(helmet());

// cors
app.use(cors());

// convert everything to json
app.use(express.json());
app.use(express.urlencoded({extended: true}));


app.use("/", router)
app.use("/", Restaurant)
app.use("/", Employees)
app.use("./", menu_Category)
app.use("/", menu_item)
app.use("/", menu_addon)
app.use("/", menu_item_price)
app.use("./", menu_addon_price)
app.use("./", qr_code)
app.use("./", orders)
app.use("/", mobile_app_User)


module.exports = app;